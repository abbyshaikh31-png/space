"""
pandas._config is considered explicitly upstream of everything else in pandas,
should have no intra-pandas dependencies.

importing `dates` and `display` ensures that keys needed by _libs
are initialized.
"""

__all__ = [
    "describe_option",
    "detect_console_encoding",
    "get_option",
    "option_context",
    "options",
    "reset_option",
    "set_option",
]
from pandas._config import dates  # pyright: ignore[reportUnusedImport]  # noqa: F401
from pandas._config.config import (
    _global_config,
    describe_option,
    get_option,
    option_context,
    options,
    reset_option,
    set_option,
)
from pandas._config.display import detect_console_encoding


def using_string_dtype() -> bool:
    return _global_config["future"]["infer_string"]


def using_python_scalars() -> bool:
    return _global_config["future"]["python_scalars"]


def is_nan_na() -> bool:
    return not _global_config["future"]["distinguish_nan_and_na"]


def using_infer_freq_offset() -> bool | None:
    return _global_config["future"]["infer_freq_returns_offset"]
