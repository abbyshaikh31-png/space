# ONLINE DEPLOYMENT — every step, explained like you've never done this

Read top to bottom. Do not skip. Total time: ~20 minutes.
Everything is free. No credit card anywhere.

```
 WHAT YOU ARE BUILDING (the whole picture):

   Kilo Code  ──https──▶  your service on Render  ──https──▶  Tusk free AI
   (your PC,               (a tiny server that lives
    any PC)                 on the internet)
```

WHY NOT HUGGING FACE: since July 2026 HF charges for any Space that runs
code (Docker/Gradio). Only "Static" (plain website) Spaces are free there,
and those cannot run our server. Render's free tier still runs code.

---

# PART 0 — Fix your broken Kilo FIRST (2 minutes)

The `<p>Something went wrong generating that response...</p>` messages in
Kilo were **Tusk's own error page leaking through the OLD shim**.
Version 1.2.1 detects it and retries with a fresh session automatically.

1. Close the black console window running the shim.
2. In your `tusk` folder **delete** old `openai_shim.py` and `tusk_ai.py`.
3. Copy the new `openai_shim.py` + `tusk_ai.py` from this zip's
   `local-fallback` folder into your `tusk` folder.
   (These 2 files are the ONLY files that changed. `start.bat` unchanged.)
4. Double-click `start.bat`. Banner must say **tusk-openai-shim 1.2.1**.
5. Kilo needs no change for local use (same Base URL / key / model as before).

---

# PART 1 — Make your API key (1 minute)

This key is a password. Anyone holding it spends YOUR quota.

1. `Win + R` → type `cmd` → Enter.
2. Paste + Enter:
   ```
   python -c "import secrets; print(secrets.token_urlsafe(32))"
   ```
3. Copy the 43-character string it prints into notepad.
   You will paste it twice later (Render, then Kilo).

---

# PART 2 — GitHub: a private locker for your 3 files (5 minutes)

Render builds your server FROM a GitHub repo. GitHub here is just a
file locker — we only use drag & drop in the browser, never git commands.

1. Go to https://github.com/signup → create a free account (email + password
   + username). Verify your email when asked.
2. Log in. Top-right click the **+** icon → **New repository**.
3. Fill:
   - **Repository name**: `tusk-shim`
   - Click the dot on **Private**   ← important
   - Do NOT tick "Add a README"
4. Click green **Create repository**.
5. You land on an empty page with a link saying **"uploading an existing
   file"** — click that link (or: **Add file** button → **Upload files**).
6. From this zip open the `render` folder and drag these **3 files** in:
   - `openai_shim.py`
   - `tusk_ai.py`
   - `requirements.txt`
7. Scroll down: click green **Commit changes** (message can stay default).
8. Done. Your locker: `github.com/YOURUSERNAME/tusk-shim` (private).

---

# PART 3 — Render: the free server (7 minutes)

1. Go to https://render.com → click **Get Started for Free** →
   choose **GitHub** → authorize Render (it asks which repos it may see:
   choose **Only select repositories** → pick `tusk-shim` → Save).
   (No credit card. If it ever asks for a card, you're on a paid flow — go
   back and pick the Free plan / GitHub signup.)
2. In the Render dashboard click **New +** (top right) → **Web Service**.
3. It lists your repos → click **Connect** next to `tusk-shim`.
4. Fill the form EXACTLY like this (leave everything else default):
   - **Name**: `tusk-shim` (this decides your URL, see step 7)
   - **Region**: pick the closest to you
   - **Branch**: `main`
   - **Root Directory**: leave empty
   - **Runtime**: **Python 3**
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python -u openai_shim.py`
   - **Instance Type / Plan**: click **Free**
5. Open the **Environment Variables** section (same page, below) and add TWO:
   | Key | Value |
   |---|---|
   | `SHIM_API_KEY` | *paste your random key from PART 1* (mark Secret if offered) |
   | `PYTHON_VERSION` | `3.12.0` |
6. Click **Create Web Service** (bottom).
7. Render now builds (~2 minutes). Watch the log stream. Success looks like:
   ```
   tusk-openai-shim 1.2.1 on http://0.0.0.0:10000
     mode : PUBLIC -- reachable over the network
   ```
   (The port number will differ — Render picks it, the shim auto-reads it.)
8. Your public URL is at the top of the page, shaped like:
   `https://tusk-shim.onrender.com`
   Test it in a browser: `https://tusk-shim.onrender.com/health`
   → must show JSON starting `{"ok": true, ...}`.

**Your server is now on the internet.** 🎉

If logs instead say "REFUSING TO START -- public bind without an API key":
the `SHIM_API_KEY` variable is missing/misspelled → step 5 again.

---

# PART 4 — Point Kilo Code at it (2 minutes)

In Kilo Code:

1. Settings (gear) → **Providers** → your OpenAI Compatible provider.
2. Change exactly two fields:
   - **Base URL**: `https://tusk-shim.onrender.com/v1`   (your URL + `/v1`, https)
   - **API Key**: *the same random key from PART 1*
3. **Model** → **Fetch Available Models** → pick `brainiac`. Save.
4. Send "hello". It answers with your PC's console window CLOSED.
   Same 3 settings on any other computer = works there too.

"There are no files inside Kilo" — Kilo stores only those 3 settings.
The files that changed are the two .py files (PART 0), replaced both in
your `tusk` folder and in the GitHub repo (you uploaded the new ones).

---

# PART 5 — Stop it from sleeping (3 minutes, do this!)

Render Free spins the server down after **15 minutes** without traffic.
A sleeping server makes the next Kilo message wait ~1 minute or fail once.
Kill the sleep forever with a free pinger:

1. https://cron-job.org → free account (email only).
2. Dashboard → **CREATE CRONJOB**:
   - URL: `https://tusk-shim.onrender.com/health`
   - Schedule: **Every 10 minutes**
   - Save.
3. It pings your server forever → server never sees 15 idle minutes →
   never sleeps → Kilo always fast. Done.

---

# Troubleshooting

| Symptom | Meaning / fix |
|---|---|
| Kilo: ECONNREFUSED / timeout | server asleep (pinger not set up?) or still deploying → open `/health` in browser once, wait 60s, retry |
| Kilo: 401 | key in Kilo ≠ key in Render env vars (no extra spaces!) |
| Render logs: "REFUSING TO START" | `SHIM_API_KEY` missing → PART 3 step 5 |
| Render logs: upstream errors on EVERY request | Tusk blocking cloud IPs today → use `start.bat` locally (local-fallback folder) |
| `<p>Something went wrong...` in Kilo | old shim → banner/logs must say 1.2.1; re-upload both .py files (GitHub + your folder) |
| Render deploy fails at build | check you uploaded `requirements.txt` and Build Command is exactly `pip install -r requirements.txt` |
| Answers slow (30s+) | Tusk rate limit (~10 calls/min per IP) or cold start — self-recovers |

**Rules of the road:** repo Private, key secret, use it yourself.
One shared IP ≈ 10 calls/min from Tusk; a crowd on your key = 429s for
everyone and possibly a banned IP.

**Updating later:** upload new `openai_shim.py` / `tusk_ai.py` over the old
ones on GitHub (Add file → Upload files → Commit) — Render redeploys itself.
