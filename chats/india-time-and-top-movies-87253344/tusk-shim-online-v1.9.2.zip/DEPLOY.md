# Put the shim online — free, in ~20 minutes

Your own public URL like `https://tusk-shim.onrender.com/v1` that Kilo Code
can use **from anywhere** — laptop, phone, another PC. Still free, still no
paid API key. The full click-by-click version is in **ONLINE-STEPS.md** —
follow that one; this file is the short technical summary.

> ⚠️ **Hugging Face is NOT an option anymore.** Since July 2026 any Space
> that runs code (Docker or Gradio SDK) requires a paid plan; only Static
> Spaces are free and those cannot run a server. The `hf-space/` folder is
> kept only for people who already own an old free Docker Space.
> **Use Render — its free tier still runs code in 2026.**

## Render (free, needs a free GitHub account, no card)

1. Private GitHub repo with `openai_shim.py`, `tusk_ai.py`, `requirements.txt`
   (drag & drop in the browser is fine — no git commands needed).
2. render.com → sign up with GitHub → **New +** → **Web Service** → connect
   that repo. Settings:
   - Runtime **Python 3**, Build `pip install -r requirements.txt`,
     Start `python -u openai_shim.py`, plan **Free**.
3. Env vars: `SHIM_API_KEY=<your random key>` (secret), `PYTHON_VERSION=3.12.0`.
   Render injects `PORT`; the shim reads it and binds 0.0.0.0 by default.
   `/health` is open (no auth) so any health check passes.
4. Optional: `render/render.yaml` is a Blueprint that pre-fills all of the
   above and prompts for the key as a secret (New + → Blueprint instead).
5. Free tier spins down after 15 idle minutes → keep awake with a free
   cron-job.org job GETting `/health` every 10 minutes. Never sleeps again.

## Kilo settings for the online server

| Field | Value |
|---|---|
| Provider API | OpenAI Compatible |
| Base URL | `https://<your-service>.onrender.com/v1` |
| API key | your random key (same as Render env var) |
| Model | Fetch models → `brainiac` |

## Honest caveats

1. First request right after a spin-down is slow (~1 min) or fails once —
   the pinger in step 5 prevents spin-downs entirely.
2. The hosted IP's Tusk quota (~10 calls/min) is shared by everyone using
   your key. Keep the key secret; personal use only.
3. If Tusk ever starts rejecting cloud IPs, fall back to `start.bat`
   locally (`local-fallback/` folder) — same two .py files.

---

# Agent mode (Cowork inside the chat) — v1.4.0

The web UI's composer has a **Cowork toggle** (sparkle-cow icon). When ON, the
chat becomes an agent: the model writes scripts with `write_file`, executes
them with `run_python` / `run_shell` **on your server**, reads the output,
fixes and re-runs (up to `SHIM_AGENT_MAX_STEPS`, default 8), and you watch
`🔧 step N · tool(args) → result` chips appear live in the conversation.
Files live in `agent_workspace/` next to the shim.

## Render env vars to add (Settings → Environment)

| Var | Value |
|---|---|
| `SHIM_AGENT_TOKEN` | any long random string (second `secrets.token_urlsafe(32)`). Gates the agent endpoint; the web page asks you for it once when you first flip the toggle. **Never embedded in the page.** |
| `GITHUB_REPO` | `yourusername/your-repo` (optional, see below) |
| `GITHUB_PAT` | personal access token (optional, see below) |

## The GitHub repo = your permanent disk (days → months)

Render's free container has **ephemeral disk**: everything dies on restart.
Your GitHub repo fixes that:

1. GitHub → **Settings → Developer settings → Personal access tokens →
   Fine-grained tokens → Generate new token**.
   - Repository access: **Only select repositories** → pick your repo
   - Permissions → Contents: **Read and write**
   - Copy the token (starts with `github_pat_...` or `ghp_...`)
2. Put the repo name in `GITHUB_REPO` and the token in `GITHUB_PAT`.
3. The shim then: clones the repo into the workspace at boot, auto-commits +
   pushes after every agent session and every 10 minutes, and the agent gets
   a `github_push` tool. Restart, redeploy, even Render recycling the
   container — your workspace and the agent's scripts come back from GitHub.
   That is how work survives for months on a free host.

## Safety built in

- Agent subprocesses run with a **scrubbed env**: no PAT, no API keys inside.
- All file tools are jailed to the workspace dir (`../` escapes rejected).
- Each step has a timeout (`SHIM_AGENT_STEP_TIMEOUT`, default 60s).
- The agent endpoint 404s unless `x-agent-token` matches — and that token is
  never embedded in `/chat`, unlike the chat key.
- If the repo is **public**, everything the agent writes is public. Use a
  private repo if the work is personal.

## Per-chat folders in your repo (v1.5.1)

Every chat gets its **own folder** in the synced repo/workspace:
`chats/<chat-title>-<id>/` (e.g. `chats/butterfly-plot-experiment-58160123/`).
The agent of a chat is **jailed** to that folder: file tools and scripts cannot
read, write or list anything outside it — other conversations' folders are
invisible to it. `github_push` still syncs the whole repo (the repo is the
disk; the jail is per-conversation). Clients that send no chat metadata land
in `chats/chat-general/`. Verified: escape attempts (`../`) rejected on read,
write and list.

## Agent installs (v1.6.2) — and the env-var trap

NEVER set `PIP_USER` or `PIP_BREAK_SYSTEM_PACKAGES` as **Render service env
vars** — they break the build pip inside Render's virtualenv. The shim injects
them automatically *only inside the agent's subprocess* at runtime. The
workspace `.local/` package dir is created by the shim and gitignored; you
configure nothing.

For permanence across redeploys, use this Build Command:

    pip install -r requirements.txt; [ -f agent_requirements.txt ] && pip install -r agent_requirements.txt || true

The agent appends its runtime pip installs to `agent_requirements.txt` and
pushes it with the repo, so the next deploy bakes them in.
