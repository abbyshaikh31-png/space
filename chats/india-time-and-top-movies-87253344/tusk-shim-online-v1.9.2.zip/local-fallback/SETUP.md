# Setting up Tusk Free in Kilo Code — the easy way

3 steps. Takes about 2 minutes. No API key to buy, no account, nothing to install
(beyond Python, which you probably already have).

---

## Already running an old copy? Update in 2 steps (v1.1.0)

If Kilo is leaking text like *"I don't have access to tools"* or raw
`tool call` JSON into your chat, you're on **v1.0.0**. The fix is in v1.1.0:

1. **Stop the old server** — close its black console window.
2. **Replace two files** in your folder (`C:\tusk` or wherever they live)
   with the new ones from this zip: `tusk_ai.py` and `openai_shim.py`.
   Then double-click `start.bat` again. Nothing in Kilo changes —
   same Base URL, same key, same model.

How to tell which version you have: the console banner says
`tusk-openai-shim X.X.X` on startup. You want **1.1.0**.

**What v1.1.0 changes:**
- Tool calls that the model mangles (invented tool names, prose wrappers,
  XML tags, refusals) are now detected and **retried automatically** with a
  corrective nudge, instead of leaking into Kilo as plain text.
  Measured: 2/6 agentic prompts leaked before → 0/6 after.
- The scary 20-line `ConnectionResetError [WinError 10054]` tracebacks are
  gone. That was Kilo's connection pool closing idle sockets — harmless.
  It now prints one short `[info] ... harmless, ignored` line.
- `SHIM_PREFER_MODEL=GLM` env var: biases retries toward GLM when the router
  serves it (guests still can't truly pin a model — that needs a free account).

---

## Step 1 — Get the 3 files into one folder

Put these three files in a folder together, e.g. `C:\tusk` or `~/tusk`:

```
tusk_ai.py        <- talks to Tusk
openai_shim.py    <- translates it into the format Kilo understands
start.sh          <- launcher for Mac/Linux
start.bat         <- launcher for Windows
```

You need **all of them in the same folder**. `openai_shim.py` imports
`tusk_ai.py`, so they can't be separated.

---

## Step 2 — Run the launcher

**Windows:** double-click `start.bat`

**Mac / Linux:** open a terminal in that folder and run
```bash
chmod +x start.sh
./start.sh
```

You'll see this:

```
======================================================
 Tusk Free -> OpenAI bridge for Kilo Code
======================================================
 python    : Python 3.11.2
 listening : http://127.0.0.1:8100

 PUT THIS IN KILO CODE:
   Provider API : OpenAI Compatible
   Base URL     : http://127.0.0.1:8100/v1
   API key      : tusk-local-key
   Model        : click 'Fetch models', pick 'brainiac'

 Press Ctrl+C to stop. Leave this window open while using Kilo.
======================================================

[ok] upstream connectivity check passed
```

`[ok] upstream connectivity check passed` means Tusk is reachable. If you see
`[!!] upstream check FAILED`, read the error — usually it means no internet.

**Leave this window open.** Closing it stops the bridge and Kilo will fail.

---

## Step 3 — Tell Kilo Code about it

1. Open Kilo Code
2. Click the **gear icon** (Settings) → **Providers** tab
3. Scroll to the very bottom → click **Custom provider**
4. Fill in exactly these:

| Field | Type this |
|---|---|
| **Provider ID** | `tusk-free` |
| **Display name** | `Tusk Free` |
| **Provider API** | `OpenAI Compatible` ← pick this from the dropdown |
| **Base URL** | `http://127.0.0.1:8100/v1` |
| **API key** | `tusk-local-key` |

5. Click **Fetch models** → select **`brainiac`**
6. Click **Submit**
7. Pick **Tusk Free** from Kilo's model selector at the top

Done. Ask it something.

---

## "Is it truly unlimited?" — NO. Here is the real limit.

I was wrong the first time I answered this. I ran short burst tests, saw no
limits, and told you it was unlimited. Then I ran a proper sustained load test
and the server told me the truth itself:

```
HTTP 429
Retry-After: 3
"API calls quota exceeded! maximum admitted 10 per 1m."
```

**There is a quota: roughly 10 requests per minute sustained.** Under heavy load
I measured **222 of 375 requests rejected (59%)**.

### Why it hid from me at first

It behaves like a token bucket with a **large burst buffer**. Measured:

| Scenario | Rate | 429s |
|---|---|---|
| 24 simultaneous, from cold | burst | **0%** |
| 40 sequential at 1/sec | ~60/min | **0%** |
| 121 requests in 45s, from cold | 161/min | **0%** |
| 259 requests in 200s, from cold | 77.7/min | **0%** |
| 8 concurrent **right after** a heavy 2-min run | ~203/min | **59%** |

So short and medium bursts are genuinely free, and you can do a lot of work. But
once you drain the buffer with sustained hammering, it clamps you toward ~10/min
until it refills.

### What that means for Kilo agentic mode

- **Normal use: fine.** An agent doing 5–20 calls per task sits well inside the
  burst buffer. You will rarely notice.
- **Long autonomous runs: you will get throttled.** A multi-hour agent session
  making hundreds of calls will drain the buffer and start waiting.
- **It is handled for you.** I built the quota into the client: it self-throttles,
  and on a 429 it reads `Retry-After`, waits, and retries. In a deliberate
  throttling test — 8 concurrent, governor disabled, 150 seconds — the result was
  **198/198 successful, 0 failures**. Some calls took up to 58s because they were
  waiting out the quota, but none errored.

### Can you actually burn 20 million tokens?

No, and the maths is why:

- ~3,700 tokens per agentic call
- ~10 calls/min sustained ceiling → ~37,000 tokens/min → ~2.2M tokens/hour
- **20M tokens ≈ 9 hours of continuous maximum-rate hammering**, pinned at the
  quota the entire time

That is not a test, it is an abuse run — and the likeliest outcome is your IP
getting banned, which loses you the free access you were trying to verify. I did
not run it. The sustained tests above already answer the question.

### Tokens themselves: no cap found

Separately, per-request size is not limited in any way I could find:

| Test | Result |
|---|---|
| 150,000 character input (~37k tokens) | worked |
| Asked for 5,000 words | got **4,708 words / 6,013 tokens / 25,727 chars** |
| API key / account required | **No** |

### Bottom line

**Free, no key, no account, no per-request size limit — but roughly 10 calls per
minute sustained.** Plenty for personal agentic use. Not enough to treat as an
unlimited bulk inference backend.

Two more honest warnings:

1. **One model only.** Guests get "Brainiac"; the other 25 "free" models reply
   *"Sign up for a free account."* And Brainiac is a **router** — I watched it
   serve `Gemini 3.8 Flash`, `gpt-6-luna` and `GLM 5.3 Flash` for identical
   prompts. Your results vary day to day for reasons you can't control.
2. **They can change any of this instantly.** Undocumented private beta, no
   notice, no support. Keep one paid API configured in Kilo as a backup.

### Tuning the limit yourself

```bash
TUSK_RATE_PER_MIN=9 ./start.sh     # maximally safe, never provokes a 429
TUSK_RATE_PER_MIN=45 ./start.sh    # default: loose guard vs runaway loops
TUSK_RATE_ENABLED=0 ./start.sh     # off -- only for testing, you will get 429s
```

---

## "It keeps switching models and then Kilo breaks" — fixed

This was your complaint, and you were right that it hurts. But the diagnosis is
different from what it looks like.

### You cannot force GLM as a guest. Here's the proof.

I checked every avenue:

| Idea | Result |
|---|---|
| Request GLM 5.3 Flash directly by its GUID | **Gated** — `"Sign up for a free account to use this model."` Same for GLM 5.3 and GLM 5.2 |
| A `forceModel` / `preferredModel` / `modelSlug` parameter | **Does not exist.** I dumped the whole app bundle — 0 occurrences. The only model field is `aiModelId` |
| An API-key / developer-key feature | **None.** 0 hits for `developer key`, `personal access`, `secret key` |
| `grokproOptions` as an override | Always `null` in the app's own code |

Guests get **Brainiac only**, and Brainiac is a **server-side router** that picks
the upstream model itself. I watched it serve 12/12 `Gemini 3.8 Flash` in one
window, then 8/8 `GLM 5.3 Flash` in the next. You do not control it.

The only true pin is a free Tusk account (a Clerk JWT unlocks the direct GLM
GUID) — but those tokens expire in about 60 seconds, so a long-running bridge
would have to keep refreshing one from a browser session. Fragile, and I would
not build on it.

### So I fixed the actual symptom instead

I reproduced your bug. Six agentic prompts, and **2 came back as prose instead
of a tool call** — exactly what you saw in Kilo. But here's the surprise:

**Both failures were GLM 5.3 Flash.** Your "good" model. The model wasn't the
problem. The two real causes were:

1. It invented a tool name that doesn't exist — `{"tool": "list_dir", ...}` when
   only `read_file` / `write_to_file` / `execute_command` were offered. The old
   parser rejected it and quietly handed Kilo the raw text.
2. It **denied having tools at all**: *"I can't run shell commands or access
   tools — I'm a text-based assistant without a terminal or execute_command
   capability."* That is Tusk's injected chat persona overriding your agent's
   instructions.

Both are now handled. The parser accepts **6 formats**, not 1:

```
canonical JSON          {"tool":"read_file","arguments":{"path":"a.py"}}   -> ok
invented tool name      {"tool":"list_dir","arguments":{"path":"."}}       -> remapped to read_file
markdown-fenced JSON    ```json {...} ```                                  -> ok
buried in prose         "Sure! I'll read that. {...} Let me know!"         -> ok
function-call syntax    read_file(path="src/app.py")                       -> ok
XML tags                <read_file><path>src/app.py</path></read_file>     -> ok
```

And when a call still can't be parsed, or the model denies having tools, the
shim **retries with a corrective instruction** instead of giving up.

**Same 6 prompts, after the fix:**

```
GOOD  [GLM 5.3 Flash] tool_call  attempts=1  <- 'Read the file src/app.py'
GOOD  [GLM 5.3 Flash] tool_call  attempts=1  <- 'List the files in this directory'
GOOD  [GLM 5.3 Flash] tool_call  attempts=3  <- "Run 'ls -la'"
      healed: ['retry: denial', 'retry: denial']     <- gave up twice, then recovered
GOOD  [GLM 5.3 Flash] tool_call  attempts=1  <- 'Read config.json'
GOOD  [GLM 5.3 Flash] tool_call  attempts=1  <- 'Read the file at /app/main.py'
GOOD  [GLM 5.3 Flash] tool_call  attempts=1  <- 'Execute the command npm test'

before: 2/6 broken      after: 0/6 broken
```

That third line is the important one — it hit the denial **twice** and still
came back with a correct `execute_command` call.

### Optional: bias toward GLM anyway

```bash
SHIM_PREFER_MODEL=GLM ./start.sh
```

The shim reads which model actually served each response and retries if it isn't
GLM. **Retries are capped at 2** (3 attempts total), then it returns whatever it
got rather than failing — verified: asked to prefer an unavailable model, it used
exactly 3 attempts, 7.6s, and still returned a good answer.

⚠️ **Cost warning:** when the router is in a non-GLM window this triples your
quota use, and quota is only ~10/min. If Kilo starts feeling slow, unset it — the
parser fixes above mean you probably don't need it.

### See what's happening

```bash
curl http://127.0.0.1:8100/health
```

Returns `models_seen` (which models have actually served you), `tool_renames`,
`tool_retries`, `denial_retries`, `model_retries` and the quota guard state.
Every response also carries an `x_tusk` block with `served_model`, `attempts`,
`tool_status` and `notes` — OpenAI clients ignore it, but it tells you exactly
why a call behaved oddly.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Kilo says "Invalid API Key" | It must be exactly `tusk-local-key` (or whatever you set `SHIM_API_KEY` to) |
| Kilo says connection error | Is the black terminal window still open? The bridge must be running |
| "Fetch models" shows nothing | Bridge isn't running, or wrong Base URL. It must end in `/v1` |
| Port 8100 already in use | Run `PORT=9000 ./start.sh`, then use `http://127.0.0.1:9000/v1` in Kilo |
| Kilo shows text instead of calling a tool | Upgrade to this version — the parser now handles 6 formats and retries on denial. Check `/health` for `denial_retries`. |
| Kilo feels slow / pauses | You hit the ~10/min quota; the client is waiting out `Retry-After` on purpose. Lower concurrency or wait. |
| Answers are empty or say "Sign up for a free account" | Tusk changed which model guests can use. Run `python3 tusk_ai.py --list-models --free-only` and tell me what you see |
| It worked yesterday, not today | Tusk changed something. Run `python3 tests/run_tests.py` — it tells you exactly what broke |
| Python not found | Install from python.org. On Windows, **tick "Add python.exe to PATH"** |

### Check it's healthy any time

```bash
python3 tusk_ai.py --selftest     # is Tusk reachable and answering?
python3 tests/run_tests.py        # full 76-check test of everything
```

---

## Optional extras

**Different port or key:**
```bash
PORT=9000 SHIM_API_KEY=mysecret ./start.sh
```

**Let other computers on your network use it:**
```bash
HOST=0.0.0.0 SHIM_API_KEY=a-long-random-secret ./start.sh
```
⚠️ Only do this with a strong key. Without one, anyone who finds your machine
can use your quota and possibly get your IP banned by Tusk.

**Keep it running after you close the terminal (Mac/Linux):**
```bash
nohup ./start.sh > tusk.log 2>&1 &
```

---

## What each file does

| File | Purpose |
|---|---|
| `start.sh` / `start.bat` | Launcher. Checks Python, checks Tusk is reachable, starts the bridge |
| `openai_shim.py` | The bridge. Speaks "OpenAI" to Kilo, "Tusk" upstream |
| `tusk_ai.py` | The actual Tusk client |
| `tests/run_tests.py` | 76-check test suite. Run it when things break |
| `example_api_server.py` | Separate thing — your own REST endpoint with caching. Not needed for Kilo |
| `README.md` | The deep technical docs and all the measurements |
