#!/usr/bin/env python3
"""
openai_shim.py -- OpenAI-compatible API in front of the free Tusk endpoint.

This is what lets you attach Tusk as an AI provider in Kilo Code (or Cline, Roo
Code, Cursor, Continue, LangChain, the `openai` Python SDK -- anything that
speaks "OpenAI Compatible").

    Kilo Code  ->  POST {base}/chat/completions   ->  this shim
                 ->  GET  {base}/models                |
                                                       v
                                    tusk_ai.py -> https://new.tusksearch.com/api/V2/Chat

Stdlib only. No pip installs. Python 3.9+.

Run:
    python3 openai_shim.py                       # 0.0.0.0:8100
    PORT=8100 SHIM_API_KEY=mysecret python3 openai_shim.py

Then in Kilo Code -> Settings -> Providers -> Custom provider:
    Provider ID   : tusk-free
    Display name  : Tusk Free (Brainiac)
    Provider API  : OpenAI Compatible
    Base URL      : http://<your-host>:8100/v1
    API key       : mysecret        (or any string if SHIM_API_KEY is unset)
    Models        : click "Fetch models" -> pick "brainiac"

Implemented endpoints:
    GET  /v1/models
    POST /v1/chat/completions      (streaming SSE + non-streaming)
    POST /v1/completions           (legacy text completions)
    GET  /health

------------------------------------------------------------------------------
READ THIS BEFORE USING IT AS A CODING AGENT -- honest limitations
------------------------------------------------------------------------------
1. ONE model. Guests are locked to Tusk's "Brainiac". Every model id you send
   is routed there. The `model` field in responses is therefore a label, not a
   choice.

2. NO native tool calling -- but the emulation works better than expected.
   Tusk's request schema has no `tools` field (verified by dumping the full
   request contract), so this shim renders your tool schemas into the prompt and
   parses JSON back out into `tool_calls`.

   Measured 2026-10-29 (GLM 5.3 Flash behind Brainiac):
     - 10/10 identical tool-call requests returned the exact right call
     - 3/3 correct with a long competing Kilo-style system prompt
     - 0 false positives on 3 prompts that needed prose, not a tool
     - a full 3-step agent loop (read_file -> write_to_file -> answer) ran
       clean in 9.2s and produced a correct code fix
     - streaming tool_calls deltas are well-formed (id/type/index/function)

   Real limits: ONE tool call per reply (no parallel tool use), and it depends
   on the model obeying a JSON format that Tusk's own injected persona is
   actively working against. Treat it as "works, unguaranteed".

3. Tusk injects its OWN ~1,700-token consumer-chat system prompt that you
   cannot remove or override (there is no system field). It makes the model
   chatty and it fights your agent's formatting instructions.

4. Streaming is fake. Tusk buffers the entire response and flushes at the end
   (measured: ttfb == elapsed, always). SSE chunks arrive in one burst.

5. Latency: measured median 1.55s for short tool calls, 2-5s for normal
   answers, with an observed tail of 13.7s. An agent makes dozens of calls per
   task, so budget minutes, not seconds.

6. Non-deterministic backend. "Brainiac" is a ROUTER: it served
   google/gemini-3.8-flash, openai/gpt-6-luna and GLM 5.3 Flash across
   identical requests. The choice appears sticky within a window (10/10
   consecutive calls hit the same model) but can switch between windows. Your
   agent's format adherence can therefore change overnight with no code change
   on your side. This is the single biggest risk here.

Bottom line: works as a genuine free OpenAI-compatible provider, including for
light agentic use. It is not something to depend on for serious autonomous
coding -- the router can swap your model at any time and there is no SLA.
See README.md, section "Using it in Kilo Code".
"""

from __future__ import annotations

import difflib
import json
import os
import re
import subprocess
import sys
import urllib.request
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional, Tuple
from collections import Counter
from urllib.parse import urlparse

from tusk_ai import (TuskAI, TuskError, TuskUpstreamFailureError,
                     TuskNetworkError, TuskRateLimitError,
                     is_upstream_failure, extract_json, clean_text, get_models,
                     rate_stats, GUEST_MODEL_LABEL, __version__ as TUSK_VERSION)

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8100"))
SHIM_API_KEY = os.environ.get("SHIM_API_KEY", "")     # empty = accept any key
UPSTREAM_TIMEOUT = float(os.environ.get("UPSTREAM_TIMEOUT", "120"))
MAX_RETRIES = int(os.environ.get("SHIM_MAX_RETRIES", "1"))
WEB_SEARCH = os.environ.get("SHIM_WEB_SEARCH", "0") in ("1", "true", "yes")
TONE = os.environ.get("SHIM_TONE", "technical")

# "prompt" = render tools into the prompt and parse tool_calls back out.
# "none"   = ignore tools entirely (model just answers in prose).
TOOLS_MODE = os.environ.get("SHIM_TOOLS_MODE", "prompt")

# --- model preference -------------------------------------------------------
# Guests CANNOT pin a model: Brainiac is a server-side router, GLM's own GUID is
# signup-gated, and the bundle has no force/preferred-model parameter at all.
# What we CAN do is look at which model actually served each response (the stream
# reports it) and retry when it is not the one you want. Bounded, so a window
# that never serves your model cannot burn your whole quota.
PREFER_MODEL = os.environ.get("SHIM_PREFER_MODEL", "").strip()      # e.g. "GLM"
PREFER_MAX_RETRIES = int(os.environ.get("SHIM_PREFER_MAX_RETRIES", "2"))
# Corrective retries when the model tries to call a tool but produces something
# unparseable, invents a tool name, or claims it has no tools.
TOOL_RETRIES = int(os.environ.get("SHIM_TOOL_RETRIES", "2"))
# Retries when Tusk's routed model dies mid-generation and replies with its
# HTML error page ("<p>Something went wrong generating that response...</p>").
# Each retry uses a FRESH session; observed to recover on attempt 2-3.
UPSTREAM_RETRIES = int(os.environ.get("SHIM_UPSTREAM_RETRIES", "2"))
TOOL_FUZZY = os.environ.get("SHIM_TOOL_FUZZY", "1") not in ("0", "false", "no")

# Exposed via /v1/models. Only one real model exists for guests.
MODEL_ID = os.environ.get("SHIM_MODEL_ID", "brainiac")
MODEL_LABEL = f"{GUEST_MODEL_LABEL} (via Tusk free tier)"

_executor = ThreadPoolExecutor(max_workers=8)

# Single-file web UI served at GET /chat (same origin as the API, so the
# browser needs no CORS and no key in the URL). Loaded from disk per-mtime.
WEB_UI_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_ui.html")
_web_ui_cache = {"mtime": 0.0, "data": b""}


def _web_ui() -> bytes:
    try:
        mt = os.path.getmtime(WEB_UI_FILE)
    except OSError:
        return b""
    if mt != _web_ui_cache["mtime"]:
        with open(WEB_UI_FILE, "rb") as fh:
            _web_ui_cache["data"] = fh.read()
            _web_ui_cache["mtime"] = mt
    return _web_ui_cache["data"]
_stats = {"started": time.time(), "requests": 0, "streamed": 0, "tool_calls": 0,
          "tool_parse_failures": 0, "errors": 0,
          "tool_renames": 0, "tool_retries": 0, "model_retries": 0,
          "denial_retries": 0, "upstream_retries": 0}
_models_seen: Counter = Counter()
_pool_lock = threading.Lock()

# Reuse TuskAI instances so the on-disk model cache and resolution are shared.
def _client() -> TuskAI:
    return TuskAI(model=GUEST_MODEL_LABEL, tone=TONE if TONE in
                  {"casual", "technical", "creative", "work", "learn", "gippr"} else "casual",
                  timeout=UPSTREAM_TIMEOUT, max_retries=MAX_RETRIES, web_search=WEB_SEARCH)


# --------------------------------------------------------------------------- #
# messages[] -> a single prompt string
# --------------------------------------------------------------------------- #
# Tusk's API accepts ONE `content` string and keeps history server-side keyed by
# chatId/sessionId. An OpenAI client instead sends the entire conversation every
# request and expects the provider to be stateless. So we flatten.
#
# Deliberately explicit role tags: the injected Tusk persona makes the model
# chatty, and clear structure is the only lever we have.

def _content_to_text(content: Any) -> str:
    """OpenAI allows content to be a string OR a list of typed parts."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out = []
        for part in content:
            if isinstance(part, str):
                out.append(part)
            elif isinstance(part, dict):
                if part.get("type") == "text" and part.get("text"):
                    out.append(part["text"])
                elif part.get("type") == "image_url":
                    # Tusk guest chat accepts no images through this path.
                    out.append("[image omitted: not supported by this provider]")
                elif part.get("type") == "tool_result":
                    out.append(str(part.get("content", "")))
            else:
                out.append(str(part))
        return "\n".join(out)
    return str(content)


def flatten_messages(messages: List[Dict[str, Any]]) -> str:
    """Turn an OpenAI messages array into one prompt string."""
    if not messages:
        raise ValueError("messages is empty")

    system_parts: List[str] = []
    transcript: List[str] = []

    for m in messages:
        if not isinstance(m, dict):
            continue
        role = str(m.get("role", "user")).lower()
        text = _content_to_text(m.get("content")).strip()

        if role == "system" or role == "developer":
            if text:
                system_parts.append(text)
        elif role == "assistant":
            tcs = m.get("tool_calls") or []
            if tcs:
                calls = []
                for tc in tcs:
                    fn = (tc or {}).get("function") or {}
                    calls.append(json.dumps({"tool": fn.get("name"),
                                             "arguments": _safe_json_loads(fn.get("arguments"))},
                                            ensure_ascii=False))
                text = (text + "\n" if text else "") + "\n".join(calls)
            if text:
                transcript.append(f"[assistant]\n{text}")
        elif role == "tool" or role == "function":
            body = text or _content_to_text(m.get("tool_result"))
            transcript.append(f"[tool result for {m.get('name') or m.get('tool_call_id') or 'tool'}]\n{body}")
        else:  # user
            if text:
                transcript.append(f"[user]\n{text}")

    blocks: List[str] = []
    if system_parts:
        blocks.append("[instructions]\n" + "\n\n".join(system_parts))
    # Only include prior turns if there is more than the final user message;
    # keeps the prompt (and therefore latency) small for one-shot calls.
    if len(transcript) > 1:
        blocks.append("[conversation so far]\n" + "\n\n".join(transcript[:-1]))
        blocks.append("[your turn] Respond to this latest message:\n" + transcript[-1])
    elif transcript:
        blocks.append(transcript[0].replace("[user]\n", "", 1))
    else:
        raise ValueError("no usable message content")
    return "\n\n".join(blocks)


def _safe_json_loads(s: Any) -> Any:
    if isinstance(s, (dict, list)):
        return s
    if not isinstance(s, str):
        return s
    try:
        return json.loads(s)
    except Exception:
        return s


# --------------------------------------------------------------------------- #
# Tool calling, faked through the prompt
# --------------------------------------------------------------------------- #

_TOOL_INSTRUCTION = """
[tool use]
You can call tools. To call one, reply with ONLY a single JSON object and
absolutely no other text, no markdown fence, no explanation:
{"tool": "<tool_name>", "arguments": {<args matching that tool's schema>}}

Available tools:
{schemas}

Rules:
- Call at most ONE tool per reply.
- Use ONLY a tool name from the list above. Never invent one.
- If no tool is needed, answer normally in plain text with no JSON.
- Never wrap the JSON in backticks.
- You DO have these tools. Never claim you lack tool, file or terminal access.
""".strip()

_NUDGE = """

[correction] Your previous reply could not be used. {reason}
Reply again with ONLY this exact shape and nothing else:
{{"tool": "{example}", "arguments": {{...}}}}
Valid tool names are ONLY: {names}""".strip()

_DENIAL_RE = re.compile(
    r"(i (?:can(?:not|'t)|am unable|don'?t have|do not have|lack)|"
    r"unable to|no access|without access|"
    r"i'?m (?:just |only )?a (?:text[- ]based )?(?:ai|assistant|language model))"
    r"[^.\n]{0,120}?(tool|terminal|shell|command|file ?system|execute|browse|access)",
    re.I)

_FUNC_CALL_RE = re.compile(r"\b([a-zA-Z_][a-zA-Z0-9_]{2,40})\s*\(\s*(\{.*?\}|.*?)\s*\)",
                           re.S)
_XML_TAG_RE = re.compile(r"<\s*([a-zA-Z_][a-zA-Z0-9_\-]{2,40})\s*>(.*?)<\s*/\s*\1\s*>", re.S)


def render_tool_schemas(tools: List[Dict[str, Any]]) -> str:
    lines = []
    for t in tools or []:
        if not isinstance(t, dict):
            continue
        fn = t.get("function") or t
        name = fn.get("name")
        if not name:
            continue
        desc = (fn.get("description") or "").strip()
        params = fn.get("parameters") or fn.get("input_schema") or {}
        lines.append(f"- {name}: {desc}\n  parameters JSON schema: "
                     f"{json.dumps(params, ensure_ascii=False)[:1500]}")
    return "\n".join(lines)


def _valid_tool_names(tools: List[Dict[str, Any]]) -> List[str]:
    out = []
    for t in tools or []:
        if not isinstance(t, dict):
            continue
        fn = t.get("function") or t
        if fn.get("name"):
            out.append(str(fn["name"]))
    return out


def build_prompt_with_tools(prompt: str, tools: List[Dict[str, Any]]) -> str:
    if TOOLS_MODE != "prompt" or not tools:
        return prompt
    schemas = render_tool_schemas(tools)
    if not schemas:
        return prompt
    # NOTE: do NOT use str.format() -- the template contains literal JSON braces
    # which format() parses as replacement fields and raises KeyError.
    return f"{prompt}\n\n{_TOOL_INSTRUCTION.replace('{schemas}', schemas)}"


def _normalise_args(args: Any) -> Dict[str, Any]:
    if isinstance(args, str):
        args = _safe_json_loads(args)
    if isinstance(args, dict):
        return args
    if args is None:
        return {}
    return {"value": args}


_KWARG_RE = (r'([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*'
             r'("[^"]*"|' + r"'[^']*'" + r'|[^,]+)')


def _kwarg_string_to_dict(s: str) -> Dict[str, Any]:
    """Parse keyword-argument style tool arguments into a dict."""
    out: Dict[str, Any] = {}
    for m in re.finditer(_KWARG_RE, s):
        k = m.group(1)
        v = m.group(2).strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
            v = v[1:-1]
        out[k] = _safe_json_loads(v) if v.strip()[:1] in "[{" else v
    return out


def _closest(name: str, valid: List[str]) -> Optional[str]:
    """Map an invented tool name onto the nearest real one."""
    if not TOOL_FUZZY or not valid:
        return None
    n = name.lower().replace("-", "_")
    for v in valid:
        vl = v.lower()
        if n == vl:
            return v
    # substring either way: list_dir / read_file_path etc.
    subs = [v for v in valid if n in v.lower() or v.lower() in n]
    if len(subs) == 1:
        return subs[0]
    hits = difflib.get_close_matches(n, [v.lower() for v in valid], n=1, cutoff=0.62)
    if hits:
        return valid[[v.lower() for v in valid].index(hits[0])]
    # last resort: match on the verb (read_*, *file, exec*/run*)
    verb_map = {"read": ["read", "get", "open", "view", "cat", "list", "ls"],
                "write": ["write", "create", "save", "edit", "append"],
                "exec": ["exec", "run", "cmd", "command", "shell", "bash", "terminal"]}
    for canon, syns in verb_map.items():
        want = [v for v in valid if any(x in v.lower() for x in syns)]
        if want and any(x in n for x in syns):
            return want[0]
    return None


def looks_like_denial(text: str) -> bool:
    return bool(_DENIAL_RE.search(text or ""))


def attempted_a_tool_call(text: str, valid: List[str]) -> bool:
    """Did the model TRY to call a tool but fail the format?"""
    if not text or not valid:
        return False
    low = text.lower()
    if any(v.lower() in low for v in valid):
        if "{" in text or "(" in text:
            return True
    try:
        extract_json(text)
        return True          # it emitted JSON -- almost certainly meant a tool call
    except Exception:
        pass
    return bool(_FUNC_CALL_RE.search(text)) or bool(_XML_TAG_RE.search(text))


def parse_tool_call(text: str, tools: List[Dict[str, Any]]) -> Tuple[Optional[Dict[str, Any]], str, str]:
    """
    Extract a tool call from model output as robustly as possible.

    Returns (tool_call | None, remaining_text, status) where status is one of:
      "ok"            -> a valid call was parsed
      "renamed"       -> model invented a name; mapped to the nearest real tool
      "unknown_tool"  -> JSON was fine but the tool does not exist / cannot map
      "denial"        -> model claims it has no tools (Tusk's injected persona)
      "none"          -> plain prose, no tool call attempted
    """
    valid = _valid_tool_names(tools)
    if TOOLS_MODE != "prompt" or not valid:
        return None, text, "none"

    # --- 1. canonical JSON -------------------------------------------------
    data = None
    try:
        data = extract_json(text)
    except Exception:
        data = None

    for c in (data if isinstance(data, list) else [data]) if data is not None else []:
        if not isinstance(c, dict):
            continue
        name = c.get("tool") or c.get("name") or (c.get("function") or {}).get("name")
        if not name:
            continue
        name = str(name)
        args = c.get("arguments")
        if args is None:
            args = c.get("args") or c.get("parameters") or (c.get("function") or {}).get("arguments") or {}
        args = _normalise_args(args)
        if name in valid:
            _stats["tool_calls"] += 1
            return {"name": name, "arguments": json.dumps(args, ensure_ascii=False)}, "", "ok"
        mapped = _closest(name, valid)
        if mapped:
            _stats["tool_calls"] += 1
            _stats["tool_renames"] += 1
            return {"name": mapped,
                    "arguments": json.dumps(args, ensure_ascii=False)}, "", "renamed"
        return None, text, "unknown_tool"

    # --- 2. function-call syntax:  read_file(path="x") ---------------------
    m = _FUNC_CALL_RE.search(text)
    if m:
        cand, raw_args = m.group(1), m.group(2)
        if cand in valid or _closest(cand, valid):
            name = cand if cand in valid else _closest(cand, valid)
            args = _safe_json_loads(raw_args) if raw_args.strip().startswith("{") \
                else _kwarg_string_to_dict(raw_args)
            args = _normalise_args(args)
            _stats["tool_calls"] += 1
            _stats["tool_renames"] += 0 if name == cand else 1
            return {"name": name, "arguments": json.dumps(args, ensure_ascii=False)}, "", "renamed"

    # --- 3. XML-ish tags: <read_file><path>x</path></read_file> -------------
    for m in _XML_TAG_RE.finditer(text):
        tag, inner = m.group(1).replace("-", "_"), m.group(2)
        name = tag if tag in valid else _closest(tag, valid)
        if not name:
            continue
        args: Dict[str, Any] = {}
        for sm in _XML_TAG_RE.finditer(inner):
            args[sm.group(1)] = sm.group(2).strip()
        if not args and inner.strip():
            args = {"value": inner.strip()}
        _stats["tool_calls"] += 1
        return {"name": name, "arguments": json.dumps(args, ensure_ascii=False)}, "", "renamed"

    # --- 4. model denies having tools --------------------------------------
    if looks_like_denial(text):
        return None, text, "denial"

    # --- 5. it tried but we could not parse it -----------------------------
    if attempted_a_tool_call(text, valid):
        return None, text, "unknown_tool"

    _stats["tool_parse_failures"] += 1
    return None, text, "none"


def model_matches_preferred(actual: Optional[str]) -> bool:
    if not PREFER_MODEL or not actual:
        return True
    return PREFER_MODEL.lower() in str(actual).lower()


# --------------------------------------------------------------------------- #
# OpenAI response shaping
# --------------------------------------------------------------------------- #

def _cmpl_id() -> str:
    return "chatcmpl-" + uuid.uuid4().hex[:24]


def apply_stop(text: str, stop: Any) -> str:
    if not stop:
        return text
    seqs = stop if isinstance(stop, list) else [stop]
    cut = len(text)
    for s in seqs:
        if isinstance(s, str) and s:
            i = text.find(s)
            if i != -1:
                cut = min(cut, i)
    return text[:cut]


def make_completion(resp, model: str, text: str, tool_call: Optional[Dict[str, Any]],
                    created: int, cid: str) -> Dict[str, Any]:
    message: Dict[str, Any] = {"role": "assistant", "content": text or None}
    finish = "stop"
    if tool_call:
        message["tool_calls"] = [{
            "id": "call_" + uuid.uuid4().hex[:20],
            "type": "function",
            "function": {"name": tool_call["name"], "arguments": tool_call["arguments"]},
        }]
        message["content"] = text or None
        finish = "tool_calls"
    usage = {
        "prompt_tokens": resp.prompt_tokens or 0,
        "completion_tokens": resp.completion_tokens or max(1, len(text) // 4),
        "total_tokens": (resp.prompt_tokens or 0) + (resp.completion_tokens or max(1, len(text) // 4)),
    }
    return {
        "id": cid, "object": "chat.completion", "created": created, "model": model,
        "choices": [{"index": 0, "message": message, "finish_reason": finish,
                     "logprobs": None}],
        "usage": usage,
        # Non-standard, ignored by OpenAI clients but useful when debugging:
        "x_tusk": {"upstream_model": resp.model_name or resp.model,
                   "generation_ms": resp.generation_ms, "elapsed_s": resp.elapsed_s,
                   "chat_id": resp.chat_id, "session_id": resp.session_id},
    }


def chunk(cid: str, created: int, model: str, delta: Dict[str, Any],
          finish: Optional[str] = None, usage: Optional[Dict[str, Any]] = None,
          x_tusk: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    out = {"id": cid, "object": "chat.completion.chunk", "created": created,
           "model": model, "choices": [{"index": 0, "delta": delta,
                                        "finish_reason": finish, "logprobs": None}]}
    if usage is not None:
        out["usage"] = usage
    # Non-standard extra key on the FINAL chunk: ignored by OpenAI clients,
    # read by our own web UI (/chat) to show which upstream model answered.
    if x_tusk is not None:
        out["x_tusk"] = x_tusk
    return out


# --------------------------------------------------------------------------- #
# Core handler
# --------------------------------------------------------------------------- #

def do_chat_completion(body: Dict[str, Any]) -> Tuple[int, Dict[str, Any], Optional[List[Dict[str, Any]]]]:
    """
    Returns (http_status, non_streaming_response_or_error, sse_events_or_None).

    Contains a bounded self-healing loop. Four things go wrong with a routed,
    non-deterministic backend and all four are recoverable:
      1. the model invents a tool name or emits an unparseable call
      2. the model denies it has tools (Tusk's injected persona leaks through)
      3. the router served a model other than the one you prefer
      4. the routed model dies mid-generation and Tusk replies with its HTML
         error page ("<p>Something went wrong generating...</p>") -- retried
         with a fresh session, never leaked to the client as an "answer"
    Each gets a corrective retry; every retry is capped so a bad window cannot
    burn your whole quota.
    """
    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        return 400, _err("invalid_request_error", "'messages' must be a non-empty array"), None

    try:
        base_prompt = flatten_messages(messages) + "\n\n" + MANIFEST
    except Exception as e:
        return 400, _err("invalid_request_error", f"could not flatten messages: {e}"), None

    tools = body.get("tools") if isinstance(body.get("tools"), list) else []
    tool_choice = body.get("tool_choice")
    if tool_choice == "none":
        tools = []
    valid_names = _valid_tool_names(tools)
    web_names = {t["function"]["name"] for t in _AGENT_TOOLS if t["function"]["name"] in WEB_TOOL_NAMES}
    offer_tools = tools + [t for t in _AGENT_TOOLS if t["function"]["name"] in web_names]
    prompt = build_prompt_with_tools(base_prompt, offer_tools)

    stream = bool(body.get("stream"))
    stop = body.get("stop")
    model_requested = str(body.get("model") or MODEL_ID)

    _stats["requests"] += 1
    if stream:
        _stats["streamed"] += 1

    ai = _client()
    r = None
    text = ""
    tool_call = None
    status = "none"
    notes: List[str] = []
    attempts = 0
    max_attempts = 1 + max(TOOL_RETRIES if tools else 0,
                           PREFER_MAX_RETRIES if PREFER_MODEL else 0,
                           UPSTREAM_RETRIES)
    current_prompt = prompt

    def _upstream_fail(detail: str):
        """Tusk's routed model died mid-generation. Retry with a FRESH session
        (a stuck session tends to keep failing); when the budget is spent,
        return an honest 502 instead of leaking Tusk's HTML error page."""
        _stats["errors"] += 1
        if attempts < max_attempts:
            _stats["upstream_retries"] += 1
            notes.append(f"retry {attempts + 1}: upstream generation failure, fresh session")
            ai.reset()
            time.sleep(min(2.0, 0.6 * attempts))
            return None
        return (502, _err("upstream_error",
                          f"Tusk's backend failed to generate an answer "
                          f"{attempts}x in a row (their routed model died -- not "
                          f"this bridge, not your prompt). Last: {detail[:220]}"))

    while attempts < max_attempts:
        attempts += 1
        try:
            r = ai.ask(current_prompt)
        except TuskUpstreamFailureError as e:
            fail = _upstream_fail(str(e))
            if fail is None:
                continue
            return fail[0], fail[1], None
        except TuskError as e:
            _stats["errors"] += 1
            code = 429 if e.exit_code == 6 else (502 if e.exit_code in (3, 4, 5) else 400)
            return code, _err("upstream_error", str(e)), None
        except Exception as e:  # noqa: BLE001
            _stats["errors"] += 1
            return 500, _err("internal_error", f"{type(e).__name__}: {e}"), None

        served = r.model_name or r.model
        if served:
            _models_seen[str(served)] += 1

        raw_text = clean_text(r.text)
        # Defense in depth: if Tusk's HTML error page slipped through as the
        # "answer" (it sometimes arrives as ordinary stream content), treat it
        # exactly like a raised upstream failure.
        if is_upstream_failure(raw_text):
            fail = _upstream_fail(raw_text)
            if fail is None:
                continue
            return fail[0], fail[1], None
        tool_call, text, status = parse_tool_call(raw_text, offer_tools)
        if tool_call is not None and tool_call.get("name") in web_names:
            # the model chose a web tool on its own (normal chat included):
            # execute it server-side and let the model keep reasoning
            for _w in range(6):
                obs = run_agent_tool(tool_call)
                notes.append("web: " + str(tool_call.get("name")))
                current_prompt += ("\n\n[observation from " + str(tool_call.get("name"))
                                   + "]:\n" + obs[:4000] + "\n\nContinue toward the answer.")
                time.sleep(3.5)
                r = ai.ask(current_prompt)
                served = r.model_name or r.model
                if served:
                    _models_seen[str(served)] += 1
                raw_text = clean_text(r.text)
                tool_call, text, status = parse_tool_call(raw_text, offer_tools)
                if tool_call is None or tool_call.get("name") not in web_names:
                    break
            else:
                tool_call = None
        if tool_call is not None and tool_call.get("name") in web_names:
            tool_call = None          # web budget spent: answer with what we have
        if tool_call is not None and not tools:
            tool_call = None          # no client tools expected: never leak tool_calls

        # --- retry 1: wrong model served ---------------------------------
        if (PREFER_MODEL and not model_matches_preferred(served)
                and attempts <= PREFER_MAX_RETRIES):
            _stats["model_retries"] += 1
            notes.append(f"retry: router served {served!r}, wanted {PREFER_MODEL!r}")
            continue

        # --- retry 2: tool call was malformed / denied --------------------
        if tools and tool_call is None and status in ("denial", "unknown_tool") \
                and attempts < max_attempts:
            _stats["tool_retries"] += 1
            if status == "denial":
                _stats["denial_retries"] += 1
                reason = ("You DO have tools available. Do not say you lack tool, "
                          "file, terminal or command access.")
            else:
                reason = ("Your tool name or JSON was invalid. Use only a name from "
                          "the list below, and emit raw JSON with no other text.")
            example = valid_names[0] if valid_names else "tool_name"
            _stats["tool_parse_failures"] += 1
            current_prompt = (prompt + _NUDGE.replace("{reason}", reason)
                              .replace("{example}", example)
                              .replace("{names}", ", ".join(valid_names)))
            notes.append(f"retry: {status}")
            continue

        if status == "renamed":
            notes.append("tool name was invented by the model and mapped to the "
                         "nearest valid tool")
        break

    if r is None:
        return 502, _err("upstream_error", "no upstream response"), None

    text = apply_stop(text, stop)
    created = int(time.time())
    cid = _cmpl_id()
    model_out = model_requested or MODEL_ID

    if not stream:
        out = make_completion(r, model_out, text, tool_call, created, cid)
        out["x_tusk"]["served_model"] = r.model_name or r.model
        out["x_tusk"]["tool_status"] = status
        out["x_tusk"]["attempts"] = attempts
        if notes:
            out["x_tusk"]["notes"] = notes
        return 200, out, None

    meta = {"served_model": r.model_name or r.model, "attempts": attempts,
            "generation_ms": r.generation_ms, "elapsed_s": r.elapsed_s,
            "tool_status": status if tools else None,
            "notes": notes or None}
    events: List[Dict[str, Any]] = [chunk(cid, created, model_out, {"role": "assistant", "content": ""})]
    if tool_call:
        events.append(chunk(cid, created, model_out, {
            "tool_calls": [{
                "index": 0, "id": "call_" + uuid.uuid4().hex[:20], "type": "function",
                "function": {"name": tool_call["name"], "arguments": tool_call["arguments"]},
            }]}, finish="tool_calls", x_tusk=meta))
    else:
        for piece in _split_for_stream(text):
            events.append(chunk(cid, created, model_out, {"content": piece}))
        events.append(chunk(cid, created, model_out, {}, finish="stop", x_tusk=meta))

    include_usage = bool((body.get("stream_options") or {}).get("include_usage"))
    if include_usage:
        events.append(chunk(cid, created, model_out, {}, finish="stop", usage={
            "prompt_tokens": r.prompt_tokens or 0,
            "completion_tokens": r.completion_tokens or 0,
            "total_tokens": (r.prompt_tokens or 0) + (r.completion_tokens or 0),
        }))
    return 200, {"_stream_model": model_out}, events


def _split_for_stream(text: str, size: int = 60) -> List[str]:
    if not text:
        return []
    return [text[i:i + size] for i in range(0, len(text), size)]


def _err(kind: str, message: str, param: Optional[str] = None) -> Dict[str, Any]:
    return {"error": {"message": message, "type": kind, "param": param, "code": None}}


def do_models() -> Dict[str, Any]:
    created = int(time.time())
    data = [{
        "id": MODEL_ID, "object": "model", "created": created,
        "owned_by": "tusksearch",
        "label": MODEL_LABEL,
        # Hints some clients read; harmless to others.
        "context_window": 32000,
        "supports_tools": TOOLS_MODE == "prompt",
        "supports_streaming": True,
    }]
    # Also advertise the upstream names so users can see what's really serving.
    return {"object": "list", "data": data}


# --------------------------------------------------------------------------- #
# HTTP server
# --------------------------------------------------------------------------- #

class Handler(BaseHTTPRequestHandler):
    server_version = f"tusk-openai-shim/{TUSK_VERSION}"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        print(f"{self.address_string()} {fmt % args}", flush=True)

    # -- helpers ---------------------------------------------------------- #
    def _json(self, code: int, obj: Dict[str, Any]) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")

    def _authed(self) -> bool:
        if not SHIM_API_KEY:
            return True
        h = self.headers.get("Authorization", "")
        if h.startswith("Bearer ") and h[7:].strip() == SHIM_API_KEY:
            return True
        # some clients send x-api-key instead
        return self.headers.get("x-api-key", "") == SHIM_API_KEY

    # -- routes ----------------------------------------------------------- #
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path.rstrip("/") or "/"
        if path == "/favicon.ico":
            # desktop/webview clients fetch this without auth; answer quietly
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self._cors()
            self.end_headers()
            return
        if path in ("/chat", "/index.html"):
            data = _web_ui()
            if not data:
                return self._json(404, _err("not_found",
                                            "web UI missing: put web_ui.html next to openai_shim.py"))
            # Same-origin convenience: bake the server's key into the page so
            # /chat works with zero popups. Turn off with SHIM_WEB_EMBED_KEY=0
            # if the site will be reachable by strangers.
            embed = os.environ.get("SHIM_WEB_EMBED_KEY", "1") not in ("0", "false", "no")
            key_b = (SHIM_API_KEY.encode() if (embed and SHIM_API_KEY) else b"")
            data = data.replace(b"__TUSK_WEB_KEY__", key_b)
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-cache")
            self._cors()
            self.end_headers()
            self.wfile.write(data)
            return
        if path in ("/health", "/", "/v1"):
            return self._json(200, {"ok": True, "shim": TUSK_VERSION,
                                    "model": MODEL_ID, "tools_mode": TOOLS_MODE,
                                    "agent": bool(AGENT_TOKEN),
                                    "workspace_git": bool(GITHUB_REPO and GITHUB_PAT),
                                    "uptime_s": round(time.time() - _stats["started"], 1),
                                    "upstream_quota": rate_stats(),
                                    "models_seen": dict(_models_seen),
                                    "prefer_model": PREFER_MODEL or None, **_stats})
        if not self._authed():
            return self._json(401, _err("authentication_error", "invalid or missing API key"))
        if path.startswith("/v1/agent/jobs/") and path.endswith("/continue"):
            if self.headers.get("x-agent-token", "") != AGENT_TOKEN or not AGENT_TOKEN:
                return self._json(404, _err("not_found", "agent disabled"))
            jid = path.split("/")[-2]
            job = JOBS.get(jid)
            if not job:
                return self._json(404, _err("not_found", "unknown job"))
            msg = str(body.get("message") or "").strip()
            if not msg:
                return self._json(400, _err("invalid_request_error", "'message' required"))
            if job["status"] == "running":
                return self._json(409, _err("conflict", "job still running"))
            job["task"] += (f"\n\n[previous result]\n{str(job.get('result'))[:1500]}"
                            f"\n\nFOLLOW-UP FROM USER: {msg}")
            job["status"] = "queued"
            job["result"] = ""
            _jobs_save()
            threading.Thread(target=_run_job, args=(jid,), daemon=True).start()
            return self._json(200, {"id": jid, "status": "queued"})
        if path in ("/v1/agent/jobs", "/agent/jobs"):
            lst = [{"id": j["id"], "task": j["task"][:120], "status": j["status"],
                    "steps": len(j.get("steps", [])), "created": j.get("created")}
                   for j in sorted(JOBS.values(), key=lambda x: x.get("created") or 0, reverse=True)]
            return self._json(200, {"jobs": lst})
        if path.startswith("/v1/agent/jobs/") or path.startswith("/agent/jobs/"):
            jid = path.rsplit("/", 1)[-1]
            job = JOBS.get(jid)
            if not job:
                return self._json(404, _err("not_found", "unknown job"))
            return self._json(200, job)
        if path in ("/v1/workspace/files", "/workspace/files"):
            folder = urlparse(self.path).query
            import urllib.parse as _up
            rel = _up.parse_qs(folder).get("folder", ["."])[0]
            try:
                root = _ws_path(rel)
            except ValueError as e:
                return self._json(400, _err("invalid_request_error", str(e)))
            items = []
            for dp, _dn, fn in os.walk(root):
                for f in sorted(fn):
                    fp = os.path.join(dp, f)
                    items.append({"path": os.path.relpath(fp, root).replace(os.sep, "/"),
                                  "size": os.path.getsize(fp)})
                    if len(items) >= 200:
                        break
            return self._json(200, {"folder": rel, "files": items})
        if path in ("/v1/workspace/file", "/workspace/file"):
            import urllib.parse as _up
            rel = _up.parse_qs(urlparse(self.path).query).get("path", [""])[0]
            try:
                fp = _ws_path(rel)
                txt = open(fp, encoding="utf-8", errors="replace").read()[:20000]
            except ValueError as e:
                return self._json(400, _err("invalid_request_error", str(e)))
            except Exception as e:  # noqa: BLE001
                return self._json(404, _err("not_found", str(e)[:200]))
            import urllib.parse as _up2
            if _up2.parse_qs(urlparse(self.path).query).get("raw") == ["1"]:
                data = open(fp, "rb").read()
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Disposition",
                                 f'attachment; filename="{os.path.basename(fp)}"')
                self.send_header("Content-Length", str(len(data)))
                self._cors()
                self.end_headers()
                self.wfile.write(data)
                return None
            return self._json(200, {"path": rel, "content": txt})
        if path in ("/v1/memory", "/memory"):
            return self._json(200, {"memory": memory_text()})
        if path in ("/v1/models", "/models"):
            return self._json(200, do_models())
        if path in ("/v1/models/" + MODEL_ID, "/models/" + MODEL_ID):
            return self._json(200, do_models()["data"][0])
        return self._json(404, _err("not_found", f"unknown path {path!r}; try /v1/models"))

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/") or "/"

        # ALWAYS drain the request body first, before auth/routing decisions.
        # Keep-alive clients (the Kilo desktop app reuses sockets) would else
        # get our early 401/404 reply while the body bytes stay unread in the
        # socket, glued onto the NEXT request on the same connection:
        #   '{"model": ...}GET /v1 HTTP/1.1'  ->  400 garbage.
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n > 20_000_000:
            self.close_connection = True   # not draining 20 MB; drop the socket
            return self._json(413, _err("invalid_request_error", "body too large"))
        raw = self.rfile.read(n) if n else b"{}"

        if not self._authed():
            return self._json(401, _err("authentication_error", "invalid or missing API key"))

        try:
            body = json.loads(raw or b"{}")
            if not isinstance(body, dict):
                raise ValueError("body must be a JSON object")
        except Exception as e:
            return self._json(400, _err("invalid_request_error", f"invalid JSON body: {e}"))

        # Tolerant routing: some clients (Kilo desktop app) POST the chat
        # payload to the BASE URL itself (/v1 or even /) instead of
        # /v1/chat/completions. If the body looks like a chat request,
        # accept it wherever it landed.
        if path in ("/v1/agent/jobs", "/agent/jobs"):
            if self.headers.get("x-agent-token", "") != AGENT_TOKEN or not AGENT_TOKEN:
                return self._json(404, _err("not_found", "agent disabled"))
            task = str(body.get("task") or "").strip()
            if not task:
                return self._json(400, _err("invalid_request_error", "'task' required"))
            jid = start_job(task)
            return self._json(200, {"id": jid, "status": "queued"})
        if path in ("/v1/memory", "/memory"):
            content = body.get("content")
            if not isinstance(content, str):
                return self._json(400, _err("invalid_request_error", "'content' string required"))
            os.makedirs(WORKSPACE_DIR, exist_ok=True)
            open(MEMORY_FILE, "w", encoding="utf-8").write(content)
            git_sync("memory update")
            return self._json(200, {"ok": True, "bytes": len(content)})
        if path == "/v1/agent/completions" or path == "/agent/completions":
            return self._agent(body)
        if path not in ("/v1/chat/completions", "/chat/completions",
                        "/v1/completions", "/completions"):
            if "messages" in body:
                path = "/v1/chat/completions"
            elif "prompt" in body:
                path = "/v1/completions"
            else:
                return self._json(404, _err("not_found", f"unknown path {path!r}"))

        # legacy /v1/completions: {"prompt": "..."} -> treat as a single user msg
        if path.endswith("/completions") and not path.endswith("/chat/completions"):
            p = body.get("prompt")
            if isinstance(p, list):
                p = "\n".join(map(str, p))
            body = {**body, "messages": [{"role": "user", "content": str(p or "")}]}

        try:
            code, obj, events = do_chat_completion(body)
        except Exception as e:  # noqa: BLE001 -- keep the socket usable
            _stats["errors"] += 1
            import traceback; traceback.print_exc()
            return self._json(500, _err("internal_error", f"{type(e).__name__}: {e}"))
        if events is None:
            return self._json(code, obj)
        try:
            return self._stream_sse(events)
        except Exception as e:  # noqa: BLE001
            _stats["errors"] += 1
            import traceback; traceback.print_exc()
            try:
                return self._json(500, _err("internal_error", f"stream failed: {e}"))
            except Exception:
                return None

    # -- server-side agent: Cowork inside the normal chat --------------- #
    def _agent(self, body: Dict[str, Any]):
        if not AGENT_TOKEN or self.headers.get("x-agent-token", "") != AGENT_TOKEN:
            return self._json(404, _err("not_found",
                                        "agent endpoint disabled (server: set SHIM_AGENT_TOKEN)"))
        messages = body.get("messages")
        if not isinstance(messages, list) or not messages:
            return self._json(400, _err("invalid_request_error", "'messages' must be a non-empty array"))
        stream = bool(body.get("stream"))
        os.makedirs(WORKSPACE_DIR, exist_ok=True)
        # --- per-chat folder: each conversation is jailed to its own dir ---
        chat = body.get("chat") if isinstance(body.get("chat"), dict) else {}
        cid = str(chat.get("id") or "general")[-8:] or "general"
        slug = re.sub(r"[^a-z0-9]+", "-", str(chat.get("title") or "chat").lower()).strip("-")[:40] or "chat"
        root = os.path.realpath(os.path.join(WORKSPACE_DIR, "chats", f"{slug}-{cid}"))
        os.makedirs(root, exist_ok=True)
        ai = _client()
        cid = "agent-" + uuid.uuid4().hex[:20]
        created = int(time.time())
        mem = memory_text()[-3000:]
        web_only = bool(body.get("web_only"))
        tools = [t for t in _AGENT_TOOLS if t["function"]["name"] in WEB_TOOL_NAMES] if web_only else _AGENT_TOOLS
        prompt = build_prompt_with_tools(flatten_messages(messages), tools)
        if mem.strip():
            prompt += ("\n\nLONG-TERM MEMORY (shared across all chats, durable):\n" + mem)
        prompt += MANIFEST
        prompt += ("\n\nAGENT MODE: you control a real server workspace. Work in steps: "
                   "write_file to create scripts, run_python/run_shell to execute them, read the "
                   "observations, fix and re-run until the task is genuinely done, then give the "
                   "final answer. Keep files in the workspace; push with github_push when available."
                   f"\nYour HOME folder for THIS conversation is '{os.path.relpath(root, WORKSPACE_DIR)}/' "
                   "(run_python/run_shell already start inside it — never `cd chats/...`). "
                   "File tools may also read/write the SHARED workspace root (for caches like jdk/, sdk/, "
                   "datasets) but keep each conversation's deliverables inside its own folder. "
                   "Never write interactive stdin scripts; prefer write_file then run_shell on the file. "
                   "For files bigger than ~3000 chars, split into write_file calls with append=true. "
                   "INSTALLING THINGS: `pip install --user <pkg>` works out of the box (packages land in "
                   "the workspace .local). You may install anything else too (curl static binaries, npm, "
                   "compile). Whenever you pip-install a package the task depends on, ALSO append it to "
                   "agent_requirements.txt (one per line) so future server redeploys keep it.")
        messages = compact_messages(messages)
        steps: List[Dict[str, Any]] = []
        final = ""
        served = None
        if stream:
            self._sse_begin()

        detached = {"flag": False}

        def emit(step: Dict[str, Any]) -> None:
            if stream and not detached["flag"]:
                try:
                    self._sse_ev({"x_tusk_step": step})
                except (BrokenPipeError, ConnectionResetError):
                    detached["flag"] = True   # user closed the tab: keep working in background

        try:
            task_txt = str((messages[-1] or {}).get('content') or '')[:2000]
            final, steps, served = _agent_core(ai, prompt, root,
                                           AGENT_MAX_STEPS if not web_only else 4,
                                           emit, 0, task=task_txt, tools=tools,
                                           verify=not body.get("chat_only"))
        except TuskError as e:
            if stream:
                self._sse_ev({"x_tusk_step": {"i": len(steps) + 1, "tool": "error",
                                             "args": "", "result": str(e)[:300]}})
                self._sse_end()
                return None
            return self._json(502, _err("upstream_error", str(e)[:300]))
        if detached["flag"]:
            jid = uuid.uuid4().hex
            JOBS[jid] = {"id": jid, "status": "running",
                         "task": task_txt + "  [auto-continued in background after client disconnect]",
                         "steps": steps, "created": time.time(), "result": ""}
            _jobs_save()
            threading.Thread(target=_run_job, args=(jid,), daemon=True).start()
            return None
        if GITHUB_REPO and GITHUB_PAT:
            try:
                git_sync("session end")
            except Exception:  # noqa: BLE001
                pass
        meta = {"served_model": served, "attempts": 1, "agent": True,
                "steps": len(steps), "step_log": steps,
                "chat_folder": os.path.relpath(root, WORKSPACE_DIR).replace(os.sep, "/")}
        if not stream:
            from types import SimpleNamespace
            fake = SimpleNamespace(chat_id=None, session_id=None, model=MODEL_ID,
                                   model_name=served, prompt_tokens=0,
                                   completion_tokens=len(final) // 4, elapsed_s=0.0,
                                   generation_ms=0)
            out = make_completion(fake, MODEL_ID, final, None, created, cid)
            out["x_tusk"] = meta
            return self._json(200, out)
        self._sse_ev(chunk(cid, created, MODEL_ID, {"role": "assistant", "content": ""}))
        for piece in _split_for_stream(final):
            self._sse_ev(chunk(cid, created, MODEL_ID, {"content": piece}))
        self._sse_ev(chunk(cid, created, MODEL_ID, {}, finish="stop", x_tusk=meta))
        self._sse_end()
        return None

    def _sse_begin(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "keep-alive")
        self.send_header("Transfer-Encoding", "chunked")
        self.send_header("X-Accel-Buffering", "no")   # tell nginx not to buffer
        self._cors()
        self.end_headers()

    def _sse_ev(self, ev: Dict[str, Any]) -> None:
        payload = f"data: {json.dumps(ev, ensure_ascii=False)}\n\n".encode("utf-8")
        self.wfile.write(f"{len(payload):X}\r\n".encode() + payload + b"\r\n")
        self.wfile.flush()

    def _sse_end(self) -> None:
        done = b"data: [DONE]\n\n"
        self.wfile.write(f"{len(done):X}\r\n".encode() + done + b"\r\n")
        self.wfile.write(b"0\r\n\r\n")
        self.wfile.flush()

    def _stream_sse(self, events: List[Dict[str, Any]]) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "keep-alive")
        self.send_header("Transfer-Encoding", "chunked")
        self.send_header("X-Accel-Buffering", "no")   # tell nginx not to buffer
        self._cors()
        self.end_headers()
        try:
            for ev in events:
                payload = f"data: {json.dumps(ev, ensure_ascii=False)}\n\n".encode("utf-8")
                self.wfile.write(f"{len(payload):X}\r\n".encode() + payload + b"\r\n")
                self.wfile.flush()
            done = b"data: [DONE]\n\n"
            self.wfile.write(f"{len(done):X}\r\n".encode() + done + b"\r\n")
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass  # client disconnected mid-stream; nothing useful to do


class QuietThreadingHTTPServer(ThreadingHTTPServer):
    """ThreadingHTTPServer that does not spam tracebacks when clients
    drop pooled/keep-alive sockets without sending a request.

    Kilo Code (and most HTTP clients) reuse or abandon connections from a
    pool; on Windows that surfaces as ConnectionResetError [WinError 10054]
    inside socketserver's default handle_error(). These are harmless --
    log one compact line instead of a 20-line traceback.
    """

    _BENIGN = (ConnectionResetError, BrokenPipeError, ConnectionAbortedError,
               TimeoutError, OSError)

    def handle_error(self, request, client_address):
        import traceback as _tb
        exc = sys.exc_info()[1]
        if isinstance(exc, self._BENIGN):
            name = type(exc).__name__
            win = getattr(exc, "winerror", None)
            tag = f"{name} {win}" if win else name
            print(f"[info] client at {client_address[0] if client_address else '?'} "
                  f"closed connection early ({tag}) -- harmless, ignored", flush=True)
            return
        # Anything genuinely unexpected still gets the full traceback.
        _tb.print_exception(*sys.exc_info())


_LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1", ""}


# --------------------------------------------------------------------------- #
# Server-side agent (Cowork-in-chat): tools execute ON THIS SERVER, workspace
# persisted to a GitHub repo when GITHUB_REPO + GITHUB_PAT are set.
# Gated by SHIM_AGENT_TOKEN (never embedded in the web page).
# --------------------------------------------------------------------------- #

AGENT_TOKEN = os.environ.get("SHIM_AGENT_TOKEN", "")
AGENT_MAX_STEPS = int(os.environ.get("SHIM_AGENT_MAX_STEPS", "24"))  # 0 = unlimited (capped 400)
AGENT_STEP_TIMEOUT = float(os.environ.get("SHIM_AGENT_STEP_TIMEOUT", "120"))
GITHUB_REPO = os.environ.get("GITHUB_REPO", "").strip()      # owner/repo or full URL
GITHUB_PAT = os.environ.get("GITHUB_PAT", "").strip()
WORKSPACE_DIR = os.path.realpath(os.environ.get("SHIM_WORKSPACE_DIR",
                                                  os.path.join(os.path.dirname(
                                                      os.path.abspath(__file__)), "agent_workspace")))

_AGENT_TOOLS = [
    {"type": "function", "function": {"name": "run_python", "description":
        "Run a Python script (source code) on the server in the persistent workspace. "
        "Returns stdout+stderr. Timeout %ds." % int(AGENT_STEP_TIMEOUT),
        "parameters": {"type": "object", "properties": {"code": {"type": "string"}}, "required": ["code"]}}},
    {"type": "function", "function": {"name": "run_shell", "description":
        "Run a shell command in the persistent workspace (ls, cat, pip --user etc). Returns output.",
        "parameters": {"type": "object", "properties": {"command": {"type": "string"}}, "required": ["command"]}}},
    {"type": "function", "function": {"name": "write_file", "description":
        "Create/overwrite a text file inside the workspace (relative path). "
        "For files longer than ~3000 chars, write the first chunk then call again "
        "with append=true for each following chunk.",
        "parameters": {"type": "object",
                       "properties": {"path": {"type": "string"}, "content": {"type": "string"},
                                      "append": {"type": "boolean"}},
                       "required": ["path", "content"]}}},
    {"type": "function", "function": {"name": "read_file", "description":
        "Read a text file from the workspace (relative path).",
        "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "list_dir", "description":
        "List files in a workspace directory (relative path, default '.').",
        "parameters": {"type": "object", "properties": {"path": {"type": "string"}}}}},
]
if GITHUB_REPO and GITHUB_PAT:
    _AGENT_TOOLS.append({"type": "function", "function": {"name": "github_push", "description":
        "Commit and push the whole workspace to the linked GitHub repo (persists it forever).",
        "parameters": {"type": "object", "properties": {"message": {"type": "string"}}}}})
_AGENT_TOOLS.append({"type": "function", "function": {"name": "spawn_subtask", "description":
    "Delegate a self-contained sub-goal to a fresh sub-agent (own step budget). "
    "Use it to keep the main context small on large tasks. Returns the sub-agent's final report.",
    "parameters": {"type": "object", "properties": {"task": {"type": "string"}}, "required": ["task"]}}})
_VALID_AGENT_NAMES = {t["function"]["name"] for t in _AGENT_TOOLS}
MEMORY_FILE = os.path.join(WORKSPACE_DIR, "MEMORY.md")


def memory_text() -> str:
    try:
        return open(MEMORY_FILE, encoding="utf-8", errors="replace").read()
    except OSError:
        return ""


_AGENT_TOOLS.append({"type": "function", "function": {"name": "memory_add", "description":
    "Append a durable note to LONG-TERM MEMORY (MEMORY.md, synced to GitHub, shared "
    "across all chats and restarts). Use for preferences, facts, decisions.",
    "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}})
_AGENT_TOOLS.append({"type": "function", "function": {"name": "memory_show", "description":
    "Read the current long-term memory.", "parameters": {"type": "object", "properties": {}}}})
_AGENT_TOOLS.append({"type": "function", "function": {"name": "web_search", "description":
    "Search the web (keyless multi-engine). Returns titles + URLs. Use for facts, "
    "news, docs, anything after your cutoff.",
    "parameters": {"type": "object", "properties": {"query": {"type": "string"},
        "count": {"type": "integer", "description": "results wanted, up to 25 (default 10)"}},
        "required": ["query"]}}})
_AGENT_TOOLS.append({"type": "function", "function": {"name": "web_extract", "description":
    "Fetch a URL and return its readable text (markdown via reader relay).",
    "parameters": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}}})
_VALID_AGENT_NAMES = {t["function"]["name"] for t in _AGENT_TOOLS}
WEB_TOOL_NAMES = {"web_search", "web_extract"}

_TOOL_CALL_XML_RE = re.compile(
    r"<tool_call>\s*([\w-]+)\s*((?:<arg_key>([\s\S]*?)</arg_key>\s*<arg_value>([\s\S]*?)</arg_value>\s*)*)</tool_call>",
    re.I)
_ARG_KV_RE = re.compile(
    r"<arg_key>([\s\S]*?)</arg_key>\s*<arg_value>([\s\S]*?)</arg_value>",
    re.I)


def _normalize_tool_call_xml(text: str) -> Optional[Dict[str, Any]]:
    """Salvage models that emit the tool_call XML dialect instead of JSON."""
    m = _TOOL_CALL_XML_RE.search(text or "")
    if not m:
        return None
    name = m.group(1).replace("-", "_")
    if name not in _VALID_AGENT_NAMES:
        return None
    args = {k.strip(): v for k, v in _ARG_KV_RE.findall(m.group(2) or "")}
    return {"name": name, "arguments": json.dumps(args, ensure_ascii=False)}



def _ws_path(rel: str, root: str = WORKSPACE_DIR) -> str:
    q = os.path.realpath(os.path.join(root, rel or "."))
    if q != root and not q.startswith(root + os.sep):
        raise ValueError(f"path escapes this chat's folder: {rel!r}")
    return q


def _clean_env() -> Dict[str, str]:
    """Scrubbed env for agent subprocesses: NO secrets (PAT/keys) leak in."""
    ub = os.path.join(WORKSPACE_DIR, ".local")
    return {"PATH": ub + "/bin:/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/sbin",
            "HOME": WORKSPACE_DIR, "PYTHONUNBUFFERED": "1", "TMPDIR": WORKSPACE_DIR,
            "PIP_BREAK_SYSTEM_PACKAGES": "1", "PIP_USER": "1", "PYTHONUSERBASE": ub}


def _git(args: List[str]) -> str:
    out = subprocess.run(["git"] + args, cwd=WORKSPACE_DIR, capture_output=True,
                         text=True, timeout=120, env={**os.environ, "GIT_TERMINAL_PROMPT": "0"})
    return (out.stdout + out.stderr)[-2000:]


def git_sync(reason: str = "auto sync") -> Optional[str]:
    """Clone once, then commit+push any workspace changes. Returns log or None."""
    if not (GITHUB_REPO and GITHUB_PAT):
        return None
    try:
        os.makedirs(WORKSPACE_DIR, exist_ok=True)
        repo = GITHUB_REPO if GITHUB_REPO.startswith("http") else f"https://github.com/{GITHUB_REPO}"
        if repo.startswith("https://") and "@" not in repo:
            repo = repo.replace("https://", f"https://x-access-token:{GITHUB_PAT}@", 1)
        if not os.path.isdir(os.path.join(WORKSPACE_DIR, ".git")):
            if os.listdir(WORKSPACE_DIR):
                _git(["init", "-b", "main"])
                _git(["remote", "add", "origin", repo])
                _git(["fetch", "origin", "--depth", "1"])
                _git(["checkout", "-B", "main", "origin/main"])
            else:
                _git(["clone", "--depth", "1", repo, WORKSPACE_DIR])
                return "cloned"
        gi = os.path.join(WORKSPACE_DIR, ".gitignore")
        if not os.path.exists(gi):
            open(gi, "w").write(".local/\n__pycache__/\n*.pyc\n")
        _git(["add", "-A"])
        st = subprocess.run(["git", "status", "--porcelain"], cwd=WORKSPACE_DIR,
                            capture_output=True, text=True, timeout=60)
        if not st.stdout.strip():
            return None
        _git(["-c", "user.email=agent@tusk.local", "-c", "user.name=tusk-agent",
              "commit", "-m", f"agent: {reason}"])
        return _git(["push", "origin", "HEAD:main"])
    except Exception as e:  # noqa: BLE001
        return f"git sync error: {e}"


def _looks_truncated(text: str) -> bool:
    """True when the reply looks like a tool-call JSON that the upstream cut off."""
    t = (text or "").strip()
    if not t or t[-1] == "}":
        return False
    return (t.startswith("{") and '"arguments"' in t) or t.startswith('{"tool"')


def _repair_tool_json(text: str, valid) -> Optional[Dict[str, Any]]:
    """Salvage a mangled/truncated tool-call JSON: re-balance strings & braces.
    Better to execute a repaired call than to leak raw JSON into the chat."""
    i = (text or "").find("{")
    if i < 0:
        return None
    out: List[str] = []
    stack: List[str] = []
    in_str = False
    esc = False
    for ch in text[i:]:
        if in_str:
            out.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
            out.append(ch)
            continue
        if ch in "{[":
            stack.append(ch)
        elif ch in "}]":
            if not stack:
                break
            stack.pop()
        out.append(ch)
    frag = "".join(out)
    if in_str:
        frag += '"'
    frag += "".join("}" if c == "{" else "]" for c in reversed(stack))
    try:
        obj = json.loads(frag)
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    name = obj.get("tool") or obj.get("name")
    if name not in valid:
        return None
    return {"name": name, "arguments": json.dumps(obj.get("arguments") or {}, ensure_ascii=False)}



_SEARCH_CACHE: Dict[str, Any] = {}


_FS_MOD = None
_WE_MOD = None


def _mods():
    global _FS_MOD, _WE_MOD
    if _FS_MOD is None:
        try:
            import free_search as _m
            _FS_MOD = _m
        except Exception:  # noqa: BLE001
            _FS_MOD = False
    if _WE_MOD is None:
        try:
            import website_extract as _m2
            _WE_MOD = _m2
        except Exception:  # noqa: BLE001
            _WE_MOD = False
    return _FS_MOD, _WE_MOD


def _web_search(q: str, n: int = 10) -> str:
    n = max(1, min(int(n or 10), 25))
    fs, _ = _mods()
    if fs:
        try:
            hits = fs.search(q, max_results=n)
            out = [f"- {h.get('title', '')[:100]} :: {h.get('url', '')}" for h in hits if h.get("url")]
            if out:
                return "[search:free_search-fleet] " + "\n".join(out[:n])
        except Exception:  # noqa: BLE001
            pass
    ck = f"{q}|{n}"
    hit = _SEARCH_CACHE.get(ck)
    if hit and time.time() - hit[0] < 300:
        return hit[1]
    """Keyless multi-engine search (DDG html -> Bing html), like free_search.py's fleet."""
    import urllib.parse as up
    engines = (
        ("ddg", "https://html.duckduckgo.com/html/?q=" + up.quote(q)),
        ("ddglite", "https://lite.duckduckgo.com/lite/?q=" + up.quote(q)),
        ("mojeek", "https://www.mojeek.com/search?q=" + up.quote(q)),
        ("bingrss", "https://www.bing.com/search?format=rss&q=" + up.quote(q)),
        ("wiki", "https://en.wikipedia.org/w/api.php?action=opensearch&limit=6&format=json&search=" + up.quote(q)),
        ("bing", "https://www.bing.com/search?q=" + up.quote(q)),
    )
    for name, url in engines:
        try:
            rq = urllib.request.Request(url, headers={"User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
            raw = urllib.request.urlopen(rq, timeout=15).read().decode("utf-8", "replace")
            STOP = {"what","when","how","why","which","does","that","this","with","from","have","will","about","the","and","for","can","you","tell","me","is","are"}
            words = [w for w in re.split(r"\W+", q.lower()) if len(w) > 4 and w not in STOP]
            out = []
            if name == "wiki":
                j = json.loads(raw)
                for t, u in zip(j[1] or [], j[3] or []):
                    out.append(f"- {t} :: {u}")
            elif name == "bingrss":
                for m in re.finditer(r"<item><title>([\s\S]*?)</title><link>([\s\S]*?)</link>", raw):
                    ti, uu = re.sub('<[^>]+>', '', m.group(1)).strip(), m.group(2).strip()
                    blob = (ti + " " + uu).lower()
                    if words and sum(1 for w in words if w in blob) < 2:
                        continue
                    out.append(f"- {ti[:100]} :: {uu}")
            else:
                for m in re.finditer(r'<a[^>]+href="(https?://[^"]+)"[^>]*>([\s\S]*?)</a>', raw):
                    u, t = m.group(1), re.sub(r"<[^>]+>", "", m.group(2)).strip()
                    if len(t) > 15 and q.split()[0].lower() not in u.lower() \
                            and (not words or sum(1 for w in words if w in (t + u).lower()) >= 2) \
                            and not u.startswith(("https://html.duckduckgo", "https://lite.duckduckgo", "https://www.bing.com")):
                        out.append(f"- {t[:100]} :: {u}")
                    if len(out) >= n:
                        break
            if out:
                res = f"[search:{name}] " + "\n".join(out[:n])
                _SEARCH_CACHE[ck] = (time.time(), res)
                return res
        except Exception:  # noqa: BLE001
            time.sleep(1.5)   # one polite retry pass across engines happens naturally
            continue
    return "no search engine answered (bot-walled); try web_extract on a known URL"


def _web_extract(url: str) -> str:
    """r.jina.ai reader relay first, naive tag-strip fallback."""
    try:
        rq = urllib.request.Request(url, headers={"User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml"})
        html0 = urllib.request.urlopen(rq, timeout=20).read().decode("utf-8", "replace")
        txt0 = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", html0)
        txt0 = re.sub(r"<[^>]+>", " ", txt0)
        txt0 = re.sub(r"\s+", " ", txt0).strip()
        if len(txt0) > 400:
            return txt0[:6000]
    except Exception:  # noqa: BLE001
        pass
    try:
        rq = urllib.request.Request("https://r.jina.ai/" + url,
                                    headers={"User-Agent": "Mozilla/5.0"})
        return urllib.request.urlopen(rq, timeout=25).read().decode("utf-8", "replace")[:6000]
    except Exception:  # noqa: BLE001
        pass
    try:
        rq = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        html = urllib.request.urlopen(rq, timeout=20).read().decode("utf-8", "replace")
        txt = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", html)
        txt = re.sub(r"<[^>]+>", " ", txt)
        return re.sub(r"\s+", " ", txt)[:6000]
    except Exception as e:  # noqa: BLE001
        return f"extract failed: {e}"


def _diagnose(ai, task: str, steps, err: str = "") -> str:
    log = "\n".join(f"- {st.get('tool')}: {str(st.get('result'))[:120]}" for st in steps[-10:])
    try:
        r = ai.ask(f"DIAGNOSTIC ROLE. Task: {task[:800]}\nLast steps:\n{log}\nError: {err[:300]}\n"
                   "In 3 short bullets: (1) why it stopped, (2) what to try next, "
                   "(3) what the user must know. Plain text, no tools.")
        return clean_text(r.text)[:1200]
    except Exception:  # noqa: BLE001
        return ""



MANIFEST = """
PLATFORM MANIFEST (you must know all of this):
- You run on a real Linux server. Tools: run_python, run_shell (any CLI: pip, curl, tar, java, gradle, aapt2, ffmpeg...), write_file/read_file/list_dir (whole workspace; keep deliverables in your chat folder), spawn_subtask, github_push, memory_add/memory_show, web_search (keyless multi-engine, count up to 25), web_extract (any URL to readable text).
- Decide YOURSELF when to search/extract; never ask the user for permission to use tools.
- For product/price/deal tasks: search engines bot-wall shopping queries — go STRAIGHT to web_extract on site search URLs (https://www.amazon.in/s?k=..., https://www.flipkart.com/search?q=..., 91mobiles/smartprix search pages); compare 10-20 items; deliver a markdown table AND a real xlsx/csv file in your folder.
- You can create and run files in EVERY chat mode (plain chat included). Never tell the user you can only search: write the file with write_file, run it with run_shell, and point at the result.
- Deliverables: write real files (xlsx via openpyxl, csv, html, apk, png via matplotlib...) into your chat folder. The UI shows a Files panel with preview + DOWNLOAD buttons for everything you create — always create the file instead of printing tables when the user asks for a file.
- Artifacts UI: wrap deliverable code you show in chat with fence lang artifact-<lang> (artifact-html, artifact-python...) so it files under Artifacts; interactive pages/games use ```html fences (Run button appears).
- Charts: ```chart JSON {"type","title","size","width","labels","series"} renders live interactive; ```svg renders illustrations you draw.
- Math: $$...$$ / \\(...\\).
- Long installs/builds: run in background with nohup + poll logs; never sleep longer than 110s per step; if rate-limited you are automatically waited out — just continue.
- Memory: proactively memory_add durable facts (user preferences, project conventions, useful commands that worked).
- If a build path fails, try the next toolchain before reporting (you have full apt-less userspace: download JDK/SDK tarballs to workspace, pip --user, npm --prefix).
"""

def _verify_prompt(task: str, steps: List[Dict[str, Any]], draft: str) -> str:
    log = "\n".join(f"- {st.get('tool')}: {str(st.get('result'))[:150]}" for st in steps[-14:])
    return (f"VERIFIER ROLE. Original task: {task[:1500]}\nSteps performed:\n{log}\n"
            f"Draft final answer:\n{draft[:1500]}\n"
            'Is the task FULLY completed? Reply ONLY JSON: '
            '{"complete": true|false, "summary": "professional summary of what was done '
            'and the results", "missing": "what remains, empty if complete"}')


def _agent_pass(ai, prompt, root, cap, emit, depth, tag, tools=None):
    steps: List[Dict[str, Any]] = []
    final = ""
    served = None
    for i in range(max(0, cap)):
        r = None
        for _try in range(4):   # transient deaths AND rate-limit walls get retries
            try:
                r = ai.ask(prompt)
                break
            except TuskUpstreamFailureError:
                ai.reset()
                time.sleep(1.0 + _try)
            except TuskNetworkError:
                time.sleep(1.0 + _try)
            except TuskRateLimitError:
                # Tusk allows ~10 calls/min: WAIT it out instead of dying mid-task
                time.sleep(min(75, 20 + 15 * _try))
        if r is None:
            raise TuskUpstreamFailureError("upstream died 4x within a single agent step")
        time.sleep(3.5)   # pace under the 10/min wall on long runs
        served = r.model_name or r.model
        raw = clean_text(r.text)
        tools = tools or _AGENT_TOOLS
        tc, text, _status = parse_tool_call(raw, tools)
        repaired = False
        if tc is None:
            xtc = _normalize_tool_call_xml(raw)
            if xtc:
                tc, repaired = xtc, True
        if tc is None and not _looks_truncated(raw):
            rep = _repair_tool_json(raw, _VALID_AGENT_NAMES)
            if rep:
                tc, repaired = rep, True
        if tc is None and _looks_truncated(raw):
            prompt += ("\n\n[system] Your previous tool call was TRUNCATED mid-JSON by the "
                       "upstream limit. Retry differently: split large file contents into "
                       "several write_file calls using append=true (first call creates the "
                       "file, later calls append chunks of <=3000 chars).")
            steps.append({"i": i + 1, "tool": f"{tag}truncation_heal", "args": "",
                          "result": "previous tool call was cut off; retrying with chunked writes",
                          "model": served})
            emit(steps[-1])
            continue
        if tc is None:
            final = text
            break
        obs = run_agent_tool(tc, WORKSPACE_DIR, {"ai": ai, "depth": depth, "emit": emit})
        step = {"i": i + 1, "tool": f"{tag}{tc.get('name', '?')}",
                "args": tc.get("arguments") or "", "result": obs[:2000], "model": served,
                "repaired": repaired or None}
        steps.append(step)
        emit(step)
        prompt += (f"\n\n[observation from {tc.get('name', 'tool')}]:\n{obs}"
                   "\n\nContinue toward the goal.")
    else:
        if cap > 0:
            final = ""
    return final, steps, served


def _agent_core(ai, prompt, root, budget, emit, depth, tag="", task="", tools=None, verify=True):
    """Agent loop with a verifier: after each pass the model itself is asked
    whether the task is complete; if not, it continues. budget 0 = unlimited."""
    cap = 400 if budget <= 0 else budget
    all_steps: List[Dict[str, Any]] = []
    served = None
    final = ""
    while True:
        final, steps, served = _agent_pass(ai, prompt, root, cap - len(all_steps), emit, depth, tag, tools)
        all_steps += steps
        if not verify or not final or not all_steps or not task or len(all_steps) >= cap:
            break
        try:
            vr = ai.ask(_verify_prompt(task, all_steps, final))
            vj = extract_json(clean_text(vr.text)) or {}
        except TuskError:
            break
        if str(vj.get("complete", "")).lower() in ("true", "yes", "1"):
            final = str(vj.get("summary") or final)
            break
        miss = str(vj.get("missing") or "").strip()
        if not miss:
            break
        prompt += (f"\n\n[verifier] Task NOT complete yet. Missing: {miss}\n"
                   "Continue with tools until fully done, then answer.")
    if not final or final.startswith("Step budget"):
        diag = _diagnose(ai, task, all_steps)
        head = final or ("Step budget exhausted. Completed so far: "
                         + ", ".join(st.get("tool", "?") for st in all_steps[-8:]) + ".")
        final = head + ("\n\n--- WHY IT STOPPED / HOW TO PROCEED ---\n" + diag if diag else
                        "\n\n(stopped: budget exhausted; re-send to continue)")
    return final, all_steps, served


def compact_messages(messages: List[Dict[str, Any]], budget_chars: int = 120_000
                     ) -> List[Dict[str, Any]]:
    """Worst-case guard: if the conversation would blow the context window,
    keep system + a digest of the old middle + the recent tail verbatim."""
    def size(ms): return sum(len(m.get("content") or "") for m in ms)
    if size(messages) <= budget_chars:
        return messages
    head = [m for m in messages[:1] if m.get("role") == "system"]
    rest = messages[len(head):]
    keep = rest[-10:]
    old = rest[:-10]
    digest = "\n".join(f"- {m.get('role')}: {(m.get('content') or '')[:180].strip()}" for m in old)
    mid = [{"role": "system",
            "content": f"[earlier conversation digest, {len(old)} messages trimmed for context]\n{digest}"}]
    return head + mid + keep



# --------------------------------------------------------------------------- #
# Background job queue: autonomous agent runs that survive page close and
# container sleep (persisted to agent_jobs.json, git-synced, resumed at boot).
# --------------------------------------------------------------------------- #
JOBS_FILE = os.path.join(WORKSPACE_DIR, "agent_jobs.json")
_jobs_lock = threading.Lock()
JOBS: Dict[str, Dict[str, Any]] = {}


def _jobs_load() -> None:
    global JOBS
    try:
        JOBS = json.load(open(JOBS_FILE, encoding="utf-8"))
    except Exception:
        JOBS = {}


def _jobs_save() -> None:
    try:
        tmp = JOBS_FILE + ".tmp"
        with _jobs_lock:
            json.dump(JOBS, open(tmp, "w", encoding="utf-8"))
            os.replace(tmp, JOBS_FILE)
    except Exception:  # noqa: BLE001
        pass


def _run_job(jid: str) -> None:
    job = JOBS.get(jid)
    if not job:
        return
    job["status"] = "running"
    job["started"] = time.time()
    _jobs_save()
    root = os.path.realpath(os.path.join(WORKSPACE_DIR, "chats", "job-" + jid[:8]))
    os.makedirs(root, exist_ok=True)
    ai = _client()
    prompt = build_prompt_with_tools(job["task"], _AGENT_TOOLS)
    prompt += ("\n\nAUTONOMOUS JOB MODE: no human is watching right now. Work until the "
               f"task is genuinely complete. Your private folder is '{os.path.relpath(root, WORKSPACE_DIR)}/'; "
               "run_python/run_shell already start inside it. pip install --user works. "
               "When done, write a professional summary as your final answer.")
    mem = memory_text()[-3000:]
    if mem.strip():
        prompt += "\n\nLONG-TERM MEMORY:\n" + mem

    def emit(step: Dict[str, Any]) -> None:
        job["steps"].append(step)
        _jobs_save()

    try:
        final, steps, served = _agent_core(ai, prompt, root, AGENT_MAX_STEPS, emit, 0,
                                           task=job["task"])
        job["status"] = "done"
        job["result"] = final[:8000]
        job["served"] = served
    except Exception as e:  # noqa: BLE001
        diag = ""
        try:
            diag = _diagnose(ai, job["task"], job.get("steps", []), str(e))
        except Exception:  # noqa: BLE001
            pass
        job["status"] = "error"
        job["result"] = (f"{type(e).__name__}: {e}"[:500]
                         + ("\n\n--- WHY IT STOPPED / HOW TO PROCEED ---\n" + diag if diag else ""))
    job["finished"] = time.time()
    _jobs_save()
    git_sync("job " + jid[:8])


def start_job(task: str) -> str:
    jid = uuid.uuid4().hex
    JOBS[jid] = {"id": jid, "task": task[:4000], "status": "queued", "steps": [],
                 "created": time.time(), "result": ""}
    _jobs_save()
    threading.Thread(target=_run_job, args=(jid,), daemon=True).start()
    return jid


def resume_jobs() -> None:
    _jobs_load()
    for jid, job in list(JOBS.items()):
        if job.get("status") in ("running", "queued"):
            job["status"] = "queued"
            job["steps"] = job.get("steps", [])
            threading.Thread(target=_run_job, args=(jid,), daemon=True).start()


def _git_sync_loop() -> None:
    while True:
        time.sleep(600)
        try:
            git_sync("periodic sync")
        except Exception:  # noqa: BLE001
            pass


def run_agent_tool(tc: Dict[str, Any], root: str = WORKSPACE_DIR,
                   ctx: Optional[Dict[str, Any]] = None) -> str:
    name = tc.get("name", "")
    try:
        args = json.loads(tc.get("arguments") or "{}")
    except Exception:
        args = {}
    missing = {"write_file": ("path", "content"), "read_file": ("path",),
               "run_shell": ("command",), "run_python": ("code",),
               "web_search": ("query",), "web_extract": ("url",),
               "spawn_subtask": ("task",), "memory_add": ("text",)}.get(name)
    if missing and not all(str(args.get(k, "")).strip() for k in missing):
        return (f"tool error: missing argument(s) {', '.join(missing)} for {name}. "
                f"Retry with complete arguments (large contents: split with append=true).")
    try:
        if name == "run_python":
            r = subprocess.run([sys.executable, "-c", args.get("code", "")],
                               cwd=root, capture_output=True, text=True,
                               stdin=subprocess.DEVNULL,
                               timeout=AGENT_STEP_TIMEOUT, env=_clean_env())
            return (r.stdout + "\n" + r.stderr)[-4000:] or f"(exit {r.returncode}, no output)"
        if name == "run_shell":
            r = subprocess.run(args.get("command", ""), shell=True, cwd=root,
                               capture_output=True, text=True,
                               stdin=subprocess.DEVNULL,
                               timeout=AGENT_STEP_TIMEOUT, env=_clean_env())
            return (r.stdout + "\n" + r.stderr)[-4000:] or f"(exit {r.returncode}, no output)"
        if name == "write_file":
            if not str(args.get("path", "")).strip():
                return "tool error: write_file needs a non-empty relative 'path'"
            p = _ws_path(args.get("path", ""), root)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            mode = "a" if args.get("append") else "w"
            with open(p, mode, encoding="utf-8") as fh:
                fh.write(args.get("content", ""))
            return f"{'appended to' if mode == 'a' else 'wrote'} {args.get('path')} ({len(args.get('content', ''))} chars)"
        if name == "read_file":
            return open(_ws_path(args.get("path", ""), root), encoding="utf-8", errors="replace").read()[-4000:]
        if name == "list_dir":
            rel = str(args.get("path") or ".")
            p = _ws_path(rel, root)
            names = sorted(os.listdir(p))
            if rel in (".", "", "/"):
                names = [x for x in names if not x.startswith(".")]
            return "\n".join(names) or "(empty)"
        if name == "github_push":
            return git_sync(args.get("message", "manual push")) or "nothing to push"
        if name == "web_search":
            return _web_search(str(args.get("query", "")), int(args.get("count") or 10))
        if name == "web_extract":
            return _web_extract(str(args.get("url", "")))
        if name == "memory_add":
            with open(MEMORY_FILE, "a", encoding="utf-8") as fh:
                fh.write("- " + str(args.get("text", "")).strip() + "\n")
            return "remembered (" + str(len(memory_text())) + " bytes total)"
        if name == "memory_show":
            return memory_text()[-4000:] or "(memory empty)"
        if name == "spawn_subtask":
            if not ctx or ctx.get("depth", 0) >= 2:
                return "sub-agent depth limit reached (max 2 levels)"
            sub_prompt = (f"SUB-TASK (self-contained): {args.get('task', '')}\n"
                          f"Complete it fully using the available tools inside the same "
                          f"workspace folder, then answer with a concise report of what you "
                          f"did and the exact results.")
            final, sub_steps, _s = _agent_core(
                ctx["ai"], build_prompt_with_tools(sub_prompt, _AGENT_TOOLS), root,
                min(8, AGENT_MAX_STEPS or 8), ctx.get("emit") or (lambda s: None),
                ctx.get("depth", 0) + 1, tag="sub")
            return f"[sub-agent finished in {len(sub_steps)} steps]\n{final}"[:4000]
        return f"unknown tool {name}"
    except subprocess.TimeoutExpired:
        return f"TIMEOUT after {AGENT_STEP_TIMEOUT}s"
    except Exception as e:  # noqa: BLE001
        return f"tool error: {type(e).__name__}: {e}"


def _guard_public_mode() -> None:
    """Refuse to be an open relay: a non-loopback bind MUST have an API key."""
    if HOST in _LOOPBACK_HOSTS or SHIM_API_KEY:
        return
    print("=" * 62, flush=True)
    print("REFUSING TO START -- public bind without an API key", flush=True)
    print("=" * 62, flush=True)
    print(f"  HOST={HOST!r} makes this shim reachable from other machines,", flush=True)
    print("  but SHIM_API_KEY is empty, which accepts ANY key.", flush=True)
    print("  That would be an open, free relay to Tusk for the whole internet.", flush=True)
    print("", flush=True)
    print("  Fix: set a strong key, e.g.:", flush=True)
    print('    SHIM_API_KEY="$(python3 -c \'import secrets;print(secrets.token_urlsafe(32))\')"', flush=True)
    print("  ...or bind to localhost only:  HOST=127.0.0.1", flush=True)
    sys.exit(2)


def main() -> int:
    _guard_public_mode()
    os.makedirs(WORKSPACE_DIR, exist_ok=True)
    if GITHUB_REPO and GITHUB_PAT:
        threading.Thread(target=_git_sync_loop, daemon=True).start()
        threading.Thread(target=git_sync, args=("boot",), daemon=True).start()
    if AGENT_TOKEN:
        threading.Thread(target=resume_jobs, daemon=True).start()
    srv = QuietThreadingHTTPServer((HOST, PORT), Handler)
    srv.daemon_threads = True
    print(f"tusk-openai-shim {TUSK_VERSION} on http://{HOST}:{PORT}", flush=True)
    print(f"  base URL for Kilo : http://<host>:{PORT}/v1", flush=True)
    print(f"  model id          : {MODEL_ID}  (all requests route to Tusk {GUEST_MODEL_LABEL})", flush=True)
    print(f"  tools mode        : {TOOLS_MODE}  (faked via prompt; NOT native)", flush=True)
    print(f"  auth              : {'Bearer key REQUIRED' if SHIM_API_KEY else 'OPEN -- set SHIM_API_KEY'}", flush=True)
    print(f"  mode              : {'PUBLIC -- reachable over the network' if HOST not in _LOOPBACK_HOSTS else 'local only'}", flush=True)
    print(f"  upstream          : {UPSTREAM_TIMEOUT}s timeout, {MAX_RETRIES} retry", flush=True)
    print(f"  prefer model      : {PREFER_MODEL or '(any -- cannot be pinned as a guest)'}", flush=True)
    print(f"  self-heal retries : tools={TOOL_RETRIES}, model={PREFER_MAX_RETRIES}, "
          f"upstream={UPSTREAM_RETRIES}", flush=True)
    print(f"  web UI            : GET /chat  (key auto-embedded: "
          f"{'ON' if os.environ.get('SHIM_WEB_EMBED_KEY', '1') not in ('0', 'false', 'no') and SHIM_API_KEY else 'off'})",
          flush=True)
    print(f"  agent (Cowork)    : {'ON at /v1/agent/completions (token-gated)' if AGENT_TOKEN else 'off (set SHIM_AGENT_TOKEN)'}"
          f"{'; workspace synced to ' + GITHUB_REPO if GITHUB_REPO and GITHUB_PAT else ''}", flush=True)
    rs = rate_stats()
    print(f"  quota guard       : {rs['per_minute']:.0f} req/min, burst "
          f"{rs['burst']:.0f} (server allows ~10/min sustained)", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nshutting down", flush=True)
    finally:
        srv.server_close()
        _executor.shutdown(wait=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
