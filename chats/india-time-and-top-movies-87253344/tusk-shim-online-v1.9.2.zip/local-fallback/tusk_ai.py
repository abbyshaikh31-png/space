#!/usr/bin/env python3
"""
tusk_ai.py -- Unofficial, dependency-free Python client for the free AI chat
endpoint behind https://new.tusksearch.com/ai ("Tusk Central AI").

WHY THIS EXISTS
---------------
The web app is an Angular SPA. It does NOT need a browser to talk to: the chat
UI is just an XMLHttpRequest POST to `/api/V2/Chat` that returns a streamed
`application/x-ndjson` body. This module speaks that protocol directly with the
Python standard library only -- no Chrome, no Selenium, no Playwright, no pip
installs. That makes it trivially runnable from cron / GitHub Actions / a
serverless function.

PROTOCOL NOTES (reverse engineered 2026-10-29, app v0.9.79 beta)
---------------------------------------------------------------
POST https://new.tusksearch.com/api/V2/Chat
  Content-Type: application/json
  (Authorization: Bearer <clerk jwt>  -- ONLY if signed in; guest works without)

  Body is a FLAT object (do NOT wrap it in {"request": ...} -- that 500s):
    {
      "role": "user",
      "chatId": <guid|null>,          # null => server starts a new chat
      "sessionId": <guid|null>,       # null => server starts a new session
      "content": "<prompt>",
      "aiModelId": "<provider guid>", # see /api/v2/chat/providers
      "grokproOptions": null,
      "voiceAndTone": "casual",       # technical|creative|work|learn|casual|...
      "askClarifyingQuestion": false,
      "isWebSearchEnabled": false,
      "isLocationEnabled": false,
      "location": null,               # or {"city":..,"countryCode":..}
      "inputMode": "text"             # text|voice
    }

  Response: newline-delimited JSON. Each line looks like:
    {"chatId":"...","sessionId":"...","chatLogId":null,"role":"assistant",
     "content":"{\"isComplete\":false,\"model\":\"google/gemini-3.8-flash\",
                 \"role\":\"assistant\",\"content\":\"<delta text>\"}"}

  NOTE the double encoding: the outer `content` is itself a JSON *string* that
  must be parsed again. The terminal line has "isComplete": true and carries
  token counts / generationMs / citations, with an empty content delta.

USAGE
-----
  Library:
      from tusk_ai import TuskAI
      ai = TuskAI()
      r = ai.ask("Summarise photosynthesis in one sentence.")
      print(r.text)

  FIXED-PROMPT / CRON MODE  (the mode you asked for -- prompts live in code)
  --------------------------------------------------------------------------
  Edit the FIXED_PROMPTS list near the top of this file, then:

      python3 tusk_ai.py --list-fixed
      python3 tusk_ai.py --run-fixed --out results.json --lock /tmp/tusk.lock

  That runs every fixed prompt, VALIDATES each answer (gate detection, length
  bounds, JSON schema keys), merges with the previous good run so a transient
  blip never wipes your data, and writes results.json atomically. Serve that
  file from your website and you answer in <20ms without ever waiting on the
  3-6s upstream call. Exit code 8 means at least one prompt failed, which is
  what your cron should alert on (set TUSK_ALERT_WEBHOOK, e.g. an ntfy.sh
  topic, and it POSTs the failure for you).

  Cron example (every 3 hours):
      0 */3 * * * cd /opt/tusk && /usr/bin/python3 tusk_ai.py --run-fixed \
                    --out /var/www/results.json --lock /tmp/tusk.lock \
                    >> /var/log/tusk.log 2>&1

  CLI:
      python3 tusk_ai.py "your prompt here"
      python3 tusk_ai.py --list-models
      python3 tusk_ai.py --selftest
      python3 tusk_ai.py "prompt" --model "gemini" --json
      python3 tusk_ai.py "prompt" --stream          # token-by-token to stdout
      echo "prompt" | python3 tusk_ai.py -           # read prompt from stdin

Exit codes: 0 ok, 2 usage, 3 network/timeout, 4 HTTP error, 5 empty response,
6 rate limited,
            7 model gated behind signup, 8 one or more fixed prompts failed.
"""

from __future__ import annotations

import argparse
import json
import os
import random
import sys
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple
import urllib.error
import urllib.request

__version__ = "1.9.2"

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #

BASE_URL = os.environ.get("TUSK_BASE_URL", "https://new.tusksearch.com")
CHAT_ENDPOINT = BASE_URL + "/api/V2/Chat"
PROVIDERS_ENDPOINT = BASE_URL + "/api/v2/chat/providers"

# A stable desktop-Chrome UA. The API does not currently enforce it, but sending
# a realistic one reduces the chance of a future bot filter rejecting us.
USER_AGENT = os.environ.get(
    "TUSK_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
)

# Where the resolved provider catalogue gets cached so `--model <name>` does not
# need a network round trip every run (important for the 5s latency budget).
MODEL_CACHE_PATH = os.environ.get(
    "TUSK_MODEL_CACHE",
    os.path.join(os.path.expanduser("~"), ".cache", "tusk_ai", "models.json"),
)
MODEL_CACHE_TTL = int(os.environ.get("TUSK_MODEL_CACHE_TTL", str(24 * 3600)))

# CRITICAL: as a GUEST (no auth token) the backend only serves the model whose
# label is exactly "Brainiac". Every other provider -- including ones the
# catalogue marks isPremium:false -- replies with the gate message
# "<p>Sign up for a free account to use this model.</p>" in ~0.6s.
# Verified 2026-10-29 against app v0.9.79.
GUEST_MODEL_LABEL = "Brainiac"
FALLBACK_MODEL_ID = "efb6b775-3a32-4b74-8e8a-3fbb6f9627d4"  # Brainiac
DEFAULT_MODEL_HINT = os.environ.get("TUSK_DEFAULT_MODEL", GUEST_MODEL_LABEL.lower())

# The UI ignores this sentinel when absorbing ids from the stream; so do we.
NULL_GUID = "00000000-0000-0000-0000-000000000000"

# Returned verbatim by the backend when the chosen model needs an account.
GATE_MARKERS = ("sign up for a free account", "sign up to use", "upgrade to")

# Returned verbatim by the backend when the upstream model dies mid-generation
# (observed in the wild 2026-10-29 through Kilo Code: the whole "answer" was
# exactly this HTML line). Transient: a fresh session almost always works.
UPSTREAM_FAILURE_MARKERS = ("something went wrong generating",
                            "please try again.</p>",
                            "an error occurred while generating")

VALID_TONES = {"casual", "technical", "creative", "work", "learn", "gippr"}


# --------------------------------------------------------------------------- #
# Errors
# --------------------------------------------------------------------------- #

class TuskError(Exception):
    """Base class for all tusk_ai errors."""
    exit_code = 1


class TuskUsageError(TuskError):
    exit_code = 2


class TuskNetworkError(TuskError):
    exit_code = 3


class TuskHTTPError(TuskError):
    exit_code = 4

    def __init__(self, status: int, body: str, url: str):
        self.status = status
        self.body = body
        self.url = url
        detail = _extract_api_error(body) or body[:400]
        super().__init__(f"HTTP {status} from {url}: {detail}")


class TuskRateLimitError(TuskHTTPError):
    exit_code = 6

    def __init__(self, status: int, body: str, url: str, retry_after: Optional[float] = None):
        super().__init__(status, body, url)
        self.retry_after = retry_after


class TuskTimeoutError(TuskNetworkError):
    pass


class TuskEmptyResponseError(TuskError):
    exit_code = 5


class TuskModelGatedError(TuskError):
    """The backend refused because the model requires a (free) account."""
    exit_code = 7


class TuskUpstreamFailureError(TuskError):
    """The routed upstream model died mid-generation (HTML error page as the
    whole reply). Transient and retryable with a fresh session."""
    exit_code = 9


def is_upstream_failure(text: str) -> bool:
    """True when `text` looks like Tusk's 'generation failed' HTML error page
    rather than a real answer. Real answers are never a single <p> tag."""
    t = (text or "").strip()
    if not t or len(t) > 400:
        return False
    low = t.lower()
    return any(m in low for m in UPSTREAM_FAILURE_MARKERS)


_CODE_FENCE = None  # compiled lazily below


def strip_code_fences(text: str) -> str:
    """
    Remove ```lang ... ``` wrappers.

    The model emits these even when explicitly told "no code fence", so any
    caller that wants JSON must strip them first. Verified 2026-10-29:
        asked -> 'Return ONLY a JSON object, no prose, no code fence: {...}'
        got   -> '```json\\n{"sentiment":"negative","score":3}\\n```'
    """
    s = (text or "").strip()
    if s.startswith("```"):
        # drop the opening fence line (```json / ```JSON / ```)
        nl = s.find("\n")
        if nl != -1:
            s = s[nl + 1:]
        else:
            s = s[3:]
        if s.rstrip().endswith("```"):
            s = s.rstrip()[:-3]
    return s.strip()


def extract_json(text: str) -> Any:
    """
    Best-effort parse of JSON out of untrusted model prose.

    Never call json.loads(result.text) directly: the model adds conversational
    filler and code fences. This strips fences, then finds the first balanced
    {...} or [...] block, tolerating surrounding prose.

    Raises ValueError if nothing parseable is found.
    """
    global _CODE_FENCE
    s = strip_code_fences(text)
    if not s:
        raise ValueError("empty response")

    # fast path: the whole thing is already valid JSON
    try:
        return json.loads(s)
    except Exception:
        pass

    # scan for the first balanced object/array, respecting strings + escapes
    for opener, closer in (("{", "}"), ("[", "]")):
        start = s.find(opener)
        if start < 0:
            continue
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(s)):
            ch = s[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == opener:
                depth += 1
            elif ch == closer:
                depth -= 1
                if depth == 0:
                    candidate = s[start:i + 1]
                    try:
                        return json.loads(candidate)
                    except Exception:
                        break
    raise ValueError(f"no JSON found in response: {text[:200]!r}")


def clean_text(text: str) -> str:
    """Normalise model prose: strip fences, collapse trailing filler whitespace."""
    return strip_code_fences(text).strip()


def _extract_api_error(body: str) -> Optional[str]:
    """ASP.NET Core ProblemDetails -> a readable one-liner."""
    try:
        d = json.loads(body)
    except Exception:
        return None
    if isinstance(d, dict) and "errors" in d:
        parts = []
        for k, v in d["errors"].items():
            parts.append(f"{k}: {v if isinstance(v, str) else '; '.join(map(str, v))}")
        return " | ".join(parts)
    if isinstance(d, dict):
        for key in ("message", "error", "title", "detail"):
            if d.get(key):
                return str(d[key])
    return None


# --------------------------------------------------------------------------- #
# Client-side rate governor
# --------------------------------------------------------------------------- #
# MEASURED 2026-10-29. The endpoint DOES enforce a quota and answers:
#     HTTP 429, Retry-After: 3
#     "API calls quota exceeded! maximum admitted 10 per 1m."
#
# Observed behaviour is a token bucket with a large burst buffer:
#   - 259 requests / 200s (77.7/min) from cold  -> 0 x 429
#   - 121 requests /  45s (161/min) from cold   -> 0 x 429
#   -  40 sequential at 1/s                     -> 0 x 429
#   - 8 concurrent immediately after a heavy
#     2-minute run (burst already drained)      -> 222/375 = 59% x 429
#
# Practical reading: short and medium bursts are free; sustained hammering
# eventually clamps you toward the stated ~10/min until the buffer refills.
#
# So we self-throttle to stay UNDER the server's limit. Waiting a few seconds
# client-side is far better than handing Kilo/Cline a 429 error.

RATE_ENABLED = os.environ.get("TUSK_RATE_ENABLED", "1") not in ("0", "false", "no")
# Server's stated sustained ceiling is 10/min, but it clearly has a large burst
# buffer: 259 requests over 200s (77.7/min) returned ZERO 429s from a cold
# start, while the same shape fired right after a heavy run got 59% rejected.
# So: generous burst, then it clamps to roughly the stated 10/min.
#
# Default guard is deliberately loose -- its job is to stop a runaway agent loop
# from torching your access, not to slow down normal single-user use. Anything
# that does slip through is caught by the Retry-After handler in ask().
# Set TUSK_RATE_PER_MIN=9 for maximum safety on a shared/fragile connection.
RATE_PER_MIN = float(os.environ.get("TUSK_RATE_PER_MIN", "45"))
RATE_BURST = float(os.environ.get("TUSK_RATE_BURST", "20"))
RATE_MAX_WAIT = float(os.environ.get("TUSK_RATE_MAX_WAIT", "180"))


class _TokenGovernor:
    """Process-global token bucket, thread-safe, shared by all TuskAI instances."""

    def __init__(self, per_minute: float, burst: float):
        self.per_minute = max(0.1, per_minute)
        self.capacity = max(1.0, burst)
        self.tokens = self.capacity
        self.last = time.monotonic()
        self._lock = threading.Lock()
        self.total_waited = 0.0
        self.total_acquired = 0

    def acquire(self, max_wait: float = RATE_MAX_WAIT) -> float:
        """Block until a token is available. Returns seconds spent waiting."""
        waited = 0.0
        while True:
            with self._lock:
                now = time.monotonic()
                self.tokens = min(self.capacity,
                                  self.tokens + (now - self.last) * (self.per_minute / 60.0))
                self.last = now
                if self.tokens >= 1.0:
                    self.tokens -= 1.0
                    self.total_acquired += 1
                    self.total_waited += waited
                    return waited
                need = (1.0 - self.tokens) / (self.per_minute / 60.0)
            if waited + need > max_wait:
                raise TuskRateLimitError(
                    429,
                    f"client-side governor: would need to wait {need:.0f}s for a slot "
                    f"(limit {self.per_minute:.0f}/min), exceeding max wait {max_wait:.0f}s",
                    CHAT_ENDPOINT, retry_after=need)
            time.sleep(min(need, 5.0))
            waited += min(need, 5.0)


_GOVERNOR = _TokenGovernor(RATE_PER_MIN, RATE_BURST)


def rate_stats() -> Dict[str, Any]:
    """Expose governor state for /health endpoints and debugging."""
    with _GOVERNOR._lock:
        return {"per_minute": _GOVERNOR.per_minute, "burst": _GOVERNOR.capacity,
                "tokens_available": round(_GOVERNOR.tokens, 2),
                "total_acquired": _GOVERNOR.total_acquired,
                "total_waited_s": round(_GOVERNOR.total_waited, 1),
                "enabled": RATE_ENABLED}


# --------------------------------------------------------------------------- #
# Result object
# --------------------------------------------------------------------------- #

@dataclass
class TuskResult:
    """Everything you get back from one ask()."""
    text: str = ""
    model: Optional[str] = None            # upstream slug e.g. google/gemini-3.8-flash
    model_name: Optional[str] = None       # display name e.g. Gemini 3.8 Flash
    chat_id: Optional[str] = None
    session_id: Optional[str] = None
    citations: List[Any] = field(default_factory=list)
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    generation_ms: Optional[int] = None
    chunks: int = 0
    ttfb_s: Optional[float] = None         # time to first stream byte
    elapsed_s: Optional[float] = None      # total wall clock for the call
    raw: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self, include_raw: bool = False) -> Dict[str, Any]:
        d = asdict(self)
        if not include_raw:
            d.pop("raw", None)
        return d


@dataclass
class ModelInfo:
    key: str
    label: str
    display_name: str
    provider: str
    is_premium: bool
    has_web_search: bool
    options: List[str]

    @property
    def is_free(self) -> bool:
        return not self.is_premium


# --------------------------------------------------------------------------- #
# HTTP plumbing (stdlib only)
# --------------------------------------------------------------------------- #

def _open(url: str, *, data: Optional[bytes] = None, method: str = "GET",
          extra_headers: Optional[Dict[str, str]] = None, timeout: float = 30.0):
    """urlopen with our standard headers. Returns the response object."""
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Origin": BASE_URL,
        "Referer": BASE_URL + "/ai",
        # identity, NOT gzip: a gzipped stream cannot be consumed incrementally.
        "Accept-Encoding": "identity",
    }
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    return urllib.request.urlopen(req, timeout=timeout)


def _read_json(url: str, timeout: float = 30.0) -> Any:
    with _open(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


# --------------------------------------------------------------------------- #
# Model catalogue
# --------------------------------------------------------------------------- #

def fetch_models(timeout: float = 20.0) -> List[ModelInfo]:
    """Live pull of the provider catalogue."""
    d = _read_json(PROVIDERS_ENDPOINT, timeout=timeout)
    out: List[ModelInfo] = []
    for p in d.get("providers", []) or []:
        if not p.get("supportsChat", True):
            continue
        out.append(ModelInfo(
            key=p.get("key", ""),
            label=p.get("label") or p.get("displayName") or "?",
            display_name=p.get("displayName") or p.get("label") or "?",
            provider=p.get("providerName") or "?",
            is_premium=bool(p.get("isPremium")),
            has_web_search=bool(p.get("hasWebSearch")),
            options=[o.get("key") for o in (p.get("options") or []) if o.get("key")],
        ))
    return out


def _cache_load() -> Optional[List[Dict[str, Any]]]:
    try:
        st = os.stat(MODEL_CACHE_PATH)
        if time.time() - st.st_mtime > MODEL_CACHE_TTL:
            return None
        with open(MODEL_CACHE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _cache_save(models: List[ModelInfo]) -> None:
    try:
        os.makedirs(os.path.dirname(MODEL_CACHE_PATH), exist_ok=True)
        tmp = MODEL_CACHE_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump([asdict(m) for m in models], f)
        os.replace(tmp, MODEL_CACHE_PATH)
    except Exception:
        pass  # cache is best-effort; never fail the request over it


def get_models(use_cache: bool = True, timeout: float = 20.0) -> List[ModelInfo]:
    """Cached-first model list; falls back to the built-in default on failure."""
    if use_cache:
        hit = _cache_load()
        if hit:
            return [ModelInfo(**m) for m in hit]
    try:
        models = fetch_models(timeout=timeout)
        if models:
            _cache_save(models)
            return models
    except Exception:
        pass
    return [ModelInfo(key=FALLBACK_MODEL_ID, label="Fallback", display_name="Fallback",
                      provider="?", is_premium=False, has_web_search=False,
                      options=["sprint"])]


def resolve_model(hint: Optional[str], timeout: float = 20.0) -> Tuple[str, Optional[ModelInfo]]:
    """
    Turn a human hint into a provider GUID.

    Accepts: a raw GUID, an exact key, or a case-insensitive substring of the
    label / display name / provider. Prefers FREE models and, among free ones,
    the first match. Raises TuskUsageError listing candidates if ambiguous-ish
    and nothing matches.
    """
    if not hint:
        hint = DEFAULT_MODEL_HINT

    # Already a GUID? Trust it, skip the catalogue lookup entirely (fast path).
    try:
        uuid.UUID(hint)
        return hint, None
    except (ValueError, AttributeError, TypeError):
        pass

    models = get_models(timeout=timeout)
    h = hint.strip().lower()

    guest = [m for m in models if m.label == GUEST_MODEL_LABEL]
    free = [m for m in models if m.is_free]
    # Guest-usable first, then free, then everything. Without an auth token the
    # backend only serves Brainiac, so that ordering avoids a wasted round trip.
    pools = (guest, free, models)
    for pool in pools:
        exact = [m for m in pool
                 if m.key.lower() == h or m.label.lower() == h
                 or m.display_name.lower() == h]
        if len(exact) == 1:
            return exact[0].key, exact[0]
        sub = [m for m in pool
               if h in m.label.lower() or h in m.display_name.lower()
               or h in m.provider.lower()]
        if sub:
            # Deterministic pick: shortest label wins (least surprising match).
            best = min(sub, key=lambda m: (len(m.label), m.label))
            return best.key, best

    names = ", ".join(sorted({m.label for m in free})) or "(catalogue unavailable)"
    raise TuskUsageError(f"No model matching {hint!r}. Free models: {names}")


# --------------------------------------------------------------------------- #
# Stream parsing
# --------------------------------------------------------------------------- #

def _parse_inner(outer_content: Any) -> Optional[Dict[str, Any]]:
    """The outer `content` field is a JSON *string*. Decode it defensively."""
    if isinstance(outer_content, dict):
        return outer_content
    if not isinstance(outer_content, str):
        return None
    s = outer_content.strip()
    if not s:
        return None
    try:
        v = json.loads(s)
        return v if isinstance(v, dict) else None
    except Exception:
        return None


def iter_ndjson(response) -> Iterator[Dict[str, Any]]:
    """
    Yield decoded objects from a streaming HTTP response.

    Buffers partial lines across chunk boundaries (a JSON object can be split
    anywhere by TCP), and skips blank/keepalive lines.
    """
    buf = b""
    while True:
        piece = response.read(8192)
        if not piece:
            break
        buf += piece
        while True:
            nl = buf.find(b"\n")
            if nl < 0:
                break
            line, buf = buf[:nl], buf[nl + 1:]
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line.decode("utf-8", "replace"))
            except Exception:
                continue  # tolerate a stray malformed frame
            if isinstance(obj, list):
                for o in obj:
                    if isinstance(o, dict):
                        yield o
            elif isinstance(obj, dict):
                yield obj
    tail = buf.strip()
    if tail:
        try:
            obj = json.loads(tail.decode("utf-8", "replace"))
            if isinstance(obj, dict):
                yield obj
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Client
# --------------------------------------------------------------------------- #

class TuskAI:
    """
    Stateful client. Reuse one instance for a multi-turn conversation: it
    remembers chatId/sessionId so the server keeps context.

        ai = TuskAI()
        ai.ask("Hi, I'm Sam.")
        ai.ask("What's my name?")   # -> remembers
        ai.reset()                  # start a fresh conversation
    """

    def __init__(self,
                 model: Optional[str] = None,
                 tone: str = "casual",
                 web_search: bool = False,
                 timeout: float = 60.0,
                 max_retries: int = 2,
                 max_rate_retries: Optional[int] = None,
                 backoff_base: float = 0.7,
                 token: Optional[str] = None,
                 input_mode: str = "text",
                 verbose: bool = False):
        self.model_hint = model or DEFAULT_MODEL_HINT
        self.tone = tone if tone in VALID_TONES else "casual"
        self.web_search = web_search
        self.timeout = timeout
        self.max_retries = max(0, max_retries)
        # 429s get their own, larger budget: the fix is simply to wait a minute.
        self.max_rate_retries = (int(os.environ.get("TUSK_MAX_RATE_RETRIES", "6"))
                                 if max_rate_retries is None else max(0, max_rate_retries))
        self.backoff_base = backoff_base
        self.token = token or os.environ.get("TUSK_TOKEN")  # optional signed-in JWT
        self.input_mode = input_mode
        self.verbose = verbose

        self.chat_id: Optional[str] = None
        self.session_id: Optional[str] = None
        self._resolved_model: Optional[str] = None
        self._resolved_info: Optional[ModelInfo] = None

    # -- conversation state ------------------------------------------------- #

    def reset(self) -> None:
        """Drop chatId/sessionId so the next ask() starts a brand new chat."""
        self.chat_id = None
        self.session_id = None

    def _log(self, *a: Any) -> None:
        if self.verbose:
            print("[tusk_ai]", *a, file=sys.stderr)

    # -- payload ------------------------------------------------------------ #

    def _build_payload(self, prompt: str) -> Dict[str, Any]:
        return {
            "role": "user",
            "chatId": self.chat_id,
            "sessionId": self.session_id,
            "content": prompt,
            "aiModelId": self._resolved_model or FALLBACK_MODEL_ID,
            "grokproOptions": None,
            "voiceAndTone": self.tone,
            "askClarifyingQuestion": False,
            "isWebSearchEnabled": bool(self.web_search),
            "isLocationEnabled": False,
            "location": None,
            "inputMode": self.input_mode,
        }

    # -- main entry point --------------------------------------------------- #

    def ask(self,
            prompt: str,
            *,
            model: Optional[str] = None,
            on_delta: Optional[Callable[[str], None]] = None,
            timeout: Optional[float] = None,
            web_search: Optional[bool] = None) -> TuskResult:
        """
        Send `prompt` and return the complete TuskResult.

        on_delta: optional callback invoked with each incremental text fragment
                  (use it to print a live token stream).
        """
        if not prompt or not prompt.strip():
            raise TuskUsageError("prompt is empty")

        deadline_timeout = timeout if timeout is not None else self.timeout
        if model:
            self.model_hint = model
        if web_search is not None:
            self.web_search = web_search

        # Resolve the model GUID once per instance (cached on disk afterwards).
        self._resolved_model, self._resolved_info = resolve_model(self.model_hint)
        self._log("model ->", self._resolved_model,
                  self._resolved_info.label if self._resolved_info else "")

        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        body = json.dumps(self._build_payload(prompt)).encode("utf-8")

        attempt = 0
        rate_attempts = 0
        last_err: Optional[Exception] = None
        while attempt <= self.max_retries:
            attempt += 1
            try:
                return self._do_request(body, headers, deadline_timeout, on_delta)
            except TuskRateLimitError as e:
                # The server quota is per-minute, so backoff_base*2^n is far too
                # aggressive. Honour Retry-After (default 3s) and keep trying on
                # its own budget -- waiting is the correct response to a 429.
                last_err = e
                if on_delta is not None:
                    raise
                rate_attempts += 1
                if rate_attempts > self.max_rate_retries:
                    break
                wait = max(e.retry_after or 3.0, 3.0) + random.uniform(0, 0.6)
                wait = min(wait, RATE_MAX_WAIT)
                self._log(f"429 quota ({rate_attempts}/{self.max_rate_retries}); "
                          f"waiting {wait:.1f}s")
                time.sleep(wait)
                attempt -= 1          # a quota wait should not consume a retry
                continue
            except (TuskNetworkError, TuskTimeoutError) as e:
                last_err = e
                # Never retry once we have streamed partial text to a callback --
                # that would duplicate output for the caller.
                if on_delta is not None:
                    raise
                if attempt > self.max_retries:
                    break
                sleep_s = self.backoff_base * (2 ** (attempt - 1)) + random.uniform(0, 0.35)
                self._log(f"attempt {attempt} failed ({e}); retrying in {sleep_s:.2f}s")
                time.sleep(sleep_s)
            except TuskHTTPError as e:
                # 5xx are worth a retry; 4xx are our fault, fail fast.
                last_err = e
                if e.status >= 500 and attempt <= self.max_retries and on_delta is None:
                    sleep_s = self.backoff_base * (2 ** (attempt - 1)) + random.uniform(0, 0.35)
                    self._log(f"attempt {attempt} got {e.status}; retrying in {sleep_s:.2f}s")
                    time.sleep(sleep_s)
                    continue
                raise
        assert last_err is not None
        raise last_err

    # -- internals ---------------------------------------------------------- #

    def _do_request(self, body: bytes, headers: Dict[str, str],
                    timeout: float,
                    on_delta: Optional[Callable[[str], None]]) -> TuskResult:
        t0 = time.monotonic()
        ttfb: Optional[float] = None
        res = TuskResult()

        if RATE_ENABLED:
            _GOVERNOR.acquire()

        try:
            response = _open(CHAT_ENDPOINT, data=body, method="POST",
                             extra_headers=headers, timeout=timeout)
        except urllib.error.HTTPError as e:
            try:
                err_body = e.read().decode("utf-8", "replace")
            except Exception:
                err_body = ""
            if e.code == 429:
                ra = None
                try:
                    ra = float(e.headers.get("Retry-After") or 0) or None
                except Exception:
                    ra = None
                raise TuskRateLimitError(e.code, err_body, CHAT_ENDPOINT, retry_after=ra) from None
            raise TuskHTTPError(e.code, err_body, CHAT_ENDPOINT) from None
        except (TimeoutError, OSError) as e:
            raise TuskNetworkError(f"could not reach {CHAT_ENDPOINT}: {e}") from None

        try:
            with response:
                for obj in iter_ndjson(response):
                    if ttfb is None:
                        ttfb = time.monotonic() - t0
                    res.chunks += 1
                    if res.raw is not None and len(res.raw) < 500:
                        res.raw.append(obj)

                    # IDs arrive on the first frame; keep them for multi-turn.
                    # Ignore the all-zeros sentinel the UI also ignores.
                    cid, sid = obj.get("chatId"), obj.get("sessionId")
                    if cid and cid != NULL_GUID and not self.chat_id:
                        self.chat_id = cid
                    if sid and sid != NULL_GUID and not self.session_id:
                        self.session_id = sid
                    res.chat_id = self.chat_id
                    res.session_id = self.session_id

                    inner = _parse_inner(obj.get("content"))
                    if inner is None:
                        # Unknown frame shape: keep any plain text we can find.
                        c = obj.get("content")
                        if isinstance(c, str) and c.strip():
                            res.text += c
                            if on_delta:
                                on_delta(c)
                        continue

                    delta = inner.get("content") or ""
                    if isinstance(delta, str) and delta:
                        res.text += delta
                        if on_delta:
                            on_delta(delta)

                    if inner.get("model"):
                        res.model = inner["model"]
                    if inner.get("modelName"):
                        res.model_name = inner["modelName"]
                    if inner.get("citations"):
                        res.citations = inner["citations"]
                    for src, dst in (("promptTokens", "prompt_tokens"),
                                     ("completionTokens", "completion_tokens"),
                                     ("generationMs", "generation_ms")):
                        if inner.get(src) is not None:
                            setattr(res, dst, inner[src])

                    if inner.get("error") or inner.get("errorMessage"):
                        msg = inner.get("error") or inner.get("errorMessage")
                        raise TuskHTTPError(200, json.dumps({"message": str(msg)}),
                                            CHAT_ENDPOINT)
        except TuskError:
            raise
        except (TimeoutError, OSError) as e:
            # A mid-stream socket timeout: return what we have if usable,
            # otherwise surface it as a network error.
            if res.text.strip():
                self._log("stream interrupted, returning partial:", e)
            else:
                raise TuskNetworkError(f"stream interrupted: {e}") from None

        res.ttfb_s = round(ttfb, 3) if ttfb is not None else None
        res.elapsed_s = round(time.monotonic() - t0, 3)

        low = res.text.lower()
        if any(g in low for g in GATE_MARKERS):
            raise TuskModelGatedError(
                f"model {self._resolved_model!r} is not available to guests -- the "
                f"backend replied {res.text.strip()[:120]!r}. Only the "
                f"{GUEST_MODEL_LABEL!r} model works without an account. Pass "
                f"--model {GUEST_MODEL_LABEL.lower()} (the default), or set "
                f"TUSK_TOKEN to a signed-in Clerk JWT to unlock the others."
            )

        if is_upstream_failure(res.text):
            raise TuskUpstreamFailureError(
                f"upstream model died mid-generation -- backend replied "
                f"{res.text.strip()[:160]!r} instead of an answer. This is "
                f"transient; retry with a fresh session."
            )

        if not res.text.strip():
            raise TuskEmptyResponseError(
                "server returned no text (model may be overloaded, blocked the "
                "prompt, or the protocol changed). raw chunks="
                f"{res.chunks}; sample={json.dumps(res.raw[:2])[:400]}"
            )
        return res


# --------------------------------------------------------------------------- #
# FIXED PROMPT REGISTRY
# --------------------------------------------------------------------------- #
# You said prompts are FIXED and hardcoded. This is the single place to edit.
#
# Add / remove / change entries here, then run:
#     python3 tusk_ai.py --run-fixed --out results.json
#
# Cron that every 3 hours and have your website serve results.json -- it then
# answers in <20ms and NEVER waits on the 3-6s upstream call.
#
# Each entry is validated after the call (see FixedPrompt.validate) so a gated
# model, an empty answer, or missing JSON keys shows up as a FAILURE in the
# output instead of being silently published as a good answer.

@dataclass
class FixedPrompt:
    """One hardcoded question + how to verify its answer."""
    id: str                              # stable key used in results.json / URLs
    prompt: str
    expect: str = "text"                 # "text" | "json"
    schema_keys: Tuple[str, ...] = ()    # if expect=="json": keys that must exist
    min_chars: int = 1                   # reject suspiciously short answers
    max_chars: int = 20000
    model: Optional[str] = None          # None => default (Brainiac; only guest option)
    tone: str = "casual"
    web_search: bool = False
    retries: int = 2
    timeout: float = 60.0

    def validate(self, result: "TuskResult") -> Tuple[bool, str]:
        """Return (ok, reason). Guards against publishing junk."""
        text = (result.text or "").strip()
        low = text.lower()
        if any(g in low for g in GATE_MARKERS):
            return False, "model gated behind signup"
        if not text:
            return False, "empty answer"
        if len(text) < self.min_chars:
            return False, f"too short ({len(text)} < {self.min_chars} chars)"
        if len(text) > self.max_chars:
            return False, f"too long ({len(text)} > {self.max_chars} chars)"
        if self.expect == "json":
            try:
                data = extract_json(text)
            except Exception as e:
                return False, f"json parse failed: {e}"
            if self.schema_keys:
                if not isinstance(data, dict):
                    return False, f"expected a JSON object, got {type(data).__name__}"
                missing = [k for k in self.schema_keys if k not in data]
                if missing:
                    return False, f"json missing keys: {missing}"
        return True, "ok"


# >>> EDIT ME -- replace these three examples with your real fixed prompts <<< #
FIXED_PROMPTS: List[FixedPrompt] = [
    FixedPrompt(
        id="example_plain_text",
        prompt="In one sentence, explain what a cron job does.",
        expect="text",
        min_chars=20,
    ),
    FixedPrompt(
        id="example_structured",
        prompt=(
            'Return ONLY a JSON object with keys "sentiment" (positive|negative|neutral) '
            'and "score" (integer 0-10) for this review: '
            '"I hated the delayed flight but the hotel was fantastic."'
        ),
        expect="json",
        schema_keys=("sentiment", "score"),
    ),
    FixedPrompt(
        id="example_web_grounded",
        prompt="List three currently popular open-source Python web frameworks.",
        expect="text",
        min_chars=40,
        web_search=True,
    ),
]
# >>> END EDIT ME <<< #


def get_fixed(prompt_id: Optional[str] = None) -> List[FixedPrompt]:
    if not FIXED_PROMPTS:
        raise TuskUsageError("FIXED_PROMPTS registry is empty -- edit tusk_ai.py")
    if prompt_id is None:
        return list(FIXED_PROMPTS)
    hits = [p for p in FIXED_PROMPTS if p.id == prompt_id]
    if not hits:
        ids = ", ".join(p.id for p in FIXED_PROMPTS)
        raise TuskUsageError(f"no fixed prompt with id {prompt_id!r}. available: {ids}")
    return hits


# --------------------------------------------------------------------------- #
# Locking, atomic writes, alerting  (make cron safe)
# --------------------------------------------------------------------------- #

class _Lock:
    """
    Cross-process lock so two overlapping cron runs can't both write results.
    Portable (no fcntl): O_EXCL create + stale detection by mtime.
    """

    def __init__(self, path: str, stale_after: float = 600.0):
        self.path = path
        self.stale_after = stale_after
        self.fd: Optional[int] = None

    def __enter__(self) -> "_Lock":
        try:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        except Exception:
            pass
        for _ in range(2):
            try:
                self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
                os.write(self.fd, str(os.getpid()).encode())
                return self
            except FileExistsError:
                try:
                    age = time.time() - os.stat(self.path).st_mtime
                except OSError:
                    age = self.stale_after + 1
                if age > self.stale_after:
                    try:
                        os.unlink(self.path)      # stale lock from a killed run
                        continue
                    except OSError:
                        pass
                raise TuskError(
                    f"another run holds {self.path} (age {age:.0f}s); skipping"
                ) from None
        raise TuskError(f"could not acquire lock {self.path}")

    def __exit__(self, *exc) -> None:
        if self.fd is not None:
            try:
                os.close(self.fd)
            except OSError:
                pass
            self.fd = None
        try:
            os.unlink(self.path)
        except OSError:
            pass


def atomic_write_json(path: str, obj: Any) -> None:
    """Write via tmp + os.replace so a reader never sees a half-written file."""
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    tmp = os.path.join(d, f".{os.path.basename(path)}.{os.getpid()}.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def send_alert(message: str, *, url: Optional[str] = None) -> bool:
    """
    POST a failure alert. Set TUSK_ALERT_WEBHOOK to enable.

    Works with ntfy.sh (free, no signup):  export TUSK_ALERT_WEBHOOK=https://ntfy.sh/my-topic-xyz
    Also fine for Slack/Discord-ish endpoints that accept a JSON body; the
    payload is {"text": ...} which Slack and ntfy both tolerate.
    """
    url = url or os.environ.get("TUSK_ALERT_WEBHOOK")
    if not url:
        return False
    try:
        body = json.dumps({"text": message, "content": message}).encode("utf-8")
        req = urllib.request.Request(
            url, data=body, method="POST",
            headers={"Content-Type": "application/json", "User-Agent": f"tusk_ai/{__version__}"},
        )
        with urllib.request.urlopen(req, timeout=15) as r:
            r.read()
        return True
    except Exception:
        return False   # alerting must never be the reason a cron job crashes


# --------------------------------------------------------------------------- #
# Run the fixed prompt set
# --------------------------------------------------------------------------- #

def run_fixed(out_path: Optional[str] = None,
              only_id: Optional[str] = None,
              lock_path: Optional[str] = None,
              verbose: bool = False) -> Tuple[int, Dict[str, Any]]:
    """
    Execute every (or one) fixed prompt, validate each answer, and write an
    atomically-updated results file your website can serve directly.

    Returns (exit_code, payload). exit 0 = all ok, 8 = one or more failed.
    On failure the PREVIOUS good results file is left untouched unless
    --allow-partial is implied; failed entries are recorded with ok:false so
    your site can fall back to the last known value.
    """
    specs = get_fixed(only_id)
    t_start = time.monotonic()
    entries: List[Dict[str, Any]] = []
    previous = _load_previous(out_path) if out_path else {}

    for spec in specs:
        t0 = time.monotonic()
        entry: Dict[str, Any] = {
            "id": spec.id, "ok": False, "reason": None,
            "prompt": spec.prompt, "text": None, "data": None,
            "model": None, "elapsed_s": None,
            "attempted_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        try:
            ai = TuskAI(model=spec.model, tone=spec.tone, timeout=spec.timeout,
                        max_retries=spec.retries, web_search=spec.web_search,
                        verbose=verbose)
            r = ai.ask(spec.prompt)
            ok, reason = spec.validate(r)
            entry.update({
                "ok": ok, "reason": None if ok else reason,
                "text": clean_text(r.text),
                "model": r.model_name or r.model,
                "chat_id": r.chat_id, "session_id": r.session_id,
                "completion_tokens": r.completion_tokens,
                "generation_ms": r.generation_ms,
                "upstream_s": r.elapsed_s,
                "citations": r.citations,
            })
            if spec.expect == "json" and ok:
                try:
                    entry["data"] = extract_json(r.text)
                except Exception:
                    entry["data"] = None
            # NOTE: stale-fallback is handled centrally by _merge_with_previous
            # so there is exactly one place that decides what gets published.
        except TuskError as e:
            entry["reason"] = f"{type(e).__name__}: {e}"
        except Exception as e:  # noqa: BLE001
            entry["reason"] = f"{type(e).__name__}: {e}"

        entry["elapsed_s"] = round(time.monotonic() - t0, 2)
        entries.append(entry)
        flag = "OK  " if entry["ok"] else "FAIL"
        print(f"  [{flag}] {spec.id:<24} {entry['elapsed_s']:>5.2f}s"
              f"{'' if entry['ok'] else '  <- ' + str(entry['reason'])[:90]}")

    ok_n = sum(1 for e in entries if e["ok"])
    fail_n = len(entries) - ok_n
    payload = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "generator": f"tusk_ai/{__version__}",
        "endpoint": CHAT_ENDPOINT,
        "total_s": round(time.monotonic() - t_start, 2),
        "count": len(entries), "ok": ok_n, "failed": fail_n,
        "results": {e["id"]: e for e in entries},
    }

    if out_path:
        # Merge: keep last-known-good values for ids that failed this run, so a
        # transient upstream blip never wipes your published data.
        merged = _merge_with_previous(previous, payload)
        atomic_write_json(out_path, merged)
        print(f"  wrote {out_path} ({ok_n}/{len(entries)} ok)")

    if fail_n:
        msg = (f"tusk_ai: {fail_n}/{len(entries)} fixed prompt(s) FAILED at "
               f"{payload['generated_at']}: "
               + "; ".join(f"{e['id']}({e['reason']})" for e in entries if not e["ok"])[:400])
        print("  " + msg)
        sent = send_alert(msg)
        print(f"  alert webhook: {'sent' if sent else 'not configured (set TUSK_ALERT_WEBHOOK)'}")
        return 8, payload
    return 0, payload


def _load_previous(out_path: Optional[str]) -> Dict[str, Any]:
    if not out_path or not os.path.exists(out_path):
        return {}
    try:
        with open(out_path, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d.get("results", {}) if isinstance(d, dict) else {}
    except Exception:
        return {}


def _merge_with_previous(previous: Dict[str, Any], payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    For any id that FAILED this run but SUCCEEDED before, serve the old value.

    This is the whole point of the merge: a transient upstream blip, a gate
    change, or a too-short answer must never replace good published data with
    junk. The failed attempt is preserved under `failed_text` for debugging.
    """
    for pid, entry in payload["results"].items():
        if entry.get("ok"):
            entry.pop("serving_stale", None)
            continue
        old = previous.get(pid)
        if not old or not old.get("ok") or not old.get("text"):
            continue
        entry["last_good"] = {
            "text": old.get("text"), "data": old.get("data"),
            "model": old.get("model"), "generated_at": old.get("attempted_at"),
        }
        # Keyed on ok=False, NOT on "text is empty": a failed run usually does
        # return text, it just didn't pass validation. Serving that would
        # publish an answer we already rejected.
        entry["failed_text"] = entry.get("text")
        entry["text"] = old.get("text")
        if entry.get("data") is None and old.get("data") is not None:
            entry["data"] = old.get("data")
        entry["serving_stale"] = True
        entry["stale_since"] = old.get("attempted_at")
    return payload


# --------------------------------------------------------------------------- #
# Self test
# --------------------------------------------------------------------------- #

SELFTEST_PROMPT = (
    "This is an automated connectivity self-test. "
    "Reply with exactly the token PONG-7788 and nothing else."
)


def selftest(timeout: float = 60.0, verbose: bool = True) -> int:
    """End-to-end smoke test. Returns a process exit code."""
    print(f"tusk_ai selftest v{__version__}")
    print(f"  endpoint : {CHAT_ENDPOINT}")
    ok = True

    # 1. catalogue
    t = time.monotonic()
    try:
        models = fetch_models(timeout=20)
        free = [m for m in models if m.is_free]
        print(f"  [1/3] providers      OK  {len(models)} models "
              f"({len(free)} free) in {time.monotonic()-t:.2f}s")
    except Exception as e:
        print(f"  [1/3] providers      FAIL {type(e).__name__}: {e}")
        models, free, ok = [], [], False

    # 2. single ask
    t = time.monotonic()
    try:
        ai = TuskAI(timeout=timeout, verbose=False)  # default model = Brainiac
        r = ai.ask(SELFTEST_PROMPT)
        dt = time.monotonic() - t
        print(f"  [2/3] ask            OK  {dt:.2f}s "
              f"(ttfb {r.ttfb_s}s, gen {r.generation_ms}ms, "
              f"{r.chunks} chunks, {r.completion_tokens} tok)")
        print(f"        model={r.model_name or r.model}")
        print(f"        reply={r.text.strip()[:120]!r}")
        if "PONG" not in r.text.upper():
            print("        WARN: reply did not contain the expected PONG token "
                  "(model ignored the instruction, but transport is fine)")
        if not (r.chat_id and r.session_id):
            print("        WARN: server did not return chatId/sessionId")
    except Exception as e:
        print(f"  [2/3] ask            FAIL {type(e).__name__}: {e}")
        ok = False
        ai = None
        if isinstance(e, TuskModelGatedError):
            print("        -> guest model gate hit; check GUEST_MODEL_LABEL / providers")

    # 3. multi-turn memory
    if ai is not None:
        t = time.monotonic()
        try:
            ai.ask("Remember this code word: BLUE-OTTER-9. Reply only 'stored'.")
            r2 = ai.ask("What was the code word I gave you? Reply with only the code word.")
            dt = time.monotonic() - t
            remembered = "BLUE" in r2.text.upper() and "OTTER" in r2.text.upper()
            print(f"  [3/3] multi-turn     {'OK ' if remembered else 'WARN'} "
                  f"{dt:.2f}s  reply={r2.text.strip()[:80]!r}")
            if not remembered:
                print("        (context was not retained -- transport still fine)")
        except Exception as e:
            print(f"  [3/3] multi-turn     FAIL {type(e).__name__}: {e}")
            ok = False

    print("RESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

def _cmd_list_models(args: argparse.Namespace) -> int:
    models = fetch_models() if args.refresh else get_models()
    rows = [m for m in models if not args.free_only or m.is_free]
    if args.json:
        print(json.dumps([asdict(m) for m in rows], indent=2))
        return 0
    w = max((len(m.label) for m in rows), default=10)
    print(f"{'MODEL':<{w}}  {'TIER':6} {'WEB':4} {'MODES':16} PROVIDER  KEY")
    for m in sorted(rows, key=lambda x: (x.is_premium, x.label)):
        print(f"{m.label:<{w}}  {'paid' if m.is_premium else 'free':6} "
              f"{('yes' if m.has_web_search else '-'):4} "
              f"{','.join(m.options):16} {m.provider:<9} {m.key}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        prog="tusk_ai.py",
        description="Dependency-free client for the free Tusk Central AI chat endpoint.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="examples:\n"
               "  python3 tusk_ai.py 'explain CRON in one line'\n"
               "  python3 tusk_ai.py --list-models --free-only\n"
               "  python3 tusk_ai.py 'latest news on AI' --web-search --model sonar\n"
               "  python3 tusk_ai.py --selftest\n",
    )
    ap.add_argument("prompt", nargs="?", help="the prompt; use '-' to read stdin")
    ap.add_argument("-m", "--model", default=None,
                    help=f"model GUID or name substring (default: {DEFAULT_MODEL_HINT})")
    ap.add_argument("-t", "--tone", default="casual", choices=sorted(VALID_TONES))
    ap.add_argument("--timeout", type=float, default=60.0, help="per-request seconds (default 60)")
    ap.add_argument("--retries", type=int, default=2, help="retries on 429/5xx/network (default 2)")
    ap.add_argument("--web-search", action="store_true", help="enable web search grounding")
    ap.add_argument("--stream", action="store_true", help="print deltas as they arrive")
    ap.add_argument("--json", action="store_true", help="emit the full result as JSON")
    ap.add_argument("--new-chat", action="store_true",
                    help="force a fresh chatId/sessionId (default: new chat per process)")
    ap.add_argument("--chat-id", default=None, help="resume an existing chatId")
    ap.add_argument("--session-id", default=None, help="resume an existing sessionId")
    ap.add_argument("--list-models", action="store_true", help="list models and exit")
    ap.add_argument("--free-only", action="store_true", help="with --list-models: free models only")
    ap.add_argument("--refresh", action="store_true", help="ignore the model cache")
    ap.add_argument("--selftest", action="store_true", help="run an end-to-end smoke test")
    ap.add_argument("-v", "--verbose", action="store_true", help="debug logging to stderr")
    ap.add_argument("--version", action="version", version=f"tusk_ai {__version__}")

    # --- fixed-prompt (cron) mode ------------------------------------------- #
    g = ap.add_argument_group("fixed prompts (cron mode)",
                              "prompts are hardcoded in FIXED_PROMPTS at the top of tusk_ai.py")
    g.add_argument("--run-fixed", action="store_true",
                   help="run every fixed prompt, validate, and write results JSON")
    g.add_argument("--list-fixed", action="store_true", help="list fixed prompt ids and exit")
    g.add_argument("--fixed-id", default=None, help="run only this fixed prompt id")
    g.add_argument("--out", default=os.environ.get("TUSK_OUT", "results.json"),
                   help="results file path (default: results.json; '-' = stdout only)")
    g.add_argument("--lock", default=os.environ.get("TUSK_LOCK", ""),
                   help="lockfile path to stop overlapping cron runs (recommended)")
    g.add_argument("--no-alert", action="store_true",
                   help="do not POST to TUSK_ALERT_WEBHOOK on failure")
    args = ap.parse_args(argv)

    try:
        if args.selftest:
            return selftest(timeout=args.timeout, verbose=args.verbose)

        if args.list_fixed:
            if args.json:
                print(json.dumps([asdict(p) for p in FIXED_PROMPTS], indent=2))
                return 0
            w = max((len(p.id) for p in FIXED_PROMPTS), default=10)
            print(f"{'ID':<{w}}  {'EXPECT':6} {'WEB':4} VALIDATION")
            for p in FIXED_PROMPTS:
                v = f"min {p.min_chars} chars"
                if p.expect == "json":
                    v = f"json keys {list(p.schema_keys)}" if p.schema_keys else "json"
                print(f"{p.id:<{w}}  {p.expect:6} {('yes' if p.web_search else '-'):4} {v}")
            print(f"\n{len(FIXED_PROMPTS)} fixed prompt(s). Edit FIXED_PROMPTS in tusk_ai.py.")
            return 0

        if args.run_fixed:
            if args.no_alert:
                os.environ.pop("TUSK_ALERT_WEBHOOK", None)
            out = None if args.out == "-" else args.out
            print(f"running {len(get_fixed(args.fixed_id))} fixed prompt(s) "
                  f"against {CHAT_ENDPOINT}")
            if args.lock:
                with _Lock(args.lock):
                    code, payload = run_fixed(out, args.fixed_id, verbose=args.verbose)
            else:
                code, payload = run_fixed(out, args.fixed_id, verbose=args.verbose)
            if out is None or args.verbose:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            return code

        if args.list_models:
            return _cmd_list_models(args)

        prompt = args.prompt
        if prompt is None:
            if sys.stdin.isatty():
                ap.error("no prompt given (try --help, --list-models or --selftest)")
            prompt = sys.stdin.read()
        elif prompt == "-":
            prompt = sys.stdin.read()
        if not prompt or not prompt.strip():
            raise TuskUsageError("prompt is empty")

        ai = TuskAI(model=args.model, tone=args.tone, timeout=args.timeout,
                    max_retries=args.retries, web_search=args.web_search,
                    verbose=args.verbose)
        ai.chat_id = args.chat_id
        ai.session_id = args.session_id

        if args.stream and not args.json:
            wrote = {"n": 0}

            def delta(s: str) -> None:
                sys.stdout.write(s)
                sys.stdout.flush()
                wrote["n"] += 1

            r = ai.ask(prompt, on_delta=delta)
            if wrote["n"]:
                sys.stdout.write("\n")
            if args.verbose:
                print(f"[{r.elapsed_s}s | ttfb {r.ttfb_s}s | {r.model_name or r.model} "
                      f"| {r.completion_tokens} tok]", file=sys.stderr)
            return 0

        r = ai.ask(prompt)
        if args.json:
            print(json.dumps(r.to_dict(include_raw=args.verbose), ensure_ascii=False, indent=2))
        else:
            print(r.text)
        return 0

    except TuskError as e:
        print(f"error: {e}", file=sys.stderr)
        return e.exit_code
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
