#!/usr/bin/env bash
# start.sh -- one command to launch the Tusk -> OpenAI bridge for Kilo Code.
#
#   ./start.sh
#
# Then in Kilo Code use Base URL:  http://127.0.0.1:8100/v1
#                        API key:  tusk-local-key
#
# Change the key with:  SHIM_API_KEY=mysecret ./start.sh
# Change the port with: PORT=9000 ./start.sh
#
# Bias toward a specific upstream model (retries if the router serves another):
#   SHIM_PREFER_MODEL=GLM ./start.sh
# NOTE: guests cannot truly pin a model -- Brainiac is a server-side router.
# This only retries up to 2 extra times, which costs quota when the router is
# in a different window. Leave it unset unless you actually need it.

set -euo pipefail
cd "$(dirname "$0")"

# --- pick a python -----------------------------------------------------------
PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
  echo "ERROR: Python 3 is not installed. Get it from https://python.org" >&2
  exit 1
fi

# --- sanity check the two required files ------------------------------------
for f in tusk_ai.py openai_shim.py; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f is missing. tusk_ai.py and openai_shim.py must sit" >&2
    echo "       in the same folder as this script." >&2
    exit 1
  fi
done

# --- defaults ----------------------------------------------------------------
export SHIM_API_KEY="${SHIM_API_KEY:-tusk-local-key}"
export PORT="${PORT:-8100}"
export HOST="${HOST:-127.0.0.1}"     # localhost only = safe by default

echo "======================================================"
echo " Tusk Free -> OpenAI bridge for Kilo Code"
echo "======================================================"
echo " python    : $($PY -V 2>&1)"
echo " listening : http://${HOST}:${PORT}"
echo
echo " PUT THIS IN KILO CODE:"
echo "   Provider API : OpenAI Compatible"
echo "   Base URL     : http://${HOST}:${PORT}/v1"
echo "   API key      : ${SHIM_API_KEY}"
echo "   Model        : click 'Fetch models', pick 'brainiac'"
if [ -n "${SHIM_PREFER_MODEL:-}" ]; then
  echo "   (biasing toward upstream model: ${SHIM_PREFER_MODEL})"
fi
echo
echo " Press Ctrl+C to stop. Leave this window open while using Kilo."
echo "======================================================"
echo

# quick upstream check so failures are obvious immediately
if "$PY" tusk_ai.py --selftest >/tmp/tusk_selftest.log 2>&1; then
  echo "[ok] upstream connectivity check passed"
else
  echo "[!!] upstream check FAILED -- details:"
  sed 's/^/     /' /tmp/tusk_selftest.log
  echo "     (starting the server anyway)"
fi
echo

exec "$PY" openai_shim.py
