@echo off
REM start.bat -- one double-click to launch the Tusk -> OpenAI bridge for Kilo Code.
REM
REM Then in Kilo Code use Base URL:  http://127.0.0.1:8100/v1
REM                          API key:  tusk-local-key
REM
REM Change the key:  set SHIM_API_KEY=mysecret  (before running)
REM Change the port: set PORT=9000
REM
REM Bias toward a specific upstream model (guests cannot truly pin one):
REM   set SHIM_PREFER_MODEL=GLM

setlocal
cd /d "%~dp0"

REM --- pick a python ---------------------------------------------------------
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo ERROR: Python 3 is not installed.
  echo Get it from https://python.org  ^(tick "Add python.exe to PATH"^)
  pause
  exit /b 1
)

REM --- sanity check the two required files ----------------------------------
if not exist "tusk_ai.py" (
  echo ERROR: tusk_ai.py is missing from this folder.
  pause & exit /b 1
)
if not exist "openai_shim.py" (
  echo ERROR: openai_shim.py is missing from this folder.
  pause & exit /b 1
)

REM --- defaults --------------------------------------------------------------
if not defined SHIM_API_KEY set "SHIM_API_KEY=tusk-local-key"
if not defined PORT set "PORT=8100"
if not defined HOST set "HOST=127.0.0.1"

echo ======================================================
echo  Tusk Free -^> OpenAI bridge for Kilo Code
echo ======================================================
echo  listening : http://%HOST%:%PORT%
echo.
echo  PUT THIS IN KILO CODE:
echo    Provider API : OpenAI Compatible
echo    Base URL     : http://%HOST%:%PORT%/v1
echo    API key      : %SHIM_API_KEY%
echo    Model        : click 'Fetch models', pick 'brainiac'
echo.
echo  Close this window to stop. Leave it open while using Kilo.
echo ======================================================
echo.

REM quick upstream check so failures are obvious immediately
%PY% tusk_ai.py --selftest > "%TEMP%\tusk_selftest.log" 2>&1
if %errorlevel%==0 (
  echo [ok] upstream connectivity check passed
) else (
  echo [!!] upstream check FAILED -- details:
  type "%TEMP%\tusk_selftest.log"
  echo      ^(starting the server anyway^)
)
echo.

%PY% openai_shim.py
pause
endlocal
