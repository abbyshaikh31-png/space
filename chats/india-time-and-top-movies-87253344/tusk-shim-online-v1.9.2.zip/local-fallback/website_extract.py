#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
free_extract.py - UNMETERED free website extraction & reader for headless/CI/LLM workflows.

WHY THIS EXISTS
---------------
Paid/quota web scraping and reader APIs (Firecrawl, Jina Reader API, Tavily
Extract, Diffbot, ScrapingBee, ZenRows, Spider.cloud ...) burn through their
monthly credit allowance and then fail with 402/429, while target websites
put up Cloudflare/Akamai/DataDome challenges, cookie walls, or 403 blocks on
bare datacenter IPs. This module removes the quota ceiling by multiplying
independent free extraction layers instead of relying on one:

    total headroom ~= (extraction backends & archives)
                    x (egress IPs: direct + proxy pool + relays)
                    x (local multi-parser cascade + CDP Load-More/SPA + SSR/JSON-LD)
                    x (persistent SQLite cache hits)

Every layer is free, keyless, and autonomous. Nothing is ever invented: if a
page is a bot-challenge shell, a soft-404, or unreachable across every backend
and egress tier, it is flagged `deferred=True` (and rejected by the content
quality gate) so the caller can retry on the next run rather than polluting
downstream LLM/RAG pipelines with "Just a moment... Enable JavaScript".

LAYERS
------
1. EXTRACTION BACKENDS - a priority-ordered fleet of independent adapters:
     direct_http   Fetches target URL (with smart specialization for YouTube,
                   Reddit, GitHub, Wikipedia, PDF, JSON/XML/RSS) and runs:
                     * Auto "Load More" / Infinite-Scroll / SPA expansion via
                       zero-dependency Chrome/Edge DevTools Protocol (CDP) or
                       pure-HTTP next-page/AJAX link expansion
                     * trafilatura / readability-lxml (if installed)
                     * bs4 + lxml Readability-style DOM scorer & Markdown engine
                     * zero-dependency stdlib html.parser DOM scorer & Markdown
                     * JSON-LD (articleBody) & SSR state (__NEXT_DATA__ / Nuxt)
                     * PDF text extraction (pypdf / pdfplumber / pypdfium2)
     jina_reader   https://r.jina.ai/<url> (headless Chrome reader gateway;
                   works keyless out of the box, or higher rate with JINA_API_KEY)
     markdown_new  https://markdown.new/<url> (Cloudflare Workers markdown proxy)
     urltomarkdown https://urltomarkdown.herokuapp.com/ (keyless reader gateway)
     wayback       Internet Archive Wayback Machine raw snapshot (`id_`) +
                   local multi-parser cascade (bypasses live 403s & bot walls)
     google_amp    Discovers or probes AMP (`?amp=1` / `/amp`) lightweight pages
     headless_dom  Local headless Chrome / Edge / Chromium CDP expander with
                   automatic "Load More" button clicking & infinite scrolling
     api:<name>    OPTIONAL free-tier keys picked up from env (see KEY BACKENDS)

2. FAST-FIRST EGRESS ROUTING - tries ALL fast `direct` backends first before
   ever touching slow public proxies:
     direct           the machine's own IP across all healthy backends (fast!)
     free proxy pool  harvested + validated public HTTP proxies (used only when
                      all direct backends are walled, or when `--egress proxy`)
     relay            public HTTP fetch relays (corsproxy.io, allorigins, etc.)

3. LOAD-MORE & SPA EXPANSION - pages with "Load more" / "Show more" buttons
   (like `webscraper.io/test-sites/load-more`) or client-side SPA shells (like
   `z.ai`) are automatically detected and expanded via a zero-dependency
   Chrome/Edge CDP WebSocket controller (auto-discovers `msedge.exe` and
   `chrome.exe` on Windows/macOS/Linux without needing Playwright or Selenium!)
   plus pure-HTTP AJAX/pagination link expansion.

4. QUALITY GATE + ANTI-BOT-WALL DETECTOR - HTTP 200 does NOT mean success.
   Cloudflare Turnstile, Akamai Access Denied, GDPR cookie walls, footer-only
   shells, and soft-404s are scored on prose density, word count, sentence
   structure, link density, challenge markers, and optional query relevance
   (`quality` in 0.0..1.0). Extractions below `min_quality` are rejected so the
   router keeps hunting.

5. CIRCUIT BREAKERS + AIMD PACING + PER-DOMAIN POLITENESS + SQLITE CACHE.

CLI
---
  python website_extract.py selftest
  python website_extract.py extract "https://webscraper.io/test-sites/load-more"
  python website_extract.py extract "https://example.com" --format markdown
  python website_extract.py extract "https://example.com" --json -o page.json
  python website_extract.py batch urls.txt -j 8 --retry --json out.json --md-dir pages/
  python website_extract.py search-extract "sam altman openai" -n 5 --json out.json
  python website_extract.py serve --port 8079
  python website_extract.py stats
"""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import html as htmllib
import io
import json
import logging
import math
import os
import random
import re
import shutil
import socket
import sqlite3
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from collections import defaultdict
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, as_completed, wait
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import requests
except ImportError:  # pragma: no cover
    sys.stderr.write("free_extract: 'requests' is required -> pip install requests\n")
    raise

try:
    from bs4 import BeautifulSoup, Comment, NavigableString, Tag
    HAVE_BS4 = True
except Exception:
    BeautifulSoup = Comment = NavigableString = Tag = None
    HAVE_BS4 = False

try:
    import lxml  # noqa: F401
    HAVE_LXML = True
except Exception:
    HAVE_LXML = False

try:
    import html2text as _html2text_mod
    HAVE_HTML2TEXT = True
except Exception:
    _html2text_mod = None
    HAVE_HTML2TEXT = False

try:
    import trafilatura as _trafilatura_mod
    HAVE_TRAFILATURA = True
except Exception:
    _trafilatura_mod = None
    HAVE_TRAFILATURA = False

try:
    from readability import Document as _ReadabilityDoc
    HAVE_READABILITY = True
except Exception:
    _ReadabilityDoc = None
    HAVE_READABILITY = False

try:
    import pypdf as _pypdf_mod
    HAVE_PYPDF = True
except Exception:
    _pypdf_mod = None
    HAVE_PYPDF = False

try:
    import pdfplumber as _pdfplumber_mod
    HAVE_PDFPLUMBER = True
except Exception:
    _pdfplumber_mod = None
    HAVE_PDFPLUMBER = False

try:
    import pypdfium2 as _pdfium_mod
    HAVE_PDFIUM = True
except Exception:
    _pdfium_mod = None
    HAVE_PDFIUM = False

try:
    from curl_cffi import requests as curl_requests
    HAVE_CURL_CFFI = True
except Exception:
    curl_requests = None
    HAVE_CURL_CFFI = False

logger = logging.getLogger("free-extract")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

VERSION = "2.0.0"

USER_AGENTS = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.5 Safari/605.1.15",
)
BROWSER_UA = USER_AGENTS[0]

BROWSER_HEADERS = {
    "User-Agent": BROWSER_UA,
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,*/*;q=0.8"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Cache-Control": "max-age=0",
}

SEARCH_REFERERS = (
    "https://www.google.com/",
    "https://www.bing.com/",
    "https://duckduckgo.com/",
)

# Status codes that indicate an egress IP block, rate limit, or bot wall.
WALL_CODES = (401, 402, 403, 407, 418, 429, 451, 503, 520, 521, 522, 523, 524, 530, 999)

HARD_WALL_MARKERS = (
    "cdn-cgi/challenge-platform",
    "cf-browser-verification",
    "cf-turnstile",
    "__cf_chl_opt",
    "_incapsula_resource",
    "visid_incap",
    "px-captcha",
    " perimeterx",
    "datadome.co/captcha",
    "dd_cid",
    "sucuri_cloudproxy_js",
    "attention required! | cloudflare",
    "just a moment...",
    "checking your browser before accessing",
    "please wait while your request is being verified",
    "pardon our interruption",
    "verify you are human",
    "please verify you are a human",
    "enable javascript and cookies to continue",
    "please enable js and disable any ad blocker",
    "automated access to this page has been blocked",
    "unusual traffic from your computer network",
    "prove your humanity",
    "not for bots",
    "complete the challenge below",
    "whoa there, pardner",
    "blocked by network security",
)

SOFT_WALL_PHRASES = (
    "access denied",
    "you don't have permission to access",
    "403 forbidden",
    "rate limit exceeded",
    "too many requests",
    "are you a robot",
    "not a robot",
    "security check to access",
    "bot protection",
    "ddos protection by",
    "enable javascript to run this app",
    "you need to enable javascript to run this app",
    "this site requires javascript",
)

SOFT_404_PHRASES = (
    "404 not found",
    "page not found",
    "the page you requested could not be found",
    "sorry, this page isn't available",
    "this page doesn't exist",
    "404 - file or directory not found",
    "error 404",
)

# Boilerplate class/id tokens to prune during DOM cleaning.
BOILERPLATE_TOKENS = frozenset((
    "cookie", "cookies", "consent", "gdpr", "onetrust", "cybotcookiebot",
    "nav", "navbar", "navigation", "menubar", "menu", "breadcrumb", "breadcrumbs",
    "sidebar", "side-bar", "aside", "widget", "widgets",
    "footer", "site-footer", "page-footer", "masthead", "site-header",
    "share", "social-share", "sharedaddy", "social-links",
    "related-posts", "related-articles", "recommended", "outbrain", "taboola",
    "newsletter", "subscribe-box", "signup-banner", "popup", "modal", "overlay",
    "ad-container", "ad-wrapper", "advert", "advertisement", "dfp-ad", "sponsor",
    "comments-area", "comment-list", "disqus_thread",
))

POSITIVE_CONTENT_TOKENS = frozenset((
    "article", "article-body", "article-content", "articlebody",
    "post-content", "post-body", "entry-content", "story-body", "story-content",
    "main-content", "page-content", "markdown-body", "prose", "blog-post",
    "content-body", "document-body", "paper-body", "readme", "items", "products",
    "listings", "results", "catalog", "grid", "cards",
))

DEFAULT_PROXY_SOURCES = (
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-LIST/master/http.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
    "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt",
    "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http"
    "&timeout=5000&country=all&anonymity=all",
    "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
    "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.txt",
    "https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/http_proxies.txt",
    "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/all.txt",
)

DEFAULT_RELAYS = (
    ("corsproxy", "https://corsproxy.io/?url={url}"),
    ("allorigins", "https://api.allorigins.win/raw?url={url}"),
    ("codetabs", "https://api.codetabs.com/v1/proxy?quest={url}"),
    ("whateverorigin", "http://www.whateverorigin.org/get?url={url}"),
)

KEY_ENVS = {
    "firecrawl": "FIRECRAWL_API_KEY",
    "jina_api": "JINA_API_KEY",
    "tavily_extract": "TAVILY_API_KEY",
    "exa_contents": "EXA_API_KEY",
    "diffbot": "DIFFBOT_API_KEY",
    "scrapingbee": "SCRAPINGBEE_API_KEY",
    "zenrows": "ZENROWS_API_KEY",
    "spider": "SPIDER_API_KEY",
}

_PROXY_LINE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}:\d{2,5}$")
_WS = re.compile(r"[ \t\f\v]+")
_MULTI_NL = re.compile(r"\n{3,}")
_TAG_RE = re.compile(r"<[^>]+>")

# Patterns indicating a page has a "Load more" / "Show more" button
_LOAD_MORE_HTML_RE = re.compile(
    r'(<button[^>]*>[^<]{0,40}\b(?:load\s+more|show\s+more|view\s+more|see\s+more)\b[^<]*</button>'
    r'|class=["\'][^"\']*\b(?:load-more|loadmore|show-more|btn-load-more)\b[^"\']*["\']'
    r'|id=["\'][^"\']*\b(?:load-more|loadmore|loadMore|show-more|showMore)\b[^"\']*["\']'
    r'|data-load-more|wire:click=["\']loadMore)',
    re.I,
)


# ---------------------------------------------------------------------------
# Exceptions & Data Classes
# ---------------------------------------------------------------------------

class ExtractError(Exception):
    """Base class for extraction errors."""


class BotWalled(ExtractError):
    """Egress IP or request was blocked / challenged -> escalate egress tier."""


class BackendDown(ExtractError):
    """Backend cannot extract this URL (404, unsupported format, parse miss) -> next backend."""


class EgressRetry(ExtractError):
    """Specific proxy or relay failed at transport level -> retry same backend with new proxy."""


class AllBackendsFailed(ExtractError):
    """Every backend x egress combination failed for this URL."""


@dataclass
class ExtractedLink:
    text: str
    url: str

    def to_dict(self) -> Dict[str, str]:
        return {"text": self.text, "url": self.url}


@dataclass
class ExtractedImage:
    alt: str
    url: str

    def to_dict(self) -> Dict[str, str]:
        return {"alt": self.alt, "url": self.url}


@dataclass
class ExtractOutcome:
    """Normalized website extraction result with full provenance and compat keys."""
    url: str
    final_url: str = ""
    title: str = ""
    author: str = ""
    published_date: str = ""
    site_name: str = ""
    description: str = ""
    language: str = ""
    markdown: str = ""
    text: str = ""
    excerpt: str = ""
    word_count: int = 0
    reading_time_min: float = 0.0
    links: List[ExtractedLink] = field(default_factory=list)
    images: List[ExtractedImage] = field(default_factory=list)
    structured_data: List[Dict[str, Any]] = field(default_factory=list)
    status_code: int = 0
    content_type: str = ""
    backend: str = ""
    parser: str = ""
    egress: str = "direct"
    proxy: str = ""
    from_cache: bool = False
    deferred: bool = False
    quality: float = 0.0
    relevance: float = 1.0
    low_quality: bool = False
    attempts: int = 0
    elapsed_ms: int = 0
    errors: List[str] = field(default_factory=list)

    def __len__(self) -> int:
        return len(self.text or self.markdown)

    def __bool__(self) -> bool:
        return bool((self.text or self.markdown).strip()) and not self.deferred

    def metadata_dict(self) -> Dict[str, Any]:
        return {
            "url": self.url,
            "final_url": self.final_url or self.url,
            "title": self.title,
            "author": self.author,
            "published_date": self.published_date,
            "site_name": self.site_name,
            "description": self.description,
            "language": self.language,
            "status_code": self.status_code,
            "content_type": self.content_type,
            "word_count": self.word_count,
            "reading_time_min": self.reading_time_min,
            "backend": self.backend,
            "parser": self.parser,
        }

    def to_dict(self) -> Dict[str, Any]:
        meta = self.metadata_dict()
        links_list = [l.to_dict() for l in self.links]
        images_list = [img.to_dict() for img in self.images]
        return {
            "url": self.url,
            "final_url": self.final_url or self.url,
            "title": self.title,
            "author": self.author,
            "published_date": self.published_date,
            "site_name": self.site_name,
            "description": self.description,
            "language": self.language,
            "markdown": self.markdown,
            "text": self.text,
            "content": self.markdown or self.text,
            "raw_content": self.markdown or self.text,
            "excerpt": self.excerpt,
            "snippet": self.excerpt,
            "word_count": self.word_count,
            "reading_time_min": self.reading_time_min,
            "links": links_list,
            "images": images_list,
            "structured_data": self.structured_data,
            "metadata": meta,
            "data": {
                "markdown": self.markdown,
                "content": self.text,
                "metadata": meta,
                "links": [l.url for l in self.links],
            },
            "status_code": self.status_code,
            "content_type": self.content_type,
            "backend": self.backend,
            "parser": self.parser,
            "egress": self.egress,
            "proxy": self.proxy,
            "from_cache": self.from_cache,
            "deferred": self.deferred,
            "quality": round(self.quality, 3),
            "relevance": round(self.relevance, 3),
            "low_quality": self.low_quality,
            "attempts": self.attempts,
            "elapsed_ms": self.elapsed_ms,
            "errors": self.errors[-8:],
        }


# ---------------------------------------------------------------------------
# Environment, Encoding, & URL / Text Helpers
# ---------------------------------------------------------------------------

def _env_int(name: str, default: int) -> int:
    try:
        v = os.getenv(name, "").strip()
        return int(v) if v else int(default)
    except (TypeError, ValueError):
        return int(default)


def _env_float(name: str, default: float) -> float:
    try:
        v = os.getenv(name, "").strip()
        return float(v) if v else float(default)
    except (TypeError, ValueError):
        return float(default)


def _env_bool(name: str, default: bool) -> bool:
    v = os.getenv(name, "").strip().lower()
    if not v:
        return default
    return v in ("1", "true", "yes", "on", "y")


def _env_list(name: str, default: Sequence[str]) -> List[str]:
    v = os.getenv(name, "").strip()
    if not v:
        return list(default)
    return [x.strip() for x in re.split(r"[,\s]+", v) if x.strip()]


def _decode_response_text(r: requests.Response) -> str:
    """Decode HTTP response bytes without RFC-2616 Latin-1 mojibake.

    `requests` defaults to `ISO-8859-1` whenever `Content-Type: text/html` omits
    an explicit `charset=...`, which corrupts UTF-8, Shift-JIS, EUC-JP, and GBK
    pages (such as archived Wayback snapshots). This function checks:
      1. Explicit HTTP header charset (if not ISO-8859-1)
      2. HTML `<meta charset="...">` or `<meta http-equiv="Content-Type" ...>`
      3. Strict UTF-8
      4. `r.apparent_encoding` / CJK fallback encodings (`cp932`, `euc_jp`, `gb18030`)
    """
    raw = r.content or b""
    if not raw:
        return ""
    ctype = (r.headers.get("Content-Type") or "").lower()
    m_hdr = re.search(r"charset=([a-zA-Z0-9_\-]+)", ctype)
    if m_hdr:
        enc = m_hdr.group(1).strip().lower()
        if enc not in ("iso-8859-1", "latin1", "latin-1"):
            try:
                return raw.decode(enc, errors="replace")
            except LookupError:
                pass

    # Sniff <meta charset> in first 4096 bytes
    head_ascii = raw[:4096].decode("ascii", errors="ignore")
    m_meta = re.search(r'charset=["\']?\s*([a-zA-Z0-9_\-]+)', head_ascii, re.I)
    if m_meta:
        enc = m_meta.group(1).strip().lower()
        try:
            return raw.decode(enc, errors="replace")
        except LookupError:
            pass

    # Try strict UTF-8 first (95%+ of modern web)
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        pass

    # Try apparent_encoding (charset_normalizer / chardet)
    try:
        app_enc = r.apparent_encoding
        if app_enc:
            return raw.decode(app_enc, errors="replace")
    except Exception:
        pass

    for enc in ("cp932", "shift_jis", "euc_jp", "gb18030", "windows-1252"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", errors="replace")


def strip_tags(s: str) -> str:
    s = htmllib.unescape(s or "")
    s = _TAG_RE.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


def normalize_url(u: str) -> str:
    """Normalize a target URL and strip tracking query parameters."""
    u = (u or "").strip()
    if not u:
        return ""
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+\-.]*://", u):
        u = "https://" + u.lstrip("/")
    try:
        p = urllib.parse.urlsplit(u)
        scheme = p.scheme.lower() if p.scheme else "https"
        netloc = p.netloc.lower()
        if netloc.endswith(":80") and scheme == "http":
            netloc = netloc[:-3]
        elif netloc.endswith(":443") and scheme == "https":
            netloc = netloc[:-4]
        path = p.path or "/"
        if p.query:
            kept = []
            for k, v in urllib.parse.parse_qsl(p.query, keep_blank_values=True):
                kl = k.lower()
                if kl.startswith(("utm_", "mc_", "pk_")) or kl in (
                    "fbclid", "gclid", "dclid", "msclkid", "igshid", "ref_src",
                    "yclid", "_hsenc", "_hsmi", "mkt_tok",
                ):
                    continue
                kept.append((k, v))
            query = urllib.parse.urlencode(kept, doseq=True)
        else:
            query = ""
        return urllib.parse.urlunsplit((scheme, netloc, path, query, ""))
    except Exception:
        return u


def resolve_url(base_url: str, href: str) -> str:
    if not href:
        return ""
    href = htmllib.unescape(href.strip())
    if href.startswith(("javascript:", "mailto:", "tel:", "data:", "#")):
        return ""
    try:
        full = urllib.parse.urljoin(base_url, href)
        if full.lower().startswith(("http://", "https://")):
            return full
    except Exception:
        pass
    return ""


def clean_markdown(md: str) -> str:
    if not md:
        return ""
    lines = []
    in_code = False
    for raw_line in md.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if raw_line.lstrip().startswith("```"):
            in_code = not in_code
            lines.append(raw_line.rstrip())
            continue
        if in_code:
            lines.append(raw_line.rstrip())
        else:
            line = _WS.sub(" ", raw_line).strip()
            lines.append(line)
    out = "\n".join(lines).strip()
    out = _MULTI_NL.sub("\n\n", out)
    return out


def markdown_to_text(md: str) -> str:
    if not md:
        return ""
    s = md
    s = re.sub(r"```[a-zA-Z0-9_\-]*\n?", "", s)
    s = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", s)
    s = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", s)
    s = re.sub(r"(?m)^#{1,6}\s+", "", s)
    s = re.sub(r"(?m)^>\s?", "", s)
    s = re.sub(r"(\*\*|__)(.*?)\1", r"\2", s)
    s = re.sub(r"(\*|_)(.*?)\1", r"\2", s)
    s = re.sub(r"`([^`]+)`", r"\1", s)
    s = _MULTI_NL.sub("\n\n", s)
    return s.strip()


def make_excerpt(text: str, max_chars: int = 400) -> str:
    if not text:
        return ""
    paras = [p.strip() for p in text.split("\n\n") if len(p.strip()) >= 40]
    candidate = paras[0] if paras else text.strip()
    candidate = re.sub(r"\s+", " ", candidate)
    if len(candidate) <= max_chars:
        return candidate
    cut = candidate[:max_chars].rsplit(" ", 1)[0]
    return (cut or candidate[:max_chars]) + "..."


# ---------------------------------------------------------------------------
# Bot-Wall Detection, SPA/Load-More Detection, & Content Quality Gate
# ---------------------------------------------------------------------------

def looks_walled_html(status: int, raw_html: str, title: str = "") -> Tuple[bool, str]:
    """Detect whether an HTTP response is a bot wall, challenge shell, or interstitial."""
    if status in WALL_CODES:
        return True, f"http:{status}"

    low_html = (raw_html or "")[:35000].lower()
    low_title = (title or "").lower().strip()
    if not low_html:
        return False, ""

    if any(t in low_title for t in (
        "just a moment",
        "attention required",
        "access denied",
        "security check",
        "are you a human",
        "pardon our interruption",
        "ddos-guard",
        "bot verification",
    )):
        return True, f"wall-title:{low_title[:50]}"

    visible_len = len(strip_tags(raw_html[:35000]))
    if visible_len < 1600:
        for m in HARD_WALL_MARKERS:
            if m in low_html:
                return True, f"hard-marker:{m[:32]}"
    if visible_len < 600:
        for m in SOFT_WALL_PHRASES:
            if m in low_html:
                return True, f"soft-marker:{m[:32]}"

    return False, ""


def has_load_more_pattern(raw_html: str) -> bool:
    """Return True if the HTML contains a 'Load more' / 'Show more' button."""
    if not raw_html:
        return False
    return bool(_LOAD_MORE_HTML_RE.search(raw_html))


def is_spa_js_shell(raw_html: str, extracted_word_count: int) -> bool:
    """Return True when static HTML yielded almost no body words (<30) because
    the page is a client-side React/Vue/Next/Vite SPA shell (like `z.ai`)."""
    if extracted_word_count >= 30 or not raw_html:
        return False
    low = raw_html[:25000].lower()
    spa_markers = (
        'id="root"', "id='root'", 'id="app"', "id='app'", 'id="__next"',
        'id="__nuxt"', "vite", "webpack", "bundle.js", "main.js", "chunk",
        'type="module"', "ng-version", "react",
    )
    if any(m in low for m in spa_markers) and low.count("<script") >= 1:
        return True
    return False


_STOPWORDS = frozenset("""
a an the and or but if then than that this these those of in on at to for from
by with without within into onto over under again further once here there when
where why how all any both each few more most other some such no nor not only
own same so too very can will just should now is are was were be been being do
does did doing have has had having i you he she it we they them his her its our
their your my me him us what which who whom
""".split())


_CJK_RE = re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uac00-\ud7af]")


def word_tokens(text: str) -> List[str]:
    """Extract word tokens, counting CJK character pairs as words so Japanese,
    Chinese, and Korean pages are scored and counted accurately."""
    if not text:
        return []
    latin_words = re.findall(r"[a-zA-Z0-9_]+", text)
    cjk_chars = _CJK_RE.findall(text)
    cjk_pseudo_words = ["".join(cjk_chars[i : i + 2]) for i in range(0, len(cjk_chars), 2)]
    return latin_words + cjk_pseudo_words


def query_terms(query: str) -> set:
    toks = re.findall(r"[a-z0-9][a-z0-9'\-\.]{1,}", (query or "").lower())
    out = {t for t in toks if t not in _STOPWORDS and len(t) >= 3}
    out |= {t for t in toks if len(t) <= 2 and t.isalpha() and t not in ("a", "i", "an")}
    return out


def compute_relevance(query: str, outcome: ExtractOutcome) -> float:
    if not query or not query.strip():
        return 1.0
    terms = query_terms(query)
    if not terms:
        return 1.0
    blob = " ".join((
        outcome.title or "",
        outcome.description or "",
        outcome.text or "",
        urllib.parse.unquote(outcome.url or ""),
    )).lower()
    matched = sum(1 for t in terms if t in blob)
    return matched / len(terms)


def score_extraction_quality(outcome: ExtractOutcome, min_words: int = 25) -> float:
    """Compute an intrinsic quality score in [0.0, 1.0] for an extracted page.

    Rejects:
      - Empty or title-only stubs (e.g. `z.ai` static 12-word title shell)
      - Footer-only link dumps (e.g. `[About][Press][Copyright][Terms][Privacy] © Google LLC`)
      - Soft-404 and bot-challenge stubs
    """
    text = (outcome.text or "").strip()
    md = (outcome.markdown or "").strip()
    title = (outcome.title or "").strip()
    low_title = title.lower()
    if not text:
        return 0.0

    # If the extracted body is literally just the page title repeated, it's an empty shell!
    if title and text.strip().lower() == low_title:
        return 0.05

    low_text = text[:4000].lower()
    words = word_tokens(text)
    n_words = len(words)

    if n_words < 5:
        return 0.04

    if n_words < 180:
        if any(p in low_title for p in SOFT_404_PHRASES) or any(p in low_text for p in SOFT_404_PHRASES):
            return 0.05
        if any(p in low_text for p in HARD_WALL_MARKERS) or any(p in low_text for p in SOFT_WALL_PHRASES):
            return 0.02

    # Detect link-wall / footer-chrome dumps (like YouTube's static footer)
    if md:
        link_anchors = re.findall(r"\[([^\]]+)\]\([^)]+\)", md)
        link_words = sum(len(word_tokens(a)) for a in link_anchors)
        link_ratio = link_words / float(max(1, n_words))
        if link_ratio > 0.72 and n_words < 60:
            return 0.08
        if n_words < 35 and sum(1 for k in ("privacy", "terms", "copyright", "about", "press", "contact") if k in low_text) >= 3:
            return 0.06

    len_score = min(1.0, math.log1p(n_words) / math.log1p(max(120, min_words * 6)))
    sentences = [s.strip() for s in re.split(r"[.!?。！？]+(?:\s|$)", text) if len(word_tokens(s)) >= 4]
    prose_score = min(1.0, len(sentences) / max(2.0, min(10.0, n_words / 22.0)))

    meta_bonus = 0.0
    if title and len(title) >= 4:
        meta_bonus += 0.06
    if outcome.description or outcome.author or outcome.published_date:
        meta_bonus += 0.04

    raw_score = (0.55 * len_score) + (0.35 * prose_score) + meta_bonus
    if n_words < min_words:
        raw_score *= (n_words / float(max(1, min_words))) * 0.65

    return max(0.0, min(1.0, raw_score))


# ---------------------------------------------------------------------------
# Zero-Dependency Headless Browser CDP Controller ("Load More" & SPA Engine)
# ---------------------------------------------------------------------------

def _find_chromium_binary() -> Optional[str]:
    """Locate Chrome, Edge, Brave, or Chromium across Windows, macOS, and Linux."""
    env_bin = os.getenv("EXTRACT_BROWSER_BIN", "").strip()
    if env_bin and os.path.isfile(env_bin):
        return env_bin

    # 1. Check PATH
    for name in (
        "chrome", "google-chrome", "google-chrome-stable",
        "msedge", "microsoft-edge", "microsoft-edge-stable",
        "chromium", "chromium-browser", "brave", "brave-browser",
    ):
        p = shutil.which(name)
        if p:
            return p

    # 2. Check standard Windows installation paths (Chrome, Edge, Brave)
    if sys.platform.startswith("win"):
        roots = [
            os.environ.get("PROGRAMFILES", r"C:\Program Files"),
            os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
            os.environ.get("LOCALAPPDATA", ""),
        ]
        rel_paths = (
            r"Google\Chrome\Application\chrome.exe",
            r"Microsoft\Edge\Application\msedge.exe",
            r"BraveSoftware\Brave-Browser\Application\brave.exe",
            r"Chromium\Application\chrome.exe",
        )
        for root in roots:
            if not root:
                continue
            for rel in rel_paths:
                cand = os.path.join(root, rel)
                if os.path.isfile(cand):
                    return cand

    # 3. Check standard macOS installation paths
    if sys.platform == "darwin":
        for cand in (
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ):
            if os.path.isfile(cand):
                return cand

    return None


class _CDPWebSocket:
    """Minimal zero-dependency RFC-6455 WebSocket client over localhost for
    driving Chrome/Edge DevTools Protocol without Playwright or Selenium."""

    def __init__(self, ws_url: str, timeout: float = 15.0):
        u = urllib.parse.urlparse(ws_url)
        self.sock = socket.create_connection((u.hostname or "127.0.0.1", u.port or 9222), timeout=timeout)
        self.sock.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        req = (
            f"GET {u.path or '/'} HTTP/1.1\r\n"
            f"Host: {u.hostname}:{u.port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(req.encode("ascii"))
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise EOFError("CDP handshake failed")
            buf += chunk
        self._id = 0

    def send(self, payload: Dict[str, Any]) -> int:
        self._id += 1
        payload["id"] = self._id
        data = json.dumps(payload).encode("utf-8")
        header = bytearray([0x81])
        n = len(data)
        if n < 126:
            header.append(0x80 | n)
        elif n < 65536:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", n))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", n))
        mask = os.urandom(4)
        header.extend(mask)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
        self.sock.sendall(bytes(header) + masked)
        return self._id

    def _recv_exact(self, n: int) -> bytes:
        buf = bytearray()
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise EOFError("CDP socket closed")
            buf.extend(chunk)
        return bytes(buf)

    def recv_frame(self) -> str:
        while True:
            b1, b2 = self._recv_exact(2)
            opcode = b1 & 0x0F
            masked = b2 & 0x80
            length = b2 & 0x7F
            if length == 126:
                length = struct.unpack("!H", self._recv_exact(2))[0]
            elif length == 127:
                length = struct.unpack("!Q", self._recv_exact(8))[0]
            mask = self._recv_exact(4) if masked else b""
            payload = self._recv_exact(length)
            if masked:
                payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
            if opcode == 0x8:
                raise EOFError("CDP WebSocket closed")
            if opcode == 0x9:
                # Send Pong
                pong = bytearray([0x8A, 0x80, 0, 0, 0, 0])
                try:
                    self.sock.sendall(bytes(pong))
                except Exception:
                    pass
                continue
            if opcode in (0x1, 0x2):
                return payload.decode("utf-8", errors="replace")

    def call(self, method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        cid = self.send({"method": method, "params": params or {}})
        while True:
            raw = self.recv_frame()
            msg = json.loads(raw)
            if msg.get("id") == cid:
                return msg

    def close(self) -> None:
        try:
            self.sock.close()
        except Exception:
            pass


_CDP_EXPAND_JS = r"""
(async (maxClicks) => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 40 && document.readyState !== "complete"; i++) await sleep(50);
  await sleep(120);

  const LOAD_MORE_TEXT = /^\s*(load\s+more|show\s+more|view\s+more|see\s+more|more\s+results|more\s+items|load\s+all|show\s+all|view\s+more\s+comments|more\s+replies|\d+\s+more\s+repl)/i;
  let clicks = 0;
  let stagnant = 0;

  while (clicks < maxClicks) {
    window.scrollTo(0, document.body ? document.body.scrollHeight : 0);
    const candidates = Array.from(document.querySelectorAll(
      'button, a, [role="button"], input[type="button"], [class*="load-more"], [class*="loadmore"], [id*="load-more"], [id*="loadMore"], [data-load-more]'
    ));
    let target = null;
    for (const el of candidates) {
      const style = window.getComputedStyle(el);
      if (!style || style.display === "none" || style.visibility === "hidden" || style.opacity === "0" || el.disabled) continue;
      const rect = el.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) continue;
      const txt = (el.innerText || el.textContent || el.value || "").trim();
      if (txt.length > 45) continue;
      const cls = ((typeof el.className === "string" ? el.className : "") + " " + (el.id || "")).toLowerCase();
      const isLoadMoreAttr = cls.includes("load-more") || cls.includes("loadmore") || cls.includes("show-more") || el.hasAttribute("data-load-more");
      if (LOAD_MORE_TEXT.test(txt) || (isLoadMoreAttr && txt.length <= 30)) {
        // Avoid navigating away if it's a normal link to a different page without JS/load-more class
        if (el.tagName === "A") {
          const href = el.getAttribute("href") || "";
          if (href && !href.startsWith("#") && !href.startsWith("javascript:") && !isLoadMoreAttr) continue;
        }
        target = el;
        break;
      }
    }
    if (!target) break;

    const prevLen = document.body ? document.body.innerHTML.length : 0;
    try {
      target.scrollIntoView({block: "center"});
      target.click();
    } catch (e) {
      break;
    }
    clicks++;

    let changed = false;
    for (let w = 0; w < 20; w++) {
      await sleep(45);
      const curLen = document.body ? document.body.innerHTML.length : 0;
      const st = window.getComputedStyle(target);
      const hidden = !document.body.contains(target) || st.display === "none" || st.visibility === "hidden";
      if (Math.abs(curLen - prevLen) > 25 && (!target.disabled || hidden)) {
        changed = true;
        break;
      }
    }
    if (!changed) {
      stagnant++;
      if (stagnant >= 2) break;
    } else {
      stagnant = 0;
    }
  }
  window.scrollTo(0, document.body ? document.body.scrollHeight : 0);
  await sleep(80);
  return {
    clicks: clicks,
    title: document.title || "",
    text: document.body ? document.body.innerText : "",
    html: document.documentElement ? document.documentElement.outerHTML : ""
  };
})(%d)
"""


def render_and_expand_with_cdp(
    url: str,
    timeout: float = 20.0,
    proxy: Optional[str] = None,
    max_clicks: int = 25,
) -> Tuple[str, int]:
    """Launch headless Chrome/Edge/Chromium via CDP, navigate to `url`, click
    any 'Load more' / 'Show more' buttons in a loop until all items are loaded,
    and return `(expanded_html, clicks_performed)`."""
    binary = _find_chromium_binary()
    if not binary:
        raise BackendDown("cdp:no-chrome-or-edge-binary")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        dbg_port = s.getsockname()[1]

    user_dir = tempfile.mkdtemp(prefix="fe_cdp_")
    env = os.environ.copy()
    # Ensure $HOME is writable for Chromium SingletonLock in container/FUSE setups
    if not os.access(env.get("HOME", "/"), os.W_OK) or env.get("HOME", "").startswith("/working_dir"):
        env["HOME"] = tempfile.gettempdir()

    cmd = [
        binary,
        "--headless=new",
        "--no-sandbox",
        "--disable-blink-features=AutomationControlled",
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--disable-extensions",
        "--disable-background-networking",
        "--disable-sync",
        "--no-first-run",
        "--no-default-browser-check",
        "--blink-settings=imagesEnabled=false",
        f"--user-agent={BROWSER_UA}",
        f"--user-data-dir={user_dir}",
        f"--remote-debugging-port={dbg_port}",
        "--remote-allow-origins=*",
    ]
    if proxy:
        px = proxy if "://" in proxy else f"http://{proxy}"
        cmd.append(f"--proxy-server={px}")
    else:
        cmd.append("--no-proxy-server")
    cmd.append("about:blank")

    proc = None
    cdp = None
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=env,
        )
        ws_url = None
        deadline = time.time() + min(8.0, timeout * 0.5)
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{dbg_port}/json", timeout=0.4) as r:
                    tabs = json.loads(r.read().decode("utf-8", errors="replace"))
                    for tab in tabs:
                        if tab.get("type") == "page" and tab.get("webSocketDebuggerUrl"):
                            ws_url = tab["webSocketDebuggerUrl"]
                            break
                if ws_url:
                    break
            except Exception:
                time.sleep(0.05)

        if not ws_url:
            raise BackendDown("cdp:debugger-port-timeout")

        cdp = _CDPWebSocket(ws_url, timeout=max(8.0, timeout))
        cdp.call("Page.enable")
        cdp.call("Runtime.enable")
        cdp.call(
            "Page.addScriptToEvaluateOnNewDocument",
            {
                "source": (
                    "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
                    "window.chrome = {runtime: {}};"
                )
            },
        )
        cdp.call("Page.navigate", {"url": url})

        # Wait for navigation target to commit & reach interactive/complete state
        nav_deadline = time.time() + min(10.0, timeout * 0.6)
        while time.time() < nav_deadline:
            time.sleep(0.08)
            try:
                r_state = cdp.call(
                    "Runtime.evaluate",
                    {
                        "expression": "window.location.href + '|' + document.readyState + '|' + (document.body ? document.body.innerText.length : 0)",
                        "returnByValue": True,
                    },
                )
                val_str = str((((r_state.get("result") or {}).get("result") or {}).get("value")) or "")
                if not val_str.startswith("about:blank|") and ("|complete|" in val_str or "|interactive|" in val_str):
                    parts = val_str.rsplit("|", 2)
                    if len(parts) == 3 and int(parts[2] or 0) > 20:
                        break
            except Exception:
                pass

        res = cdp.call(
            "Runtime.evaluate",
            {
                "expression": _CDP_EXPAND_JS % int(max_clicks),
                "awaitPromise": True,
                "returnByValue": True,
            },
        )
        val = (((res.get("result") or {}).get("result") or {}).get("value")) or {}
        html_out = str(val.get("html") or "")
        clicks = int(val.get("clicks") or 0)
        if not html_out.strip():
            raise BackendDown("cdp:empty-dom")
        return html_out, clicks
    finally:
        if cdp is not None:
            cdp.close()
        if proc is not None:
            try:
                proc.terminate()
                proc.wait(timeout=2)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        shutil.rmtree(user_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Local HTML Extraction Engine (Zero-Dep Stdlib + BS4/LXML + SSR/JSON-LD)
# ---------------------------------------------------------------------------

class _StdlibDOMNode:
    __slots__ = ("tag", "attrs", "children", "parent")

    def __init__(self, tag: str, attrs: Dict[str, str], parent: Optional["_StdlibDOMNode"] = None):
        self.tag = tag
        self.attrs = attrs
        self.children: List[Any] = []
        self.parent = parent

    def text_content(self) -> str:
        parts: List[str] = []
        for ch in self.children:
            if isinstance(ch, str):
                parts.append(ch)
            else:
                parts.append(ch.text_content())
        return "".join(parts)


class _StdlibTreeBuilder(HTMLParser):
    VOID_TAGS = frozenset((
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr",
    ))

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = _StdlibDOMNode("document", {})
        self.cur = self.root

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]):
        t = tag.lower()
        attr_dict = {k.lower(): (v or "") for k, v in attrs if k}
        node = _StdlibDOMNode(t, attr_dict, parent=self.cur)
        self.cur.children.append(node)
        if t not in self.VOID_TAGS:
            self.cur = node

    def handle_endtag(self, tag: str):
        t = tag.lower()
        node = self.cur
        while node is not None and node.tag != "document":
            if node.tag == t:
                self.cur = node.parent or self.root
                return
            node = node.parent

    def handle_data(self, data: str):
        if data:
            self.cur.children.append(data)


def _is_boilerplate_attr(tag_name: str, attr_str: str) -> bool:
    if tag_name in ("html", "body", "main", "article"):
        return False
    low = (attr_str or "").lower()
    if not low:
        return False
    tokens = set(re.findall(r"[a-z0-9]+(?:-[a-z0-9]+)*", low))
    word_tokens = set(re.findall(r"[a-z0-9]+", low))
    all_toks = tokens | word_tokens
    if all_toks & POSITIVE_CONTENT_TOKENS:
        return False
    if all_toks & BOILERPLATE_TOKENS:
        return True
    return False


def _extract_json_ld(raw_html: str) -> Tuple[List[Dict[str, Any]], Dict[str, str]]:
    blocks: List[Dict[str, Any]] = []
    meta: Dict[str, str] = {}
    for m in re.finditer(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        raw_html or "",
        re.I | re.S,
    ):
        raw_json = htmllib.unescape(m.group(1).strip())
        if not raw_json:
            continue
        try:
            parsed = json.loads(raw_json)
        except Exception:
            try:
                cleaned = re.sub(r"[\x00-\x1f]+", " ", raw_json)
                parsed = json.loads(cleaned)
            except Exception:
                continue

        queue = parsed if isinstance(parsed, list) else [parsed]
        while queue:
            item = queue.pop(0)
            if not isinstance(item, dict):
                continue
            if "@graph" in item and isinstance(item["@graph"], list):
                queue.extend(item["@graph"])
            blocks.append(item)
            if not meta.get("title"):
                for k in ("headline", "name"):
                    if isinstance(item.get(k), str) and item[k].strip():
                        meta["title"] = strip_tags(item[k])
                        break
            if not meta.get("description") and isinstance(item.get("description"), str):
                meta["description"] = strip_tags(item["description"])
            if not meta.get("published_date"):
                for k in ("datePublished", "dateCreated", "dateModified"):
                    if isinstance(item.get(k), str) and item[k].strip():
                        meta["published_date"] = item[k].strip()
                        break
            if not meta.get("author"):
                auth = item.get("author")
                if isinstance(auth, str):
                    meta["author"] = auth.strip()
                elif isinstance(auth, dict) and isinstance(auth.get("name"), str):
                    meta["author"] = auth["name"].strip()
                elif isinstance(auth, list):
                    names = [
                        a.get("name", "").strip() if isinstance(a, dict) else str(a).strip()
                        for a in auth
                    ]
                    names = [n for n in names if n]
                    if names:
                        meta["author"] = ", ".join(names)
            if not meta.get("site_name"):
                pub = item.get("publisher")
                if isinstance(pub, dict) and isinstance(pub.get("name"), str):
                    meta["site_name"] = pub["name"].strip()
            for body_key in ("articleBody", "text"):
                val = item.get(body_key)
                if isinstance(val, str) and len(val.strip()) > len(meta.get("article_body", "")):
                    meta["article_body"] = val.strip()
    return blocks[:10], meta


def _extract_ssr_payload_text(raw_html: str) -> str:
    candidates: List[str] = []
    for m in re.finditer(
        r'<script[^>]+id=["\']__NEXT_DATA__["\'][^>]*>(.*?)</script>',
        raw_html or "",
        re.I | re.S,
    ):
        try:
            data = json.loads(m.group(1).strip())
        except Exception:
            continue

        def _walk(obj: Any):
            if isinstance(obj, str):
                s = obj.strip()
                if len(s) >= 200 and " " in s and not s.startswith(("http://", "https://", "{", "[")):
                    if re.search(r"[.!?]\s+[A-Z]", s) or "\n\n" in s or "<p>" in s:
                        candidates.append(strip_tags(s) if "<p>" in s else s)
            elif isinstance(obj, dict):
                for k, v in obj.items():
                    if k.lower() in ("script", "style", "svg", "chunks", "buildid"):
                        continue
                    _walk(v)
            elif isinstance(obj, list):
                for item in obj[:50]:
                    _walk(item)

        _walk(data)
    if not candidates:
        return ""
    candidates.sort(key=len, reverse=True)
    return "\n\n".join(dict.fromkeys(candidates[:3]))


def _extract_meta_tags(raw_html: str, base_url: str) -> Dict[str, Any]:
    info: Dict[str, Any] = {
        "title": "",
        "description": "",
        "author": "",
        "published_date": "",
        "site_name": "",
        "language": "",
        "canonical_url": "",
        "amp_url": "",
        "og_image": "",
    }
    head_chunk = (raw_html or "")[:60000]

    m_lang = re.search(r"<html[^>]+lang=[\"']?([a-zA-Z\-]+)[\"']?", head_chunk, re.I)
    if m_lang:
        info["language"] = m_lang.group(1).strip()

    m_title = re.search(r"<title[^>]*>(.*?)</title>", head_chunk, re.I | re.S)
    if m_title:
        info["title"] = strip_tags(m_title.group(1))[:300]

    for m in re.finditer(r"<meta\s+([^>]+)>", head_chunk, re.I | re.S):
        attrs_raw = m.group(1)
        name_m = re.search(r'(?:name|property|itemprop)=["\']([^"\']+)["\']', attrs_raw, re.I)
        content_m = re.search(r'content=["\']([^"\']*)["\']', attrs_raw, re.I)
        if not (name_m and content_m):
            continue
        k = name_m.group(1).strip().lower()
        v = htmllib.unescape(content_m.group(1).strip())
        if not v:
            continue
        if k in ("og:title", "twitter:title") and (not info["title"] or len(v) > len(info["title"]) // 2):
            info["title"] = strip_tags(v)[:300]
        elif k in ("description", "og:description", "twitter:description") and not info["description"]:
            info["description"] = strip_tags(v)[:600]
        elif k in ("author", "article:author", "parsely-author", "dc.creator") and not info["author"]:
            info["author"] = strip_tags(v)[:200]
        elif k in (
            "article:published_time", "datepublished", "pubdate", "publishdate",
            "dc.date", "dc.date.issued", "sailthru.date", "parsely-pub-date",
        ) and not info["published_date"]:
            info["published_date"] = v[:64]
        elif k in ("og:site_name", "application-name") and not info["site_name"]:
            info["site_name"] = strip_tags(v)[:120]
        elif k in ("og:image", "twitter:image") and not info["og_image"]:
            info["og_image"] = resolve_url(base_url, v)

    for m in re.finditer(r"<link\s+([^>]+)>", head_chunk, re.I | re.S):
        attrs_raw = m.group(1)
        rel_m = re.search(r'rel=["\']([^"\']+)["\']', attrs_raw, re.I)
        href_m = re.search(r'href=["\']([^"\']+)["\']', attrs_raw, re.I)
        if not (rel_m and href_m):
            continue
        rel = rel_m.group(1).lower()
        href = resolve_url(base_url, href_m.group(1))
        if "canonical" in rel and href and not info["canonical_url"]:
            info["canonical_url"] = href
        elif "amphtml" in rel and href and not info["amp_url"]:
            info["amp_url"] = href

    if not info["published_date"]:
        m_time = re.search(r'<time[^>]+datetime=["\']([^"\']+)["\']', raw_html or "", re.I)
        if m_time:
            info["published_date"] = m_time.group(1).strip()[:64]

    return info


# ---- BeautifulSoup + LXML Readability-style DOM Extractor -----------------

def _bs4_node_to_markdown(
    node: Any,
    base_url: str,
    links_out: List[ExtractedLink],
    images_out: List[ExtractedImage],
    seen_links: set,
    seen_images: set,
) -> str:
    if isinstance(node, NavigableString):
        if isinstance(node, Comment):
            return ""
        return str(node)

    if not isinstance(node, Tag):
        return ""

    name = (node.name or "").lower()
    if name in ("head", "title", "meta", "link", "script", "style", "noscript", "svg", "canvas", "iframe", "form", "button", "template"):
        return ""

    if name == "br":
        return "\n"
    if name == "hr":
        return "\n\n---\n\n"

    if name == "img":
        src = node.get("src") or node.get("data-src") or node.get("data-original") or ""
        full_src = resolve_url(base_url, str(src))
        alt = strip_tags(str(node.get("alt") or "")).strip()
        if full_src and not full_src.startswith("data:"):
            if full_src not in seen_images:
                seen_images.add(full_src)
                images_out.append(ExtractedImage(alt=alt, url=full_src))
            return f"![{alt or 'image'}]({full_src})"
        return ""

    if name == "pre":
        code_tag = node.find("code")
        lang = ""
        if code_tag and isinstance(code_tag, Tag):
            cls = " ".join(code_tag.get("class") or [])
            m_lang = re.search(r"(?:language|lang)-([a-zA-Z0-9_+\-]+)", cls)
            if m_lang:
                lang = m_lang.group(1)
        raw_code = node.get_text()
        return f"\n\n```{lang}\n{raw_code.strip()}\n```\n\n"

    if name == "table":
        rows_md: List[str] = []
        for tr in node.find_all("tr"):
            cells = [
                re.sub(r"\s+", " ", c.get_text(" ", strip=True)).replace("|", "\\|")
                for c in tr.find_all(["th", "td"])
            ]
            if any(cells):
                rows_md.append("| " + " | ".join(cells) + " |")
        if not rows_md:
            return ""
        first_cols = rows_md[0].count("|") - 1
        if first_cols > 0:
            sep = "| " + " | ".join(["---"] * first_cols) + " |"
            rows_md.insert(1, sep)
        return "\n\n" + "\n".join(rows_md) + "\n\n"

    if name in ("ul", "ol"):
        items_md: List[str] = []
        ordered = name == "ol"
        idx = 1
        for li in node.find_all("li", recursive=False):
            li_text = "".join(
                _bs4_node_to_markdown(ch, base_url, links_out, images_out, seen_links, seen_images)
                for ch in li.children
            ).strip()
            li_text = re.sub(r"\s+", " ", li_text)
            if li_text:
                prefix = f"{idx}. " if ordered else "- "
                items_md.append(f"{prefix}{li_text}")
                idx += 1
        return ("\n\n" + "\n".join(items_md) + "\n\n") if items_md else ""

    inner = "".join(
        _bs4_node_to_markdown(ch, base_url, links_out, images_out, seen_links, seen_images)
        for ch in node.children
    )

    if name in ("h1", "h2", "h3", "h4", "h5", "h6"):
        level = int(name[1])
        clean_h = re.sub(r"\s+", " ", inner).strip()
        return f"\n\n{'#' * level} {clean_h}\n\n" if clean_h else ""

    if name == "p":
        clean_p = inner.strip()
        return f"\n\n{clean_p}\n\n" if clean_p else ""

    if name == "blockquote":
        clean_q = inner.strip()
        if not clean_q:
            return ""
        quoted = "\n".join(f"> {ln}" for ln in clean_q.splitlines() if ln.strip())
        return f"\n\n{quoted}\n\n"

    if name in ("strong", "b"):
        s = inner.strip()
        return f"**{s}**" if s else ""

    if name in ("em", "i"):
        s = inner.strip()
        return f"*{s}*" if s else ""

    if name == "code":
        s = inner.strip()
        return f"`{s}`" if s else ""

    if name == "a":
        href = resolve_url(base_url, str(node.get("href") or ""))
        anchor = re.sub(r"\s+", " ", inner).strip()
        if href and anchor:
            if href not in seen_links:
                seen_links.add(href)
                links_out.append(ExtractedLink(text=anchor[:200], url=href))
            return f"[{anchor}]({href})"
        return inner

    if name in ("div", "section", "article", "main", "header", "figure", "figcaption", "dd", "dt"):
        return f"\n{inner}\n"

    return inner


def _extract_with_bs4(
    raw_html: str, base_url: str
) -> Tuple[str, str, List[ExtractedLink], List[ExtractedImage], str]:
    parser_name = "lxml" if HAVE_LXML else "html.parser"
    soup = BeautifulSoup(raw_html, parser_name)

    for bad in soup.find_all(["head", "script", "style", "noscript", "svg", "canvas", "iframe", "form", "dialog", "template"]):
        bad.decompose()
    for comment in soup.find_all(string=lambda t: isinstance(t, Comment)):
        comment.extract()

    for tag in list(soup.find_all(True)):
        if tag.decomposed or tag.name in ("html", "body", "main", "article"):
            continue
        if tag.find(["article", "main"]):
            continue
        attr_str = " ".join([
            str(tag.name or ""),
            " ".join(tag.get("class") or []),
            str(tag.get("id") or ""),
            str(tag.get("role") or ""),
            str(tag.get("aria-label") or ""),
        ])
        if _is_boilerplate_attr(tag.name, attr_str):
            tag.decompose()

    best_node = soup.body or soup
    best_score = -1.0

    candidates = soup.find_all(["article", "main", "section", "div", "td"])
    for cand in candidates:
        text = cand.get_text(" ", strip=True)
        tlen = len(text)
        if tlen < 60:
            continue
        link_chars = sum(len(a.get_text(" ", strip=True)) for a in cand.find_all("a"))
        link_density = link_chars / float(max(1, tlen))
        if link_density > 0.65:
            continue

        p_tags = cand.find_all(["p", "pre", "blockquote", "li", "td", "h2", "h3", "h4"])
        p_text_len = sum(len(p.get_text(" ", strip=True)) for p in p_tags)
        commas = text.count(",") + text.count(". ") + text.count("; ") + text.count(": ")

        bonus = 1.0
        tname = (cand.name or "").lower()
        attr_blob = " ".join([
            " ".join(cand.get("class") or []),
            str(cand.get("id") or ""),
            str(cand.get("role") or ""),
            str(cand.get("itemprop") or ""),
        ]).lower()

        if tname == "article" or "articlebody" in attr_blob:
            bonus *= 1.65
        elif tname == "main" or 'role="main"' in attr_blob or "main" in attr_blob:
            bonus *= 1.45
        if any(tok in attr_blob for tok in POSITIVE_CONTENT_TOKENS):
            bonus *= 1.35

        score = ((p_text_len * 1.2 + tlen * 0.45) + (commas * 18.0)) * (1.0 - link_density * 0.75) * bonus
        if score > best_score:
            best_score = score
            best_node = cand

    # Whole-page preservation: if best_node is a narrow child (<article> or <div>) that holds
    # less than 55% of the cleaned body prose (e.g. a page with a main post PLUS comments,
    # reviews, or multiple product sections), step up to <main> or <body> so no section is lost!
    body_node = soup.find("main") or soup.body or soup
    body_text_len = len(body_node.get_text(" ", strip=True))
    best_text_len = len(best_node.get_text(" ", strip=True)) if best_node else 0
    if body_text_len > 0 and best_text_len < (body_text_len * 0.55):
        best_node = body_node

    links_out: List[ExtractedLink] = []
    images_out: List[ExtractedImage] = []
    seen_links: set = set()
    seen_images: set = set()

    h1_prefix = ""
    if not best_node.find("h1"):
        top_h1 = soup.find("h1")
        if top_h1:
            h1_txt = strip_tags(top_h1.get_text(" ", strip=True))
            if h1_txt:
                h1_prefix = f"# {h1_txt}\n\n"

    md = h1_prefix + _bs4_node_to_markdown(
        best_node, base_url, links_out, images_out, seen_links, seen_images
    )
    md = clean_markdown(md)
    text = markdown_to_text(md)
    return md, text, links_out, images_out, f"bs4_{parser_name}"


# ---- Zero-Dependency Stdlib HTML DOM Extractor ----------------------------

def _stdlib_node_to_markdown(
    node: Any,
    base_url: str,
    links_out: List[ExtractedLink],
    images_out: List[ExtractedImage],
    seen_links: set,
    seen_images: set,
) -> str:
    if isinstance(node, str):
        return node
    if not isinstance(node, _StdlibDOMNode):
        return ""
    t = node.tag
    if t in ("head", "title", "meta", "link", "script", "style", "noscript", "svg", "canvas", "iframe", "form", "button", "template"):
        return ""
    attr_str = " ".join([
        t,
        node.attrs.get("class", ""),
        node.attrs.get("id", ""),
        node.attrs.get("role", ""),
    ])
    if _is_boilerplate_attr(t, attr_str):
        return ""
    if t == "br":
        return "\n"
    if t == "hr":
        return "\n\n---\n\n"
    if t == "img":
        src = resolve_url(base_url, node.attrs.get("src") or node.attrs.get("data-src") or "")
        alt = node.attrs.get("alt", "").strip()
        if src and not src.startswith("data:"):
            if src not in seen_images:
                seen_images.add(src)
                images_out.append(ExtractedImage(alt=alt, url=src))
            return f"![{alt or 'image'}]({src})"
        return ""
    if t == "pre":
        return f"\n\n```\n{node.text_content().strip()}\n```\n\n"

    inner = "".join(
        _stdlib_node_to_markdown(ch, base_url, links_out, images_out, seen_links, seen_images)
        for ch in node.children
    )
    if t in ("h1", "h2", "h3", "h4", "h5", "h6"):
        lvl = int(t[1])
        clean_h = re.sub(r"\s+", " ", inner).strip()
        return f"\n\n{'#' * lvl} {clean_h}\n\n" if clean_h else ""
    if t == "p":
        clean_p = inner.strip()
        return f"\n\n{clean_p}\n\n" if clean_p else ""
    if t == "li":
        clean_li = re.sub(r"\s+", " ", inner).strip()
        return f"\n- {clean_li}" if clean_li else ""
    if t == "blockquote":
        clean_q = inner.strip()
        return f"\n\n> {clean_q}\n\n" if clean_q else ""
    if t in ("strong", "b"):
        return f"**{inner.strip()}**" if inner.strip() else ""
    if t in ("em", "i"):
        return f"*{inner.strip()}*" if inner.strip() else ""
    if t == "code":
        return f"`{inner.strip()}`" if inner.strip() else ""
    if t == "a":
        href = resolve_url(base_url, node.attrs.get("href", ""))
        anchor = re.sub(r"\s+", " ", inner).strip()
        if href and anchor:
            if href not in seen_links:
                seen_links.add(href)
                links_out.append(ExtractedLink(text=anchor[:200], url=href))
            return f"[{anchor}]({href})"
        return inner
    if t in ("div", "section", "article", "main", "ul", "ol", "table", "tr"):
        return f"\n{inner}\n"
    return inner


def _extract_with_stdlib(
    raw_html: str, base_url: str
) -> Tuple[str, str, List[ExtractedLink], List[ExtractedImage], str]:
    builder = _StdlibTreeBuilder()
    builder.feed(raw_html or "")
    links_out: List[ExtractedLink] = []
    images_out: List[ExtractedImage] = []
    seen_links: set = set()
    seen_images: set = set()
    md = _stdlib_node_to_markdown(
        builder.root, base_url, links_out, images_out, seen_links, seen_images
    )
    md = clean_markdown(md)
    text = markdown_to_text(md)
    return md, text, links_out, images_out, "stdlib_dom"


# ---- Unified Multi-Parser HTML Extraction Cascade -------------------------

def extract_from_html(
    raw_html: str,
    url: str,
    final_url: str = "",
    status_code: int = 200,
    content_type: str = "text/html",
) -> ExtractOutcome:
    base_url = final_url or url
    meta = _extract_meta_tags(raw_html, base_url)
    ld_blocks, ld_meta = _extract_json_ld(raw_html)

    title = meta["title"] or ld_meta.get("title", "")
    description = meta["description"] or ld_meta.get("description", "")
    author = meta["author"] or ld_meta.get("author", "")
    published_date = meta["published_date"] or ld_meta.get("published_date", "")
    site_name = meta["site_name"] or ld_meta.get("site_name", "")
    if not site_name and base_url:
        host = (urllib.parse.urlparse(base_url).netloc or "").lower()
        site_name = host[4:] if host.startswith("www.") else host

    candidates: List[Tuple[str, str, List[ExtractedLink], List[ExtractedImage], str]] = []

    if HAVE_TRAFILATURA and _trafilatura_mod is not None:
        try:
            traf_md = _trafilatura_mod.extract(
                raw_html,
                url=base_url,
                output_format="markdown",
                include_links=True,
                include_images=True,
                include_tables=True,
            )
            if traf_md and len(traf_md.strip()) >= 80:
                candidates.append((clean_markdown(traf_md), markdown_to_text(traf_md), [], [], "trafilatura"))
        except Exception:
            pass

    if HAVE_READABILITY and _ReadabilityDoc is not None:
        try:
            doc = _ReadabilityDoc(raw_html)
            summary_html = doc.summary()
            if summary_html:
                if HAVE_BS4:
                    md_r, txt_r, l_r, img_r, _ = _extract_with_bs4(summary_html, base_url)
                else:
                    md_r, txt_r, l_r, img_r, _ = _extract_with_stdlib(summary_html, base_url)
                if len(txt_r) >= 80:
                    candidates.append((md_r, txt_r, l_r, img_r, "readability"))
        except Exception:
            pass

    if HAVE_BS4:
        try:
            candidates.append(_extract_with_bs4(raw_html, base_url))
        except Exception as e:
            logger.debug("bs4 extractor error: %s", e)

    if not candidates or len(candidates[-1][1]) < 120:
        try:
            candidates.append(_extract_with_stdlib(raw_html, base_url))
        except Exception as e:
            logger.debug("stdlib extractor error: %s", e)

    ld_body = ld_meta.get("article_body", "").strip()
    if len(ld_body) >= 120:
        ld_txt = strip_tags(ld_body)
        ld_md = f"# {title}\n\n{ld_txt}" if title else ld_txt
        candidates.append((clean_markdown(ld_md), ld_txt, [], [], "json_ld"))

    ssr_body = _extract_ssr_payload_text(raw_html)
    if len(ssr_body) >= 160:
        ssr_md = f"# {title}\n\n{ssr_body}" if title else ssr_body
        candidates.append((clean_markdown(ssr_md), markdown_to_text(ssr_md), [], [], "nextjs_ssr"))

    best_md, best_txt, best_links, best_imgs, best_parser = "", "", [], [], "none"
    best_q = -1.0
    for md_c, txt_c, links_c, imgs_c, parser_c in candidates:
        probe = ExtractOutcome(
            url=url, title=title, description=description, author=author,
            published_date=published_date, markdown=md_c, text=txt_c,
            structured_data=ld_blocks,
        )
        q = score_extraction_quality(probe)
        tie_breaker = min(0.08, len(txt_c) / 50000.0) + (0.02 if links_c else 0.0)
        if (q + tie_breaker) > best_q:
            best_q = q + tie_breaker
            best_md, best_txt, best_links, best_imgs, best_parser = (
                md_c, txt_c, links_c, imgs_c, parser_c
            )

    if meta.get("og_image") and all(img.url != meta["og_image"] for img in best_imgs):
        best_imgs.insert(0, ExtractedImage(alt=title or "og:image", url=meta["og_image"]))

    words = word_tokens(best_txt)
    word_count = len(words)
    reading_time = round(word_count / 200.0, 2) if word_count else 0.0

    out = ExtractOutcome(
        url=url,
        final_url=meta.get("canonical_url") or final_url or url,
        title=title,
        author=author,
        published_date=published_date,
        site_name=site_name,
        description=description,
        language=meta.get("language", ""),
        markdown=best_md,
        text=best_txt,
        excerpt=make_excerpt(best_txt or description),
        word_count=word_count,
        reading_time_min=reading_time,
        links=best_links[:250],
        images=best_imgs[:50],
        structured_data=ld_blocks,
        status_code=status_code,
        content_type=content_type,
        parser=best_parser,
    )
    out.quality = score_extraction_quality(out)
    return out


# ---- PDF Extractor --------------------------------------------------------

def extract_from_pdf_bytes(
    pdf_bytes: bytes, url: str, final_url: str = "", status_code: int = 200
) -> ExtractOutcome:
    pages_text: List[str] = []
    parser_used = ""
    title = ""

    if HAVE_PYPDF and _pypdf_mod is not None:
        try:
            reader = _pypdf_mod.PdfReader(io.BytesIO(pdf_bytes))
            if reader.metadata and getattr(reader.metadata, "title", None):
                title = str(reader.metadata.title).strip()
            for i, p in enumerate(reader.pages, 1):
                t = (p.extract_text() or "").strip()
                if t:
                    pages_text.append(f"## Page {i}\n\n{t}")
            if pages_text:
                parser_used = "pypdf"
        except Exception as e:
            logger.debug("pypdf failed: %s", e)

    if not pages_text and HAVE_PDFPLUMBER and _pdfplumber_mod is not None:
        try:
            with _pdfplumber_mod.open(io.BytesIO(pdf_bytes)) as pdf:
                for i, p in enumerate(pdf.pages, 1):
                    t = (p.extract_text() or "").strip()
                    if t:
                        pages_text.append(f"## Page {i}\n\n{t}")
            if pages_text:
                parser_used = "pdfplumber"
        except Exception as e:
            logger.debug("pdfplumber failed: %s", e)

    if not pages_text and HAVE_PDFIUM and _pdfium_mod is not None:
        try:
            doc = _pdfium_mod.PdfDocument(pdf_bytes)
            for i in range(len(doc)):
                page = doc[i]
                textpage = page.get_textpage()
                t = (textpage.get_text_range() or "").strip()
                if t:
                    pages_text.append(f"## Page {i + 1}\n\n{t}")
            doc.close()
            if pages_text:
                parser_used = "pypdfium2"
        except Exception as e:
            logger.debug("pypdfium2 failed: %s", e)

    if not pages_text:
        raise BackendDown("pdf:no-extractable-text-or-no-pdf-library")

    if not title:
        path_name = urllib.parse.urlparse(final_url or url).path.rsplit("/", 1)[-1]
        title = urllib.parse.unquote(path_name) or "PDF Document"

    md = f"# {title}\n\n" + "\n\n".join(pages_text)
    md = clean_markdown(md)
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url,
        final_url=final_url or url,
        title=title[:300],
        markdown=md,
        text=txt,
        excerpt=make_excerpt(txt),
        word_count=len(words),
        reading_time_min=round(len(words) / 200.0, 2),
        status_code=status_code,
        content_type="application/pdf",
        parser=parser_used,
    )
    out.quality = score_extraction_quality(out)
    return out


# ---------------------------------------------------------------------------
# SQLite Result Cache
# ---------------------------------------------------------------------------

class ResultCache:
    """Thread-safe persistent SQLite WAL cache for extracted pages."""

    def __init__(self, path: Optional[str] = None, ttl: Optional[int] = None):
        self.path = path if path is not None else os.getenv(
            "EXTRACT_CACHE_DB",
            os.path.join(os.path.expanduser("~"), ".free_extract_cache.sqlite3"),
        )
        self.ttl = ttl if ttl is not None else _env_int("EXTRACT_CACHE_TTL", 7 * 86400)
        self.enabled = _env_bool("EXTRACT_CACHE_ENABLED", True) and self.ttl > 0
        self._lock = threading.Lock()
        self._local = threading.local()
        self.hits = 0
        self.misses = 0
        if self.enabled:
            self._init_db()

    def _open_sqlite(self, db_path: str) -> sqlite3.Connection:
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
        c = sqlite3.connect(db_path, timeout=30, check_same_thread=False)
        try:
            c.execute("PRAGMA journal_mode=WAL")
        except sqlite3.OperationalError:
            c.execute("PRAGMA journal_mode=MEMORY")
        c.execute("PRAGMA synchronous=NORMAL")
        return c

    def _conn(self) -> sqlite3.Connection:
        c = getattr(self._local, "conn", None)
        if c is None:
            try:
                c = self._open_sqlite(self.path)
            except sqlite3.OperationalError:
                self.path = os.path.join(tempfile.gettempdir(), ".free_extract_cache.sqlite3")
                c = self._open_sqlite(self.path)
            self._local.conn = c
        return c

    def _init_db(self) -> None:
        schema = (
            "CREATE TABLE IF NOT EXISTS extract_cache("
            "  k TEXT PRIMARY KEY, url TEXT, v TEXT NOT NULL, ts REAL NOT NULL,"
            "  backend TEXT, quality REAL);"
            "CREATE INDEX IF NOT EXISTS extract_cache_ts ON extract_cache(ts);"
        )
        with self._lock:
            try:
                self._conn().executescript(schema)
                self._conn().commit()
            except sqlite3.OperationalError:
                self._local.conn = None
                self.path = os.path.join(tempfile.gettempdir(), ".free_extract_cache.sqlite3")
                self._conn().executescript(schema)
                self._conn().commit()

    @staticmethod
    def key(url: str, backend: str = "auto") -> str:
        norm = normalize_url(url)
        raw = json.dumps([norm, backend or "auto", VERSION], ensure_ascii=False, sort_keys=True)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:40]

    def get(self, k: str) -> Optional[Dict[str, Any]]:
        if not self.enabled:
            return None
        try:
            with self._lock:
                row = self._conn().execute(
                    "SELECT v, ts FROM extract_cache WHERE k=?", (k,)
                ).fetchone()
            if not row:
                self.misses += 1
                return None
            if (time.time() - row[1]) > self.ttl:
                self.misses += 1
                return None
            self.hits += 1
            return json.loads(row[0])
        except Exception:
            self.misses += 1
            return None

    def put(self, k: str, outcome: ExtractOutcome) -> None:
        if not self.enabled or outcome.deferred or not (outcome.text or outcome.markdown):
            return
        try:
            payload = outcome.to_dict()
            with self._lock:
                self._conn().execute(
                    "INSERT OR REPLACE INTO extract_cache(k,url,v,ts,backend,quality) "
                    "VALUES(?,?,?,?,?,?)",
                    (
                        k,
                        outcome.url,
                        json.dumps(payload, ensure_ascii=False),
                        time.time(),
                        outcome.backend,
                        outcome.quality,
                    ),
                )
                self._conn().commit()
        except Exception:
            pass

    def prune(self) -> int:
        if not self.enabled:
            return 0
        with self._lock:
            cur = self._conn().execute(
                "DELETE FROM extract_cache WHERE ts < ?", (time.time() - self.ttl,)
            )
            self._conn().commit()
            return cur.rowcount or 0

    def size(self) -> int:
        try:
            with self._lock:
                return self._conn().execute("SELECT COUNT(*) FROM extract_cache").fetchone()[0]
        except Exception:
            return 0


# ---------------------------------------------------------------------------
# Egress Tier 2: Fast Bounded Public Proxy Pool
# ---------------------------------------------------------------------------

class ProxyPool:
    """Free public HTTP proxy pool with fast, bounded validation (never blocks
    for 80+ seconds on a single query: tests a small batch with a 3.5s fuse and
    stops as soon as `pool_max` working proxies respond)."""

    def __init__(self, probe_url: Optional[str] = None):
        self.probe_url = probe_url or os.getenv(
            "EXTRACT_PROXY_PROBE_URL", "https://httpbin.org/ip"
        )
        self._lock = threading.Lock()
        self._pool: List[str] = []
        self._idx = 0
        self._dead: set = set()
        self._builds = 0
        self._last_build = 0.0
        self._validated_at: Dict[str, float] = {}
        self.max_builds = max(1, _env_int("PROXY_MAX_BUILDS_PER_RUN", 6))
        self.pool_max = max(1, _env_int("PROXY_POOL_MAX", 15))
        self.validate_limit = _env_int("PROXY_VALIDATE_LIMIT", 180)
        self.validate_workers = _env_int("PROXY_VALIDATE_WORKERS", 90)
        self.validate_timeout = _env_float("PROXY_VALIDATE_TIMEOUT", 3.5)
        self.state_file = os.getenv(
            "EXTRACT_PROXY_STATE_FILE",
            os.path.join(os.path.expanduser("~"), ".free_extract_proxies.json"),
        )

    @staticmethod
    def parse_candidates(text: str) -> List[str]:
        out: List[str] = []
        for line in (text or "").splitlines():
            s = line.strip()
            for prefix in ("http://", "https://"):
                if s.lower().startswith(prefix):
                    s = s[len(prefix):]
                    break
            s = s.split()[0] if s else s
            if _PROXY_LINE.match(s):
                try:
                    port = int(s.rsplit(":", 1)[1])
                except ValueError:
                    continue
                if 1 <= port <= 65535:
                    out.append(s)
        return list(dict.fromkeys(out))

    def _sources(self) -> List[str]:
        return _env_list("PROXY_SOURCES", DEFAULT_PROXY_SOURCES)

    def harvest(self, per_source_timeout: int = 5) -> List[str]:
        sources = self._sources()
        found: Dict[str, str] = {}
        hdr = {"User-Agent": BROWSER_UA}

        def _grab(url: str) -> Tuple[str, List[str]]:
            try:
                r = requests.get(url, timeout=per_source_timeout, headers=hdr)
                if r.status_code == 200:
                    return url, self.parse_candidates(r.text)
            except Exception:
                pass
            return url, []

        with ThreadPoolExecutor(max_workers=min(6, len(sources))) as ex:
            for url, cands in ex.map(_grab, sources):
                for c in cands:
                    found.setdefault(c, url)
        out = list(found.keys())
        random.shuffle(out)
        logger.debug("proxy candidates harvested: %d unique (from %d sources)", len(out), len(sources))
        return out

    def _try_proxy(self, candidate: str, timeout: Optional[float] = None) -> Optional[float]:
        timeout = timeout or self.validate_timeout
        purl = f"http://{candidate}"
        try:
            t0 = time.time()
            r = requests.get(
                self.probe_url,
                proxies={"http": purl, "https": purl},
                timeout=timeout,
                headers={"User-Agent": BROWSER_UA},
                allow_redirects=True,
            )
            if r.status_code == 200 and (r.text or "").strip():
                walled, _ = looks_walled_html(r.status_code, r.text)
                if not walled:
                    return time.time() - t0
        except Exception:
            pass
        return None

    def validate(
        self,
        candidates: Sequence[str],
        limit: Optional[int] = None,
        workers: Optional[int] = None,
    ) -> List[Tuple[str, float]]:
        limit = limit or self.validate_limit
        workers = workers or self.validate_workers
        cands = list(candidates)[:limit]
        if not cands:
            return []
        scored: List[Tuple[str, float]] = []
        ex = ThreadPoolExecutor(max_workers=min(workers, len(cands)))
        try:
            futs = {ex.submit(self._try_proxy, c): c for c in cands}
            for fut in as_completed(futs):
                try:
                    lat = fut.result()
                except Exception:
                    lat = None
                if lat is not None:
                    scored.append((futs[fut], lat))
                    if len(scored) >= self.pool_max:
                        break
        finally:
            ex.shutdown(wait=False, cancel_futures=True)
        scored.sort(key=lambda t: t[1])
        return scored

    def _load_state(self) -> bool:
        max_age = _env_int("PROXY_STATE_MAX_AGE", 1800)
        try:
            with open(self.state_file, "r", encoding="utf-8") as fh:
                st = json.load(fh)
            if time.time() - float(st.get("ts", 0)) > max_age:
                return False
            pool = [p for p in st.get("pool", []) if isinstance(p, str)]
            if not pool:
                return False
            with self._lock:
                self._pool = pool
                self._idx = 0
                self._dead = set()
                self._validated_at = st.get("validated_at", {}) or {}
            return True
        except Exception:
            return False

    def _save_state(self) -> None:
        try:
            with self._lock:
                payload = {
                    "ts": time.time(),
                    "pool": list(self._alive()),
                    "validated_at": dict(self._validated_at),
                }
            with open(self.state_file, "w", encoding="utf-8") as fh:
                json.dump(payload, fh)
        except Exception:
            pass

    def build(self, force: bool = False) -> bool:
        with self._lock:
            if self._pool and self._alive() and not force:
                return True
            if self._builds >= self.max_builds:
                return False
            if not force and (time.time() - self._last_build) < 20 and self._alive():
                return True
            self._builds += 1
            self._last_build = time.time()
        cands = self.harvest()
        if not cands:
            return False
        scored = self.validate(cands)
        pool = [c for c, _ in scored[: self.pool_max]]
        now = time.time()
        with self._lock:
            self._pool = pool
            self._idx = 0
            self._dead = set()
            for c, _ in scored[: self.pool_max]:
                self._validated_at[c] = now
        if pool:
            self._save_state()
            return True
        return False

    def ensure(self) -> bool:
        if self._load_state():
            return True
        return self.build()

    def _alive(self) -> List[str]:
        return [p for p in self._pool if p not in self._dead]

    def next(self) -> Optional[str]:
        with self._lock:
            pool = self._pool
            if not pool:
                return None
            for _ in range(len(pool)):
                p = pool[self._idx % len(pool)]
                self._idx += 1
                if p not in self._dead:
                    return p
            return None

    def mark_dead(self, proxy: str) -> None:
        with self._lock:
            self._dead.add(proxy)

    def mark_ok(self, proxy: str) -> None:
        with self._lock:
            self._dead.discard(proxy)
            self._validated_at[proxy] = time.time()

    def alive_count(self) -> int:
        with self._lock:
            return len(self._alive())

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "pool": len(self._pool),
                "alive": len(self._alive()),
                "dead": len(self._dead),
                "builds": self._builds,
            }


# ---------------------------------------------------------------------------
# Backend Health (Circuit Breakers + AIMD Pacing) & Per-Domain Limiter
# ---------------------------------------------------------------------------

@dataclass
class BackendHealth:
    name: str
    ok: int = 0
    fail: int = 0
    walls: int = 0
    chars_extracted: int = 0
    consecutive_fail: int = 0
    cooldown_until: float = 0.0
    strikes: int = 0
    last_error: str = ""
    total_ms: float = 0.0
    rate: float = 0.0
    base_rate: float = 0.0
    rate_min: float = 0.05
    rate_max: float = 8.0
    rate_inc: float = 0.04
    _bucket: float = field(default=0.0, repr=False)
    _last: float = field(default=0.0, repr=False)

    def __post_init__(self):
        if self.rate and not self.base_rate:
            self.base_rate = self.rate
        self.rate_max = max(self.rate_max, self.base_rate * 4)

    def ready(self) -> bool:
        return time.time() >= self.cooldown_until

    def trip(self, err: str, wall: bool = False) -> None:
        self.fail += 1
        self.consecutive_fail += 1
        self.last_error = err[:200]
        if wall:
            self.walls += 1
        if self.rate > 0:
            self.rate = max(self.rate_min, self.rate * (0.4 if wall else 0.65))
        trip_after = max(1, _env_int("BACKEND_TRIP_AFTER", 4))
        if self.consecutive_fail >= trip_after:
            self.strikes += 1
            base = _env_float("BACKEND_COOLDOWN", 45.0)
            cool = min(base * (2 ** (self.strikes - 1)), _env_float("BACKEND_COOLDOWN_MAX", 1200.0))
            self.cooldown_until = time.time() + cool
            self.consecutive_fail = 0

    def note_ok(self, chars: int, ms: float) -> None:
        self.ok += 1
        self.chars_extracted += chars
        self.total_ms += ms
        self.consecutive_fail = 0
        if self.strikes and self.ok % 4 == 0:
            self.strikes = max(0, self.strikes - 1)
            self.cooldown_until = min(self.cooldown_until, time.time())
        if self.rate > 0:
            self.rate = min(self.rate_max, self.rate + self.rate_inc)

    def acquire(self) -> float:
        if self.rate <= 0:
            return 0.0
        now = time.time()
        if self._last == 0.0:
            self._bucket = 1.0
            self._last = now
        self._bucket = min(2.0, self._bucket + (now - self._last) * self.rate)
        self._last = now
        if self._bucket >= 1.0:
            self._bucket -= 1.0
            return 0.0
        wait = (1.0 - self._bucket) / self.rate
        time.sleep(wait)
        self._bucket = 0.0
        self._last = time.time()
        return wait


class DomainLimiter:
    def __init__(self, min_interval_s: float = 0.20):
        self.min_interval_s = max(0.0, float(min_interval_s))
        self._lock = threading.Lock()
        self._next_allowed: Dict[str, float] = {}

    def wait(self, url: str) -> float:
        if self.min_interval_s <= 0:
            return 0.0
        host = (urllib.parse.urlparse(url).netloc or "").lower()
        if not host:
            return 0.0
        with self._lock:
            now = time.time()
            ready_at = self._next_allowed.get(host, 0.0)
            if now >= ready_at:
                self._next_allowed[host] = now + self.min_interval_s
                return 0.0
            sleep_s = ready_at - now
            self._next_allowed[host] = ready_at + self.min_interval_s
        if sleep_s > 0:
            time.sleep(sleep_s)
        return sleep_s


# ---------------------------------------------------------------------------
# Transport Helpers & Specialised Site Extractors (YouTube, Reddit, GitHub, Wiki)
# ---------------------------------------------------------------------------

def _mk_session(
    proxy: Optional[str] = None,
    try_index: int = 0,
) -> requests.Session:
    s = requests.Session()
    s.trust_env = False
    if proxy:
        purl = f"http://{proxy}" if "://" not in proxy else proxy
        s.proxies = {"http": purl, "https": purl}
    s.headers.update(BROWSER_HEADERS)
    s.headers["User-Agent"] = USER_AGENTS[try_index % len(USER_AGENTS)]
    s.headers["Referer"] = SEARCH_REFERERS[try_index % len(SEARCH_REFERERS)]
    return s


def _apply_relay(url: str, relay: Optional[Tuple[str, str]]) -> str:
    if not relay:
        return url
    return relay[1].format(url=urllib.parse.quote(url, safe=""))


def _http_get(
    url: str,
    sess: requests.Session,
    timeout: float = 12.0,
    relay: Optional[Tuple[str, str]] = None,
    proxy: Optional[str] = None,
    **kw,
) -> requests.Response:
    target = _apply_relay(url, relay)
    req_timeout = (min(5.0, timeout * 0.5), timeout) if isinstance(timeout, (int, float)) else timeout
    if HAVE_CURL_CFFI and curl_requests is not None and not relay:
        try:
            px = None
            if proxy:
                purl = f"http://{proxy}" if "://" not in proxy else proxy
                px = {"http": purl, "https": purl}
            hdrs = dict(sess.headers)
            if kw.get("headers"):
                hdrs.update(kw["headers"])
            r_cffi = curl_requests.get(
                target,
                impersonate="chrome124",
                timeout=timeout,
                proxies=px,
                headers=hdrs,
                allow_redirects=True,
            )
            if r_cffi.status_code not in WALL_CODES and r_cffi.status_code < 400:
                return r_cffi  # type: ignore
        except Exception:
            pass
    try:
        r = sess.get(target, timeout=req_timeout, allow_redirects=True, **kw)
    except requests.RequestException as e:
        msg = str(e).lower()
        if proxy and any(k in msg for k in ("proxy", "tunnel", "connect", "timed out", "timeout", "reset")):
            raise EgressRetry(f"proxy-failed:{type(e).__name__}") from e
        if relay:
            raise EgressRetry(f"relay-failed:{relay[0]}:{type(e).__name__}") from e
        raise BackendDown(f"transport:{type(e).__name__}:{str(e)[:80]}") from e

    if r.status_code in WALL_CODES:
        raise BotWalled(f"http:{r.status_code}")
    if r.status_code == 404 or r.status_code == 410:
        raise BackendDown(f"http:{r.status_code}")
    if r.status_code >= 500:
        raise BackendDown(f"http:{r.status_code}")
    return r


def _extract_balanced_json(text: str, marker: str) -> Optional[Dict[str, Any]]:
    """Find `marker` in `text` (e.g. `ytInitialPlayerResponse =`) and parse the
    following `{...}` JSON object using balanced brace counting."""
    idx = text.find(marker)
    if idx < 0:
        return None
    start = text.find("{", idx + len(marker))
    if start < 0 or (start - idx - len(marker)) > 40:
        return None
    depth = 0
    in_str = False
    esc = False
    for i in range(start, min(len(text), start + 600000)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[start : i + 1])
                    except Exception:
                        return None
    return None


def _try_youtube_special(
    url: str, sess: requests.Session, timeout: float, relay: Optional[Tuple[str, str]], proxy: Optional[str]
) -> Optional[ExtractOutcome]:
    """Dedicated YouTube video & shorts extractor: pulls full title, channel,
    publish date, view count, duration, full description, and captions/transcript
    from `ytInitialPlayerResponse` + oEmbed so YouTube URLs never return footer links."""
    p = urllib.parse.urlparse(url)
    host = (p.netloc or "").lower()
    if host.startswith("www."):
        host = host[4:]
    if host not in ("youtube.com", "m.youtube.com", "youtu.be"):
        return None

    video_id = ""
    if host == "youtu.be":
        video_id = p.path.strip("/").split("/")[0]
    elif "/watch" in p.path:
        qs = urllib.parse.parse_qs(p.query)
        video_id = (qs.get("v") or [""])[0]
    elif "/shorts/" in p.path or "/embed/" in p.path:
        parts = [x for x in p.path.split("/") if x]
        if len(parts) >= 2:
            video_id = parts[1]

    if not video_id:
        return None

    watch_url = f"https://www.youtube.com/watch?v={video_id}&hl=en"
    # Bypass EU/regional YouTube consent wall with SOCS cookie
    yt_headers = {
        "Accept-Language": "en-US,en;q=0.9",
        "Cookie": "CONSENT=YES+cb.20210328-17-p0.en+FX+417; SOCS=CAISHAgBEhJnd3NfMjAyMzA4MTUtMF9SQzIaAmVuIAEaBgiAo_CmBg",
    }

    title = ""
    author = ""
    description = ""
    pub_date = ""
    views = ""
    duration_s = 0
    keywords: List[str] = []
    transcript_text = ""
    thumb_url = f"https://i.ytimg.com/vi/{video_id}/maxresdefault.jpg"

    # 1. Try watch page HTML for ytInitialPlayerResponse
    try:
        r = _http_get(watch_url, sess, timeout=timeout, relay=relay, proxy=proxy, headers=yt_headers)
        html_text = _decode_response_text(r)
        player = (
            _extract_balanced_json(html_text, "var ytInitialPlayerResponse =")
            or _extract_balanced_json(html_text, "ytInitialPlayerResponse =")
        )
        if isinstance(player, dict):
            vd = player.get("videoDetails") or {}
            title = str(vd.get("title") or "").strip()
            author = str(vd.get("author") or "").strip()
            description = str(vd.get("shortDescription") or "").strip()
            views = str(vd.get("viewCount") or "").strip()
            duration_s = int(vd.get("lengthSeconds") or 0)
            if isinstance(vd.get("keywords"), list):
                keywords = [str(k) for k in vd["keywords"][:20]]

            mf = ((player.get("microformat") or {}).get("playerMicroformatRenderer") or {})
            pub_date = str(mf.get("publishDate") or mf.get("uploadDate") or "").strip()
            if not description and isinstance(mf.get("description"), dict):
                description = str(mf["description"].get("simpleText") or "").strip()

            # Check for caption tracks (transcript)
            captions = (
                ((player.get("captions") or {}).get("playerCaptionsTracklistRenderer") or {})
                .get("captionTracks") or []
            )
            if captions and isinstance(captions, list):
                # Prefer English track if available
                chosen = captions[0]
                for tr in captions:
                    if str(tr.get("languageCode") or "").startswith("en"):
                        chosen = tr
                        break
                base_cap_url = str(chosen.get("baseUrl") or "")
                if base_cap_url:
                    try:
                        r_cap = _http_get(base_cap_url, sess, timeout=6.0, relay=relay, proxy=proxy)
                        cap_xml = _decode_response_text(r_cap)
                        lines_cap = [
                            strip_tags(m.group(1))
                            for m in re.finditer(r"<text[^>]*>(.*?)</text>", cap_xml, re.S)
                        ]
                        lines_cap = [ln for ln in lines_cap if ln]
                        if lines_cap:
                            transcript_text = " ".join(lines_cap)
                    except Exception:
                        pass
    except Exception as e:
        logger.debug("youtube watch page fetch failed: %s", e)

    # 2. Fallback / supplement via YouTube oEmbed API
    if not title or not author:
        try:
            oembed_url = "https://www.youtube.com/oembed?" + urllib.parse.urlencode(
                {"url": f"https://www.youtube.com/watch?v={video_id}", "format": "json"}
            )
            r_oe = _http_get(oembed_url, sess, timeout=6.0, relay=relay, proxy=proxy)
            oe = r_oe.json()
            title = title or str(oe.get("title") or "").strip()
            author = author or str(oe.get("author_name") or "").strip()
            thumb_url = str(oe.get("thumbnail_url") or thumb_url)
        except Exception:
            pass

    if not title and not description:
        return None

    md_parts = [f"# {title or 'YouTube Video'}"]
    meta_items = []
    if author:
        meta_items.append(f"**Channel:** {author}")
    if pub_date:
        meta_items.append(f"**Published:** {pub_date}")
    if views:
        try:
            meta_items.append(f"**Views:** {int(views):,}")
        except ValueError:
            meta_items.append(f"**Views:** {views}")
    if duration_s:
        mins, secs = divmod(duration_s, 60)
        meta_items.append(f"**Duration:** {mins}m {secs}s")
    if meta_items:
        md_parts.append(" | ".join(meta_items))
    if thumb_url:
        md_parts.append(f"![{title or 'thumbnail'}]({thumb_url})")
    if description:
        md_parts.append(f"## Description\n\n{description}")
    if transcript_text:
        md_parts.append(f"## Transcript\n\n{transcript_text}")
    if keywords:
        md_parts.append(f"**Tags:** {', '.join(keywords)}")

    md = clean_markdown("\n\n".join(md_parts))
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url,
        final_url=f"https://www.youtube.com/watch?v={video_id}",
        title=title,
        author=author,
        published_date=pub_date,
        site_name="youtube.com",
        description=description[:600],
        markdown=md,
        text=txt,
        excerpt=make_excerpt(description or txt),
        word_count=len(words),
        reading_time_min=round(len(words) / 200.0, 2),
        images=[ExtractedImage(alt=title or "thumbnail", url=thumb_url)],
        status_code=200,
        content_type="text/html",
        backend="direct_http",
        parser="youtube_player",
    )
    out.quality = max(0.85, score_extraction_quality(out, min_words=8))
    return out


def _cdp_fetch_text_or_html(url: str, timeout: float = 15.0, proxy: Optional[str] = None) -> Tuple[str, str]:
    """Use local stealth headless Chrome/Edge to fetch a URL and return (document_html, body_inner_text)."""
    raw_html, _ = render_and_expand_with_cdp(url, timeout=timeout, proxy=proxy, max_clicks=6)
    m_pre = re.search(r"<pre[^>]*>(.*?)</pre>", raw_html, re.I | re.S)
    if m_pre:
        cand = htmllib.unescape(strip_tags(m_pre.group(1))).strip()
        if cand.startswith(("[", "{")):
            return raw_html, cand
    plain = strip_tags(raw_html).strip()
    if plain.startswith(("[", "{")):
        return raw_html, plain
    idx = plain.find("[{\"kind\":")
    if idx >= 0:
        return raw_html, plain[idx:]
    return raw_html, plain


def _walk_reddit_comments(children: List[Any], depth: int = 0, out_lines: Optional[List[str]] = None) -> List[str]:
    """Recursively walk Reddit JSON comment trees to extract all comments and nested subcomments."""
    if out_lines is None:
        out_lines = []
    for c in children or []:
        if not isinstance(c, dict) or c.get("kind") != "t1":
            continue
        cd = c.get("data") or {}
        body = str(cd.get("body") or "").strip()
        c_auth = str(cd.get("author") or "user").strip()
        c_score = cd.get("score")
        score_str = f" ({c_score} pts)" if c_score is not None else ""
        if body and body not in ("[deleted]", "[removed]"):
            if depth == 0:
                out_lines.append(f"### u/{c_auth}{score_str}\n\n{body}")
            else:
                indent = "  " * (depth - 1)
                prefix = ">" * min(depth, 4)
                clean_b = "\n".join(f"{indent}{prefix} {ln}" for ln in body.splitlines() if ln.strip())
                out_lines.append(f"{indent}{prefix} **u/{c_auth}{score_str}:**\n{clean_b}")
        replies = cd.get("replies")
        if isinstance(replies, dict):
            rep_children = (replies.get("data") or {}).get("children") or []
            if rep_children:
                _walk_reddit_comments(rep_children, depth + 1, out_lines)
    return out_lines


def _parse_reddit_json_data(data: Any, url: str) -> Optional[ExtractOutcome]:
    if not isinstance(data, list) or len(data) < 1:
        return None
    try:
        post = data[0]["data"]["children"][0]["data"]
    except Exception:
        return None
    title = str(post.get("title") or "Reddit Post").strip()
    author = str(post.get("author") or "").strip()
    sub = str(post.get("subreddit_name_prefixed") or "r/reddit").strip()
    score = post.get("score")
    num_comments = post.get("num_comments")
    selftext = str(post.get("selftext") or "").strip()
    created = post.get("created_utc")
    pub_date = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(created)) if created else ""

    md_parts = [
        f"# {title}",
        f"**{sub}** • Posted by u/{author}"
        + (f" • {score} points" if score is not None else "")
        + (f" • {num_comments} comments" if num_comments is not None else ""),
    ]
    if selftext:
        md_parts.append(selftext)

    # Extract media / image / gallery / video URLs
    post_url = str(post.get("url_overridden_by_dest") or post.get("url") or "")
    if post_url and "reddit.com/r/" not in post_url:
        if any(post_url.lower().endswith(ext) for ext in (".jpg", ".jpeg", ".png", ".gif", ".webp")):
            md_parts.append(f"![{title}]({post_url})")
        else:
            md_parts.append(f"**Media / Link:** [{post_url}]({post_url})")
    if post.get("is_video") and isinstance(post.get("media"), dict):
        vurl = ((post["media"].get("reddit_video") or {}).get("fallback_url")) or ""
        if vurl:
            md_parts.append(f"**Video Stream:** [{vurl}]({vurl})")
    if isinstance(post.get("media_metadata"), dict):
        for _mid, mval in post["media_metadata"].items():
            if isinstance(mval, dict) and isinstance(mval.get("s"), dict):
                iu = htmllib.unescape(str(mval["s"].get("u") or mval["s"].get("gif") or ""))
                if iu:
                    md_parts.append(f"![gallery image]({iu})")

    comment_lines: List[str] = []
    if len(data) > 1 and isinstance(data[1], dict):
        top_children = (data[1].get("data") or {}).get("children") or []
        _walk_reddit_comments(top_children, depth=0, out_lines=comment_lines)

    if comment_lines:
        md_parts.append(f"## Comments ({len(comment_lines)} extracted)\n\n" + "\n\n".join(comment_lines))

    # Do not accept if there are comments reported on the post (num_comments > 0) yet 0 comments were extracted and selftext is empty
    if not selftext and not comment_lines and (num_comments or 0) > 0:
        return None

    md = clean_markdown("\n\n".join(md_parts))
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url, final_url=url, title=title, author=author,
        published_date=pub_date, site_name="reddit.com",
        markdown=md, text=txt, excerpt=make_excerpt(selftext or txt),
        word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
        status_code=200, content_type="application/json",
        backend="direct_http", parser=f"reddit_json(comments={len(comment_lines)})",
    )
    out.quality = max(0.90, score_extraction_quality(out, min_words=10))
    return out


def _parse_reddit_html_full(raw_html: str, url: str) -> Optional[ExtractOutcome]:
    """Parse BOTH the main post AND all comments + nested subcomments from
    either `old.reddit.com` HTML or `www.reddit.com` (shreddit) HTML."""
    if not HAVE_BS4 or not raw_html:
        return None
    walled, _ = looks_walled_html(200, raw_html)
    if walled or "prove your humanity" in raw_html[:10000].lower():
        return None

    soup = BeautifulSoup(raw_html, "lxml" if HAVE_LXML else "html.parser")
    title = ""
    author = ""
    pub_date = ""
    md_parts: List[str] = []
    comment_blocks: List[str] = []

    # Case A: old.reddit.com DOM structure (.sitetable.linklisting + .commentarea)
    top_matter = soup.find("div", class_=re.compile(r"\btop-matter\b"))
    if top_matter:
        a_title = top_matter.find("a", class_=re.compile(r"\btitle\b"))
        if a_title:
            title = a_title.get_text(" ", strip=True)
        a_auth = top_matter.find("a", class_=re.compile(r"\bauthor\b"))
        if a_auth:
            author = a_auth.get_text(" ", strip=True)
        t_el = top_matter.find("time")
        if t_el and t_el.get("datetime"):
            pub_date = str(t_el.get("datetime"))

        md_parts.append(f"# {title or 'Reddit Thread'}")
        if author or pub_date:
            md_parts.append(f"**Posted by u/{author}** ({pub_date})")

        # Post selftext or media inside the first .thing.link
        link_thing = soup.find("div", class_=re.compile(r"\bthing\b.*\blink\b"))
        if link_thing:
            expando = link_thing.find("div", class_=re.compile(r"\busertext-body\b"))
            if expando:
                post_md, _, _, _, _ = _extract_with_bs4(str(expando), url)
                if post_md:
                    md_parts.append(post_md)
            media_img = link_thing.find("img", class_=re.compile(r"\bpreview\b"))
            if media_img and media_img.get("src"):
                md_parts.append(f"![post media]({resolve_url(url, str(media_img.get('src')))})")

        # Walk all comments & nested subcomments inside .commentarea
        c_area = soup.find("div", class_=re.compile(r"\bcommentarea\b"))
        if c_area:
            for c_thing in c_area.find_all("div", class_=re.compile(r"\bthing\b.*\bcomment\b")):
                entry = c_thing.find("div", class_=re.compile(r"\bentry\b"), recursive=False)
                if not entry:
                    continue
                c_auth_el = entry.find("a", class_=re.compile(r"\bauthor\b"))
                c_auth = c_auth_el.get_text(" ", strip=True) if c_auth_el else "user"
                c_score_el = entry.find("span", class_=re.compile(r"\bscore\b"))
                c_score = f" ({c_score_el.get_text(' ', strip=True)})" if c_score_el else ""
                c_body_el = entry.find("div", class_=re.compile(r"\busertext-body\b"))
                if not c_body_el:
                    continue
                c_text = c_body_el.get_text("\n", strip=True)
                if not c_text or c_text in ("[deleted]", "[removed]"):
                    continue
                # Determine nesting depth by counting parent .child containers
                depth = 0
                parent = c_thing.parent
                while parent is not None and parent != c_area:
                    if getattr(parent, "name", "") == "div" and "child" in (parent.get("class") or []):
                        depth += 1
                    parent = parent.parent
                if depth == 0:
                    comment_blocks.append(f"### u/{c_auth}{c_score}\n\n{c_text}")
                else:
                    indent = "  " * (depth - 1)
                    prefix = ">" * min(depth, 4)
                    lines = "\n".join(f"{indent}{prefix} {ln}" for ln in c_text.splitlines() if ln.strip())
                    comment_blocks.append(f"{indent}{prefix} **u/{c_auth}{c_score}:**\n{lines}")

    # Case B: www.reddit.com Shreddit WebComponents (<shreddit-post> + <shreddit-comment>)
    sh_post = soup.find("shreddit-post")
    if sh_post and not top_matter:
        title = str(sh_post.get("post-title") or "").strip()
        author = str(sh_post.get("author") or "").strip()
        score = str(sh_post.get("score") or "").strip()
        pub_date = str(sh_post.get("created-timestamp") or "").strip()
        content_href = str(sh_post.get("content-href") or "").strip()
        md_parts.append(f"# {title or 'Reddit Thread'}")
        md_parts.append(f"**Posted by u/{author}** • {score} points • {pub_date}")
        text_slot = sh_post.find(attrs={"slot": "text-body"})
        if text_slot:
            md_parts.append(text_slot.get_text("\n\n", strip=True))
        if content_href and "reddit.com/r/" not in content_href:
            md_parts.append(f"**Media / Link:** [{content_href}]({content_href})")

    for sh_c in soup.find_all("shreddit-comment"):
        c_auth = str(sh_c.get("author") or "user").strip()
        c_score = str(sh_c.get("score") or "").strip()
        depth = int(sh_c.get("depth") or 0)
        slot_c = sh_c.find(attrs={"slot": "comment"})
        c_text = slot_c.get_text("\n", strip=True) if slot_c else sh_c.get_text("\n", strip=True)
        if not c_text:
            continue
        score_tag = f" ({c_score} pts)" if c_score else ""
        if depth == 0:
            comment_blocks.append(f"### u/{c_auth}{score_tag}\n\n{c_text}")
        else:
            indent = "  " * (depth - 1)
            prefix = ">" * min(depth, 4)
            lines = "\n".join(f"{indent}{prefix} {ln}" for ln in c_text.splitlines() if ln.strip())
            comment_blocks.append(f"{indent}{prefix} **u/{c_auth}{score_tag}:**\n{lines}")

    if comment_blocks:
        md_parts.append(f"## Comments ({len(comment_blocks)} extracted)\n\n" + "\n\n".join(comment_blocks))

    if not md_parts or (not comment_blocks and len("\n".join(md_parts).split()) < 30):
        return None

    md = clean_markdown("\n\n".join(md_parts))
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url, final_url=url, title=title[:300], author=author,
        published_date=pub_date, site_name="reddit.com",
        markdown=md, text=txt, excerpt=make_excerpt(txt),
        word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
        status_code=200, content_type="text/html",
        backend="direct_http", parser=f"reddit_html(comments={len(comment_blocks)})",
    )
    out.quality = max(0.88, score_extraction_quality(out, min_words=10))
    return out


def _try_reddit_special(
    url: str, sess: requests.Session, timeout: float, relay: Optional[Tuple[str, str]], proxy: Optional[str]
) -> Optional[ExtractOutcome]:
    p = urllib.parse.urlparse(url)
    host = (p.netloc or "").lower()
    if not (host == "reddit.com" or host.endswith(".reddit.com") or host == "redd.it"):
        return None

    clean_path = p.path.rstrip("/")
    if not clean_path:
        return None

    best_outcome: Optional[ExtractOutcome] = None

    # Stage 1: Direct HTTP .json across api.reddit.com, www.reddit.com, old.reddit.com
    # Use a clean requests call without Sec-Fetch-Dest: document so Fastly doesn't flag header mismatch
    if "/comments/" in clean_path:
        for base_host in ("https://api.reddit.com", "https://www.reddit.com", "https://old.reddit.com"):
            json_url = f"{base_host}{clean_path}.json?raw_json=1&limit=200&depth=10"
            for ua in (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
                "python:website-extract:v1.3 (by /u/open_research_reader)",
            ):
                try:
                    r = requests.get(
                        _apply_relay(json_url, relay),
                        timeout=(5.0, min(10.0, timeout)),
                        headers={"User-Agent": ua, "Accept": "application/json"},
                        proxies=sess.proxies if proxy else None,
                    )
                    if r.status_code == 200:
                        out = _parse_reddit_json_data(r.json(), url)
                        if out is not None and "comments=" in out.parser and not out.parser.endswith("comments=0)"):
                            return out
                        if out is not None and best_outcome is None:
                            best_outcome = out
                except Exception:
                    pass

    # Stage 2: old.reddit.com full HTML (post + .commentarea recursive tree)
    old_url = f"https://old.reddit.com{clean_path}/?limit=200"
    try:
        r_old = requests.get(
            _apply_relay(old_url, relay),
            timeout=(5.0, min(10.0, timeout)),
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
                "Accept": "text/html,application/xhtml+xml",
                "Cookie": "over18=1",
            },
            proxies=sess.proxies if proxy else None,
        )
        if r_old.status_code == 200:
            out_old = _parse_reddit_html_full(_decode_response_text(r_old), url)
            if out_old is not None and "comments=" in out_old.parser and not out_old.parser.endswith("comments=0)"):
                return out_old
            if out_old is not None and (best_outcome is None or out_old.word_count > best_outcome.word_count):
                best_outcome = out_old
    except Exception:
        pass

    # Stage 3: Reddit .rss Atom feed (extracts OP + all comment <entry> items)
    try:
        rss_url = f"https://www.reddit.com{clean_path}.rss?limit=100"
        r_rss = requests.get(
            _apply_relay(rss_url, relay),
            timeout=(5.0, min(10.0, timeout)),
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
                "Accept": "application/atom+xml,application/xml,text/xml",
            },
            proxies=sess.proxies if proxy else None,
        )
        rss_text = _decode_response_text(r_rss)
        if "<feed" in rss_text[:600] and "<entry>" in rss_text:
            root = ET.fromstring(rss_text)
            ns = {"atom": "http://www.w3.org/2005/Atom"}
            feed_title = (root.findtext("atom:title", default="", namespaces=ns) or "").strip()
            entries = root.findall("atom:entry", ns)
            if entries:
                md_parts = [f"# {feed_title or 'Reddit Thread'}"]
                author_first = ""
                pub_first = ""
                comment_count = 0
                for idx, ent in enumerate(entries[:100]):
                    e_title = (ent.findtext("atom:title", default="", namespaces=ns) or "").strip()
                    e_auth_el = ent.find("atom:author/atom:name", ns)
                    e_auth = (e_auth_el.text if e_auth_el is not None and e_auth_el.text else "").strip()
                    e_date = (ent.findtext("atom:updated", default="", namespaces=ns) or "").strip()
                    e_content_el = ent.find("atom:content", ns)
                    e_content = "".join(e_content_el.itertext()) if e_content_el is not None else ""
                    clean_c = strip_tags(htmllib.unescape(e_content))
                    clean_c = re.sub(r"submitted by\s+/u/\S+\s*\[link\]\s*\[comments\]", "", clean_c, flags=re.I).strip()
                    if idx == 0:
                        author_first = e_auth
                        pub_first = e_date
                        header_line = f"**Posted by {e_auth}** ({e_date})"
                        md_parts.append(f"{header_line}\n\n{clean_c}" if clean_c else header_line)
                        if len(entries) > 1:
                            md_parts.append("## Comments")
                    else:
                        if clean_c:
                            comment_count += 1
                            md_parts.append(f"### {e_auth or e_title} ({e_date})\n\n{clean_c}")
                if comment_count > 0:
                    md = clean_markdown("\n\n".join(md_parts))
                    txt = markdown_to_text(md)
                    words = word_tokens(txt)
                    out_rss = ExtractOutcome(
                        url=url, final_url=url, title=feed_title[:300],
                        author=author_first, published_date=pub_first,
                        site_name="reddit.com", markdown=md, text=txt,
                        excerpt=make_excerpt(txt), word_count=len(words),
                        reading_time_min=round(len(words) / 200.0, 2),
                        status_code=200, content_type="application/atom+xml",
                        backend="direct_http", parser=f"reddit_rss(comments={comment_count})",
                    )
                    out_rss.quality = max(0.85, score_extraction_quality(out_rss, min_words=15))
                    return out_rss
                elif len(md_parts) >= 2 and best_outcome is None:
                    md = clean_markdown("\n\n".join(md_parts))
                    txt = markdown_to_text(md)
                    words = word_tokens(txt)
                    if len(words) >= 30:
                        best_outcome = ExtractOutcome(
                            url=url, final_url=url, title=feed_title[:300],
                            author=author_first, published_date=pub_first,
                            site_name="reddit.com", markdown=md, text=txt,
                            excerpt=make_excerpt(txt), word_count=len(words),
                            reading_time_min=round(len(words) / 200.0, 2),
                            status_code=200, content_type="application/atom+xml",
                            backend="direct_http", parser="reddit_rss(post_only)",
                            quality=0.75,
                        )
    except Exception:
        pass

    # Stage 4: Stealth CDP on .json or www.reddit.com (renders shreddit comments)
    if "/comments/" in clean_path:
        try:
            _, inner_json = _cdp_fetch_text_or_html(
                f"https://www.reddit.com{clean_path}.json?raw_json=1&limit=200&depth=10",
                timeout=max(12.0, timeout),
                proxy=proxy,
            )
            if inner_json.startswith("["):
                out_cdp = _parse_reddit_json_data(json.loads(inner_json), url)
                if out_cdp is not None:
                    out_cdp.parser = "cdp+" + out_cdp.parser
                    return out_cdp
        except Exception:
            pass

    return best_outcome


def _try_github_special(
    url: str, sess: requests.Session, timeout: float, relay: Optional[Tuple[str, str]], proxy: Optional[str]
) -> Optional[ExtractOutcome]:
    p = urllib.parse.urlparse(url)
    host = (p.netloc or "").lower()
    if host not in ("github.com", "www.github.com"):
        return None
    parts = [x for x in p.path.split("/") if x]
    if len(parts) >= 5 and parts[2] == "blob":
        owner, repo, _, branch = parts[:4]
        file_path = "/".join(parts[4:])
        raw_url = f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{file_path}"
        r = _http_get(raw_url, sess, timeout=timeout, relay=relay, proxy=proxy)
        text = _decode_response_text(r)
        if text.strip():
            ext = file_path.rsplit(".", 1)[-1].lower() if "." in file_path else ""
            title = f"{owner}/{repo}: {file_path}"
            if ext in ("md", "markdown", "rst", "txt"):
                md = clean_markdown(text)
                plain = markdown_to_text(md)
            else:
                md = f"# {title}\n\n```{ext}\n{text.strip()}\n```"
                plain = text.strip()
            words = word_tokens(plain)
            out = ExtractOutcome(
                url=url, final_url=raw_url, title=title, site_name="github.com",
                markdown=md, text=plain, excerpt=make_excerpt(plain),
                word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
                status_code=r.status_code, content_type=r.headers.get("Content-Type", "text/plain"),
                backend="direct_http", parser="github_raw",
            )
            out.quality = score_extraction_quality(out, min_words=5)
            return out
    return None


def _try_wikipedia_api(
    url: str, sess: requests.Session, timeout: float, relay: Optional[Tuple[str, str]], proxy: Optional[str]
) -> Optional[ExtractOutcome]:
    p = urllib.parse.urlparse(url)
    host = (p.netloc or "").lower()
    if not host.endswith(".wikipedia.org") or "/wiki/" not in p.path:
        return None
    slug = p.path.split("/wiki/", 1)[1]
    if not slug:
        return None
    api_url = f"https://{host}/api/rest_v1/page/html/{slug}"
    try:
        r = _http_get(
            api_url, sess, timeout=timeout, relay=relay, proxy=proxy,
            headers={"Api-User-Agent": "free-extract/1.1 (https://example.org; research)"},
        )
        if r.status_code == 200 and r.content:
            out = extract_from_html(_decode_response_text(r), url=url, final_url=url, status_code=200)
            if not out.title:
                out.title = urllib.parse.unquote(slug).replace("_", " ")
            out.backend = "direct_http"
            out.parser = f"wikipedia_rest+{out.parser}"
            return out
    except Exception:
        pass
    return None


# ---- Backend 1: `direct_http` (with Auto Load-More & SPA Expansion) -------

def backend_direct_http(
    url: str,
    sess: requests.Session,
    timeout: float = 15.0,
    relay: Optional[Tuple[str, str]] = None,
    proxy: Optional[str] = None,
    try_index: int = 0,
) -> ExtractOutcome:
    # 1. Domain-specific fast paths (YouTube, Reddit, GitHub)
    yt = _try_youtube_special(url, sess, timeout, relay, proxy)
    if yt is not None:
        return yt

    rd = _try_reddit_special(url, sess, timeout, relay, proxy)
    if rd is not None:
        return rd

    gh = _try_github_special(url, sess, timeout, relay, proxy)
    if gh is not None:
        return gh

    r = _http_get(url, sess, timeout=timeout, relay=relay, proxy=proxy)
    ctype = (r.headers.get("Content-Type") or "").lower()
    final_url = str(r.url or url)

    # 2. PDF handling
    if "application/pdf" in ctype or final_url.lower().endswith(".pdf") or r.content[:5] == b"%PDF-":
        out = extract_from_pdf_bytes(r.content, url=url, final_url=final_url, status_code=r.status_code)
        out.backend = "direct_http"
        return out

    # 3. JSON response handling
    if "application/json" in ctype or "application/ld+json" in ctype:
        try:
            obj = r.json()
            pretty = json.dumps(obj, ensure_ascii=False, indent=2)
        except Exception:
            pretty = _decode_response_text(r).strip()
        if not pretty:
            raise BackendDown("direct_http:empty-json")
        md = f"```json\n{pretty}\n```"
        words = word_tokens(pretty)
        return ExtractOutcome(
            url=url, final_url=final_url, title=urllib.parse.urlparse(final_url).path or "JSON Document",
            markdown=md, text=pretty, excerpt=make_excerpt(pretty),
            word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
            status_code=r.status_code, content_type=ctype,
            backend="direct_http", parser="json_raw", quality=0.85,
        )

    # 4. Plain text / Markdown response handling
    raw_html = _decode_response_text(r)
    if any(t in ctype for t in ("text/plain", "text/markdown", "text/csv")) and "<html" not in raw_html[:500].lower():
        txt = raw_html.strip()
        if not txt:
            raise BackendDown("direct_http:empty-text")
        md = clean_markdown(txt)
        plain = markdown_to_text(md)
        words = word_tokens(plain)
        out = ExtractOutcome(
            url=url, final_url=final_url,
            title=urllib.parse.urlparse(final_url).path.rsplit("/", 1)[-1] or final_url,
            markdown=md, text=plain, excerpt=make_excerpt(plain),
            word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
            status_code=r.status_code, content_type=ctype,
            backend="direct_http", parser="plain_text",
        )
        out.quality = score_extraction_quality(out, min_words=5)
        return out

    # 5. HTML extraction + Bot-wall check
    if not raw_html.strip():
        raise BackendDown("direct_http:empty-body")

    meta_preview = _extract_meta_tags(raw_html[:35000], final_url)
    walled, reason = looks_walled_html(r.status_code, raw_html, meta_preview.get("title", ""))
    if walled:
        wp = _try_wikipedia_api(url, sess, timeout, relay, proxy)
        if wp is not None:
            return wp
        raise BotWalled(f"direct_http:{reason}")

    out = extract_from_html(
        raw_html, url=url, final_url=final_url, status_code=r.status_code, content_type=ctype or "text/html"
    )
    out.backend = "direct_http"

    # 6. Auto-detect "Load more" buttons or client-side SPA shells!
    needs_load_more = has_load_more_pattern(raw_html)
    needs_spa = is_spa_js_shell(raw_html, out.word_count)
    if (needs_load_more or needs_spa) and _env_bool("EXTRACT_AUTO_EXPAND", True):
        try:
            expanded_html, clicks = render_and_expand_with_cdp(
                final_url, timeout=max(15.0, timeout), proxy=proxy
            )
            exp_out = extract_from_html(
                expanded_html, url=url, final_url=final_url, status_code=r.status_code, content_type="text/html"
            )
            if exp_out.word_count > out.word_count or (needs_spa and exp_out.word_count >= 15):
                exp_out.backend = "direct_http"
                tag = f"cdp_load_more({clicks})" if clicks > 0 else "cdp_spa"
                exp_out.parser = f"{tag}+{exp_out.parser}"
                return exp_out
        except Exception as e:
            logger.debug("auto CDP expand skipped/failed (%s)", e)
            if needs_spa and out.word_count < 25:
                # Force failover to Jina Reader / markdown_new which run cloud headless Chrome
                raise BackendDown("direct_http:spa-js-shell") from e

    if not (out.text or out.markdown).strip():
        raise BackendDown("direct_http:no-content-extracted")
    return out


# ---- Backend 2: `jina_reader` (https://r.jina.ai/<url>) -------------------

def backend_jina_reader(
    url: str,
    sess: requests.Session,
    timeout: float = 18.0,
    relay: Optional[Tuple[str, str]] = None,
    proxy: Optional[str] = None,
    try_index: int = 0,
) -> ExtractOutcome:
    reader_url = "https://r.jina.ai/" + url
    headers = {
        "Accept": "application/json",
        "X-Return-Format": "markdown",
    }
    api_key = os.getenv("JINA_API_KEY", "").strip()
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    r = _http_get(reader_url, sess, timeout=timeout, relay=relay, proxy=proxy, headers=headers)
    body = _decode_response_text(r).strip()
    if not body:
        raise BackendDown("jina_reader:empty")

    title = ""
    description = ""
    published_date = ""
    final_url = url
    md = ""

    try:
        j = r.json()
        if isinstance(j, dict):
            data = j.get("data") if isinstance(j.get("data"), dict) else j
            title = str(data.get("title") or "").strip()
            description = str(data.get("description") or "").strip()
            published_date = str(data.get("publishedTime") or "").strip()
            final_url = str(data.get("url") or url).strip()
            md = str(data.get("content") or data.get("text") or "").strip()
    except Exception:
        m_title = re.search(r"(?m)^Title:\s*(.+)$", body)
        if m_title:
            title = m_title.group(1).strip()
        m_src = re.search(r"(?m)^URL Source:\s*(.+)$", body)
        if m_src:
            final_url = m_src.group(1).strip()
        m_pub = re.search(r"(?m)^Published Time:\s*(.+)$", body)
        if m_pub:
            published_date = m_pub.group(1).strip()
        if "Markdown Content:" in body:
            md = body.split("Markdown Content:", 1)[1].strip()
        else:
            md = body

    if not md:
        raise BackendDown("jina_reader:no-content")

    walled, reason = looks_walled_html(200, md, title)
    if walled:
        raise BotWalled(f"jina_reader:target-walled:{reason}")

    md = clean_markdown(md)
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url,
        final_url=final_url,
        title=title[:300],
        published_date=published_date[:64],
        description=description[:600],
        markdown=md,
        text=txt,
        excerpt=make_excerpt(txt or description),
        word_count=len(words),
        reading_time_min=round(len(words) / 200.0, 2),
        status_code=r.status_code,
        content_type="text/markdown",
        backend="jina_reader",
        parser="jina_markdown",
    )
    out.quality = score_extraction_quality(out)
    return out


# ---- Backend 3: `markdown_new` (https://markdown.new/<url>) ---------------

def backend_markdown_new(
    url: str,
    sess: requests.Session,
    timeout: float = 16.0,
    relay: Optional[Tuple[str, str]] = None,
    proxy: Optional[str] = None,
    try_index: int = 0,
) -> ExtractOutcome:
    gw_url = "https://markdown.new/" + url
    r = _http_get(
        gw_url, sess, timeout=timeout, relay=relay, proxy=proxy,
        headers={"Accept": "text/markdown, text/plain;q=0.9, */*;q=0.8"},
    )
    body = _decode_response_text(r).strip()
    if not body or len(body) < 40:
        raise BackendDown("markdown_new:empty")
    if body.lstrip().startswith("<!DOCTYPE html") or "<html" in body[:400].lower():
        out = extract_from_html(body, url=url, final_url=url, status_code=r.status_code)
        out.backend = "markdown_new"
        return out

    title = ""
    m_h1 = re.search(r"(?m)^#\s+(.+)$", body)
    if m_h1:
        title = m_h1.group(1).strip()

    walled, reason = looks_walled_html(200, body, title)
    if walled:
        raise BotWalled(f"markdown_new:target-walled:{reason}")

    md = clean_markdown(body)
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url, final_url=url, title=title[:300],
        markdown=md, text=txt, excerpt=make_excerpt(txt),
        word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
        status_code=r.status_code, content_type="text/markdown",
        backend="markdown_new", parser="remote_markdown",
    )
    out.quality = score_extraction_quality(out)
    return out


# ---- Backend 4: `headless_dom` (Local Chrome/Edge CDP + Load More) --------

def backend_headless_dom(
    url: str,
    sess: requests.Session,
    timeout: float = 20.0,
    relay: Optional[Tuple[str, str]] = None,
    proxy: Optional[str] = None,
    try_index: int = 0,
) -> ExtractOutcome:
    raw_html, clicks = render_and_expand_with_cdp(url, timeout=timeout, proxy=proxy)
    walled, reason = looks_walled_html(200, raw_html)
    if walled:
        raise BotWalled(f"headless_dom:{reason}")
    out = extract_from_html(raw_html, url=url, final_url=url, status_code=200)
    out.backend = "headless_dom"
    tag = f"cdp_load_more({clicks})" if clicks > 0 else "cdp_dom"
    out.parser = f"{tag}+{out.parser}"
    return out


# ---- Backend 5: `wayback` (Internet Archive Snapshot Fallback) ------------

def backend_wayback(
    url: str,
    sess: requests.Session,
    timeout: float = 16.0,
    relay: Optional[Tuple[str, str]] = None,
    proxy: Optional[str] = None,
    try_index: int = 0,
) -> ExtractOutcome:
    avail_url = "https://archive.org/wayback/available?" + urllib.parse.urlencode({"url": url})
    snap_url = ""
    try:
        r = _http_get(avail_url, sess, timeout=min(8.0, timeout), relay=relay, proxy=proxy)
        data = r.json()
        closest = ((data.get("archived_snapshots") or {}).get("closest") or {})
        if closest.get("available") and closest.get("timestamp"):
            ts = closest["timestamp"]
            snap_url = f"https://web.archive.org/web/{ts}id_/{url}"
    except Exception:
        pass

    if not snap_url:
        cdx_url = (
            "https://web.archive.org/cdx/search/cdx?"
            + urllib.parse.urlencode({
                "url": url,
                "output": "json",
                "fl": "timestamp,statuscode",
                "filter": "statuscode:200",
                "limit": "-1",
            })
        )
        r_cdx = _http_get(cdx_url, sess, timeout=min(8.0, timeout), relay=relay, proxy=proxy)
        try:
            rows = r_cdx.json()
            if isinstance(rows, list) and len(rows) >= 2:
                ts = rows[-1][0]
                snap_url = f"https://web.archive.org/web/{ts}id_/{url}"
        except Exception:
            pass

    if not snap_url:
        raise BackendDown("wayback:no-snapshot")

    r_snap = _http_get(snap_url, sess, timeout=timeout, relay=relay, proxy=proxy)
    raw_html = _decode_response_text(r_snap)
    if not raw_html.strip():
        raise BackendDown("wayback:empty-snapshot")

    out = extract_from_html(
        raw_html, url=url, final_url=url, status_code=r_snap.status_code,
        content_type=r_snap.headers.get("Content-Type", "text/html"),
    )
    out.backend = "wayback"
    out.parser = f"wayback+{out.parser}"
    return out



# ---- Backend 5b: `google_cache` (Google Web Cache / AMP Cache Rescue) -----

def backend_google_cache(
    url: str,
    sess: requests.Session,
    timeout: float = 12.0,
    relay: Optional[Tuple[str, str]] = None,
    proxy: Optional[str] = None,
    try_index: int = 0,
) -> ExtractOutcome:
    """Fetch target page via Google Web Cache (`webcache.googleusercontent.com`)
    to bypass target site datacenter IP blocks."""
    cache_url = (
        "https://webcache.googleusercontent.com/search?q=cache:"
        + urllib.parse.quote(url, safe="")
        + "&hl=en&strip=0"
    )
    r = _http_get(
        cache_url,
        sess,
        timeout=timeout,
        relay=relay,
        proxy=proxy,
        headers={"Cookie": "CONSENT=YES+cb.20230531-04-p0.en+FX+908", "Referer": "https://www.google.com/"},
    )
    raw_html = _decode_response_text(r)
    if not raw_html.strip() or looks_walled_html(r.status_code, raw_html)[0]:
        raise BackendDown("google_cache:unavailable")
    out = extract_from_html(raw_html, url=url, final_url=url, status_code=r.status_code)
    if out.word_count < 20:
        raise BackendDown("google_cache:too-short")
    out.backend = "google_cache"
    out.parser = f"google_cache+{out.parser}"
    return out


# ---- Backend 6: `google_amp` ----------------------------------------------

def backend_google_amp(
    url: str,
    sess: requests.Session,
    timeout: float = 12.0,
    relay: Optional[Tuple[str, str]] = None,
    proxy: Optional[str] = None,
    try_index: int = 0,
) -> ExtractOutcome:
    p = urllib.parse.urlsplit(url)
    if not p.path or p.path == "/":
        # Root homepages rarely have /amp endpoints; skip fast
        raise BackendDown("google_amp:root-path-skipped")
    amp_candidates = []
    if not p.path.rstrip("/").endswith("/amp"):
        amp_candidates.append(
            urllib.parse.urlunsplit((p.scheme, p.netloc, p.path.rstrip("/") + "/amp", p.query, ""))
        )
    q_amp = (p.query + "&amp=1").lstrip("&") if "amp=" not in p.query else p.query
    amp_candidates.append(urllib.parse.urlunsplit((p.scheme, p.netloc, p.path, q_amp, "")))

    mobile_headers = {
        "User-Agent": (
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
        ),
        "Referer": "https://www.google.com/",
    }

    last_err: Optional[Exception] = None
    for cand_url in amp_candidates:
        try:
            r = _http_get(cand_url, sess, timeout=timeout, relay=relay, proxy=proxy, headers=mobile_headers)
            raw_html = _decode_response_text(r)
            walled, _ = looks_walled_html(r.status_code, raw_html)
            if walled:
                continue
            out = extract_from_html(raw_html, url=url, final_url=str(r.url or cand_url), status_code=r.status_code)
            if out.word_count >= 30:
                out.backend = "google_amp"
                return out
        except Exception as e:
            last_err = e

    raise BackendDown(f"google_amp:{last_err or 'no-amp-variant'}")


# ---- Backend 7: `urltomarkdown` -------------------------------------------

def backend_urltomarkdown(
    url: str,
    sess: requests.Session,
    timeout: float = 15.0,
    relay: Optional[Tuple[str, str]] = None,
    proxy: Optional[str] = None,
    try_index: int = 0,
) -> ExtractOutcome:
    gw = "https://urltomarkdown.herokuapp.com/?" + urllib.parse.urlencode(
        {"url": url, "title": "true", "links": "true"}
    )
    r = _http_get(gw, sess, timeout=timeout, relay=relay, proxy=proxy)
    body = _decode_response_text(r).strip()
    if not body or len(body) < 40:
        raise BackendDown("urltomarkdown:empty")
    title = htmllib.unescape(r.headers.get("X-Title") or "").strip()
    if not title:
        m_h1 = re.search(r"(?m)^#\s+(.+)$", body)
        if m_h1:
            title = m_h1.group(1).strip()

    walled, reason = looks_walled_html(200, body, title)
    if walled:
        raise BotWalled(f"urltomarkdown:{reason}")

    md = clean_markdown(body)
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url, final_url=url, title=title[:300],
        markdown=md, text=txt, excerpt=make_excerpt(txt),
        word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
        status_code=r.status_code, content_type="text/markdown",
        backend="urltomarkdown", parser="remote_markdown",
    )
    out.quality = score_extraction_quality(out)
    return out


# ---- Optional Keyed API Backends (`KEY_BACKENDS`) -------------------------

def backend_firecrawl(
    url: str, sess: requests.Session, timeout: float = 25.0,
    relay: Optional[Tuple[str, str]] = None, proxy: Optional[str] = None, try_index: int = 0,
) -> ExtractOutcome:
    key = os.getenv("FIRECRAWL_API_KEY", "").strip()
    if not key:
        raise BackendDown("firecrawl:no-key")
    r = requests.post(
        "https://api.firecrawl.dev/v1/scrape",
        timeout=timeout,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json={"url": url, "formats": ["markdown"]},
    )
    if r.status_code in (401, 402, 403, 429):
        raise BotWalled(f"firecrawl:http:{r.status_code}")
    r.raise_for_status()
    data = (r.json().get("data") or {})
    md = clean_markdown(str(data.get("markdown") or data.get("content") or ""))
    meta = data.get("metadata") or {}
    if not md:
        raise BackendDown("firecrawl:empty")
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url,
        final_url=str(meta.get("sourceURL") or url),
        title=str(meta.get("title") or "")[:300],
        description=str(meta.get("description") or "")[:600],
        language=str(meta.get("language") or ""),
        markdown=md,
        text=txt,
        excerpt=make_excerpt(txt),
        word_count=len(words),
        reading_time_min=round(len(words) / 200.0, 2),
        status_code=int(meta.get("statusCode") or 200),
        backend="firecrawl",
        parser="firecrawl_api",
    )
    out.quality = score_extraction_quality(out)
    return out


def backend_tavily_extract(
    url: str, sess: requests.Session, timeout: float = 25.0,
    relay: Optional[Tuple[str, str]] = None, proxy: Optional[str] = None, try_index: int = 0,
) -> ExtractOutcome:
    key = os.getenv("TAVILY_API_KEY", "").strip()
    if not key:
        raise BackendDown("tavily_extract:no-key")
    r = requests.post(
        "https://api.tavily.com/extract",
        timeout=timeout,
        headers={"Content-Type": "application/json"},
        json={"api_key": key, "urls": [url]},
    )
    if r.status_code in (401, 402, 403, 429):
        raise BotWalled(f"tavily_extract:http:{r.status_code}")
    r.raise_for_status()
    results = r.json().get("results") or []
    if not results:
        raise BackendDown("tavily_extract:empty")
    row = results[0]
    raw = str(row.get("raw_content") or row.get("content") or "").strip()
    if not raw:
        raise BackendDown("tavily_extract:no-content")
    md = clean_markdown(raw)
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url, final_url=str(row.get("url") or url),
        title=str(row.get("title") or "")[:300],
        markdown=md, text=txt, excerpt=make_excerpt(txt),
        word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
        status_code=200, backend="tavily_extract", parser="tavily_api",
    )
    out.quality = score_extraction_quality(out)
    return out


def backend_exa_contents(
    url: str, sess: requests.Session, timeout: float = 25.0,
    relay: Optional[Tuple[str, str]] = None, proxy: Optional[str] = None, try_index: int = 0,
) -> ExtractOutcome:
    key = os.getenv("EXA_API_KEY", "").strip()
    if not key:
        raise BackendDown("exa_contents:no-key")
    r = requests.post(
        "https://api.exa.ai/contents",
        timeout=timeout,
        headers={"x-api-key": key, "Content-Type": "application/json"},
        json={"ids": [url], "text": True},
    )
    if r.status_code in (401, 402, 403, 429):
        raise BotWalled(f"exa_contents:http:{r.status_code}")
    r.raise_for_status()
    results = r.json().get("results") or []
    if not results:
        raise BackendDown("exa_contents:empty")
    row = results[0]
    txt_raw = str(row.get("text") or "").strip()
    if not txt_raw:
        raise BackendDown("exa_contents:no-text")
    title = str(row.get("title") or "")[:300]
    md = clean_markdown(f"# {title}\n\n{txt_raw}" if title else txt_raw)
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url, final_url=str(row.get("url") or url),
        title=title, author=str(row.get("author") or ""),
        published_date=str(row.get("publishedDate") or ""),
        markdown=md, text=txt, excerpt=make_excerpt(txt),
        word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
        status_code=200, backend="exa_contents", parser="exa_api",
    )
    out.quality = score_extraction_quality(out)
    return out


def backend_diffbot(
    url: str, sess: requests.Session, timeout: float = 25.0,
    relay: Optional[Tuple[str, str]] = None, proxy: Optional[str] = None, try_index: int = 0,
) -> ExtractOutcome:
    key = os.getenv("DIFFBOT_API_KEY", "").strip()
    if not key:
        raise BackendDown("diffbot:no-key")
    r = requests.get(
        "https://api.diffbot.com/v3/article",
        timeout=timeout,
        params={"token": key, "url": url},
    )
    if r.status_code in (401, 402, 403, 429):
        raise BotWalled(f"diffbot:http:{r.status_code}")
    r.raise_for_status()
    objs = r.json().get("objects") or []
    if not objs:
        raise BackendDown("diffbot:empty")
    obj = objs[0]
    title = str(obj.get("title") or "")[:300]
    txt = str(obj.get("text") or "").strip()
    if not txt:
        raise BackendDown("diffbot:no-text")
    md = clean_markdown(f"# {title}\n\n{txt}" if title else txt)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url, final_url=str(obj.get("pageUrl") or url),
        title=title, author=str(obj.get("author") or ""),
        published_date=str(obj.get("date") or ""),
        site_name=str(obj.get("siteName") or ""),
        markdown=md, text=txt, excerpt=make_excerpt(txt),
        word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
        status_code=200, backend="diffbot", parser="diffbot_api",
    )
    out.quality = score_extraction_quality(out)
    return out


def backend_scrapingbee(
    url: str, sess: requests.Session, timeout: float = 30.0,
    relay: Optional[Tuple[str, str]] = None, proxy: Optional[str] = None, try_index: int = 0,
) -> ExtractOutcome:
    key = os.getenv("SCRAPINGBEE_API_KEY", "").strip()
    if not key:
        raise BackendDown("scrapingbee:no-key")
    r = requests.get(
        "https://app.scrapingbee.com/api/v1/",
        timeout=timeout,
        params={"api_key": key, "url": url, "render_js": "false"},
    )
    if r.status_code in (401, 402, 403, 429):
        raise BotWalled(f"scrapingbee:http:{r.status_code}")
    r.raise_for_status()
    out = extract_from_html(_decode_response_text(r), url=url, final_url=url, status_code=r.status_code)
    out.backend = "scrapingbee"
    return out


def backend_zenrows(
    url: str, sess: requests.Session, timeout: float = 30.0,
    relay: Optional[Tuple[str, str]] = None, proxy: Optional[str] = None, try_index: int = 0,
) -> ExtractOutcome:
    key = os.getenv("ZENROWS_API_KEY", "").strip()
    if not key:
        raise BackendDown("zenrows:no-key")
    r = requests.get(
        "https://api.zenrows.com/v1/",
        timeout=timeout,
        params={"apikey": key, "url": url},
    )
    if r.status_code in (401, 402, 403, 429):
        raise BotWalled(f"zenrows:http:{r.status_code}")
    r.raise_for_status()
    out = extract_from_html(_decode_response_text(r), url=url, final_url=url, status_code=r.status_code)
    out.backend = "zenrows"
    return out


def backend_spider(
    url: str, sess: requests.Session, timeout: float = 30.0,
    relay: Optional[Tuple[str, str]] = None, proxy: Optional[str] = None, try_index: int = 0,
) -> ExtractOutcome:
    key = os.getenv("SPIDER_API_KEY", "").strip()
    if not key:
        raise BackendDown("spider:no-key")
    r = requests.post(
        "https://api.spider.cloud/scrape",
        timeout=timeout,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json={"url": url, "return_format": "markdown"},
    )
    if r.status_code in (401, 402, 403, 429):
        raise BotWalled(f"spider:http:{r.status_code}")
    r.raise_for_status()
    rows = r.json()
    row = rows[0] if isinstance(rows, list) and rows else (rows if isinstance(rows, dict) else {})
    md = clean_markdown(str(row.get("content") or ""))
    if not md:
        raise BackendDown("spider:empty")
    txt = markdown_to_text(md)
    words = word_tokens(txt)
    out = ExtractOutcome(
        url=url, final_url=str(row.get("url") or url),
        markdown=md, text=txt, excerpt=make_excerpt(txt),
        word_count=len(words), reading_time_min=round(len(words) / 200.0, 2),
        status_code=int(row.get("status") or 200),
        backend="spider", parser="spider_api",
    )
    out.quality = score_extraction_quality(out)
    return out


# ---------------------------------------------------------------------------
# Backend Registry
# ---------------------------------------------------------------------------

BUILTIN_BACKENDS: List[Tuple[str, Callable, float, bool, bool]] = [
    ("direct_http", backend_direct_http, 4.0, True, True),
    ("headless_dom", backend_headless_dom, 1.5, True, False),
    ("jina_reader", backend_jina_reader, 1.5, True, False),
    ("markdown_new", backend_markdown_new, 1.5, True, False),
    ("wayback", backend_wayback, 1.5, True, True),
    ("google_cache", backend_google_cache, 1.5, True, True),
    ("google_amp", backend_google_amp, 2.0, True, True),
    ("urltomarkdown", backend_urltomarkdown, 1.0, True, False),
]

KEY_BACKENDS: Dict[str, Callable] = {
    "firecrawl": backend_firecrawl,
    "tavily_extract": backend_tavily_extract,
    "exa_contents": backend_exa_contents,
    "diffbot": backend_diffbot,
    "scrapingbee": backend_scrapingbee,
    "zenrows": backend_zenrows,
    "spider": backend_spider,
}

DEFAULT_PRIORITY = (
    "direct_http,jina_reader,markdown_new,wayback,google_cache,headless_dom,google_amp,urltomarkdown,"
    "firecrawl,tavily_extract,exa_contents,diffbot,scrapingbee,zenrows,spider"
)

EGRESS_ORDER = ("direct", "proxy", "relay")


def build_backend_table() -> Dict[str, Tuple[Callable, float, bool, bool]]:
    tbl: Dict[str, Tuple[Callable, float, bool, bool]] = {}
    for name, fn, rate, px, rl in BUILTIN_BACKENDS:
        tbl[name] = (fn, rate, px, rl)
    for name, fn in KEY_BACKENDS.items():
        tbl.setdefault(name, (fn, 1.5, False, False))
    return tbl


# ---------------------------------------------------------------------------
# The Router: `FreeExtract`
# ---------------------------------------------------------------------------

class FreeExtract:
    """Unmetered website extraction router: many backends x many egress IPs x
    local multi-parser cascade + CDP Load-More/SPA expander x SQLite cache."""

    def __init__(
        self,
        priority: Optional[Sequence[str]] = None,
        egress: Optional[Sequence[str]] = None,
        use_proxy: Optional[bool] = None,
        use_relay: Optional[bool] = None,
        cache: Optional[ResultCache] = None,
        proxies: Optional[ProxyPool] = None,
        timeout: Optional[float] = None,
        use_cache: Optional[bool] = None,
        min_quality: Optional[float] = None,
        min_relevance: Optional[float] = None,
        allow_low_quality: Optional[bool] = None,
        per_domain_delay: Optional[float] = None,
        race: Optional[bool] = None,
        race_width: Optional[int] = None,
        verbose: bool = False,
    ):
        self.table = build_backend_table()
        prio = priority if priority is not None else _env_list(
            "EXTRACT_BACKENDS", [p.strip() for p in DEFAULT_PRIORITY.split(",")]
        )
        self.priority: List[str] = []
        for name in prio:
            if name == "*":
                self.priority.extend(sorted(self.table))
            elif name in self.table:
                self.priority.append(name)
        if not self.priority:
            self.priority = ["direct_http", "headless_dom", "jina_reader", "wayback"]

        default_egress = (
            list(EGRESS_ORDER) if _env_bool("EXTRACT_USE_RELAY", False) else ["direct", "proxy"]
        )
        order = egress if egress is not None else _env_list("EXTRACT_EGRESS", default_egress)
        self.egress_order = [e for e in order if e in EGRESS_ORDER] or ["direct"]
        if use_proxy is False:
            self.egress_order = [e for e in self.egress_order if e != "proxy"] or ["direct"]
        if use_relay is False:
            self.egress_order = [e for e in self.egress_order if e != "relay"] or ["direct"]
        if use_proxy is True and "proxy" not in self.egress_order:
            self.egress_order.append("proxy")

        self.use_proxy = "proxy" in self.egress_order
        self.use_relay = "relay" in self.egress_order
        self.cache = cache if cache is not None else ResultCache()
        self.proxies = proxies if proxies is not None else ProxyPool()
        self.timeout = timeout or _env_float("EXTRACT_TIMEOUT", 15.0)
        self.proxy_timeout = _env_float("EXTRACT_PROXY_TIMEOUT", 8.0)
        self.relay_timeout = _env_float("EXTRACT_RELAY_TIMEOUT", 18.0)
        self.proxy_retries = max(0, _env_int("EXTRACT_PROXY_RETRIES", 2))
        self.relay_retries = max(0, _env_int("EXTRACT_RELAY_RETRIES", 1))

        self.min_quality = min(1.0, max(0.0, (
            _env_float("EXTRACT_MIN_QUALITY", 0.30) if min_quality is None else float(min_quality)
        )))
        self.min_relevance = min(1.0, max(0.0, (
            _env_float("EXTRACT_MIN_RELEVANCE", 0.20) if min_relevance is None else float(min_relevance)
        )))
        self.use_cache_default = self.cache.enabled if use_cache is None else bool(use_cache)
        self.allow_low_quality = (
            _env_bool("EXTRACT_ALLOW_LOW_QUALITY", False)
            if allow_low_quality is None
            else bool(allow_low_quality)
        )
        self.domain_limiter = DomainLimiter(
            _env_float("EXTRACT_DOMAIN_DELAY", 0.20) if per_domain_delay is None else float(per_domain_delay)
        )
        self.race = _env_bool("EXTRACT_RACE", True) if race is None else bool(race)
        self.race_width = max(2, _env_int("EXTRACT_RACE_WIDTH", 3) if race_width is None else int(race_width))
        self.verbose = verbose

        self._hlock = threading.Lock()
        self._health: Dict[str, BackendHealth] = {}
        rate_scale = _env_float("EXTRACT_RATE_SCALE", 1.0)
        for name, (_fn, rate, _px, _rl) in self.table.items():
            scaled = rate * rate_scale
            self._health[name] = BackendHealth(
                name=name,
                rate=scaled,
                base_rate=scaled,
                rate_min=max(0.02, 0.05 * rate_scale),
                rate_max=max(8.0, scaled * 5),
            )
        self._relay_idx = 0
        self._rl_lock = threading.Lock()
        self.counters: Dict[str, int] = defaultdict(int)
        self._started = time.time()
        self._proxy_ready = False

    def health(self, name: str) -> BackendHealth:
        with self._hlock:
            h = self._health.get(name)
            if h is None:
                h = BackendHealth(name=name, rate=self.table.get(name, (None, 1.0, False, False))[1])
                self._health[name] = h
            return h

    def _next_relay(self) -> Optional[Tuple[str, str]]:
        relays = list(DEFAULT_RELAYS)
        if not relays:
            return None
        with self._rl_lock:
            r = relays[self._relay_idx % len(relays)]
            self._relay_idx += 1
        return r

    def _ensure_proxies(self) -> bool:
        if not self.use_proxy:
            return False
        floor = max(2, _env_int("PROXY_REBUILD_BELOW", 3))
        if self._proxy_ready:
            alive = self.proxies.alive_count()
            if alive >= floor:
                return True
            if alive > 0 and self.proxies.stats().get("builds", 0) >= self.proxies.max_builds:
                return True
            rebuilt = self.proxies.build(force=True)
            return rebuilt or alive > 0
        self._proxy_ready = self.proxies.ensure()
        return self._proxy_ready

    def _attempt(
        self,
        backend: str,
        url: str,
        egress: str,
        try_index: int = 0,
    ) -> ExtractOutcome:
        fn, _rate, supports_px, supports_rl = self.table[backend]
        if backend in KEY_ENVS and not os.getenv(KEY_ENVS[backend], "").strip():
            raise BackendDown(f"{backend}:no-key")

        proxy = None
        relay = None
        if egress == "proxy":
            if not supports_px:
                raise BackendDown("backend does not support proxies")
            if not self._ensure_proxies():
                raise BackendDown("no proxy pool available")
            proxy = self.proxies.next()
            if not proxy:
                raise BackendDown("proxy pool exhausted")
        elif egress == "relay":
            if not supports_rl:
                raise BackendDown("backend does not support relays")
            relay = self._next_relay()

        h = self.health(backend)
        slept = h.acquire()
        if backend == "direct_http":
            slept += self.domain_limiter.wait(url)
        self.counters["throttle_sleep_ms"] += int(slept * 1000)

        tmo = (
            self.proxy_timeout if egress == "proxy"
            else self.relay_timeout if egress == "relay"
            else self.timeout
        )
        sess = _mk_session(proxy=proxy, try_index=try_index)
        t0 = time.time()
        try:
            outcome = fn(
                url, sess, timeout=tmo, relay=relay, proxy=proxy, try_index=try_index
            )
        except (BotWalled, BackendDown, EgressRetry):
            if proxy:
                self.proxies.mark_dead(proxy)
            raise
        except Exception as e:
            if proxy:
                self.proxies.mark_dead(proxy)
            raise BackendDown(f"{type(e).__name__}:{str(e)[:120]}") from e
        finally:
            sess.close()

        ms = (time.time() - t0) * 1000.0
        outcome.backend = backend
        outcome.egress = egress
        outcome.proxy = proxy or (relay[0] if relay else "")
        if proxy:
            if outcome.text or outcome.markdown:
                self.proxies.mark_ok(proxy)
            else:
                self.proxies.mark_dead(proxy)
        h.note_ok(len(outcome.text or outcome.markdown), ms)
        return outcome

    @staticmethod
    def _from_cached_dict(d: Dict[str, Any]) -> ExtractOutcome:
        links = [
            ExtractedLink(text=str(x.get("text") or ""), url=str(x.get("url") or ""))
            for x in (d.get("links") or []) if isinstance(x, dict)
        ]
        images = [
            ExtractedImage(alt=str(x.get("alt") or ""), url=str(x.get("url") or ""))
            for x in (d.get("images") or []) if isinstance(x, dict)
        ]
        return ExtractOutcome(
            url=str(d.get("url") or ""),
            final_url=str(d.get("final_url") or ""),
            title=str(d.get("title") or ""),
            author=str(d.get("author") or ""),
            published_date=str(d.get("published_date") or ""),
            site_name=str(d.get("site_name") or ""),
            description=str(d.get("description") or ""),
            language=str(d.get("language") or ""),
            markdown=str(d.get("markdown") or ""),
            text=str(d.get("text") or ""),
            excerpt=str(d.get("excerpt") or ""),
            word_count=int(d.get("word_count") or 0),
            reading_time_min=float(d.get("reading_time_min") or 0.0),
            links=links,
            images=images,
            structured_data=list(d.get("structured_data") or []),
            status_code=int(d.get("status_code") or 200),
            content_type=str(d.get("content_type") or ""),
            backend=str(d.get("backend") or "cache"),
            parser=str(d.get("parser") or "cache"),
            egress="cache",
            from_cache=True,
            quality=float(d.get("quality") or 1.0),
            relevance=float(d.get("relevance") or 1.0),
        )

    def _race_backends(
        self,
        backends: List[str],
        url: str,
        egress: str,
        query: str,
        min_q: float,
        min_rel: float,
    ) -> Tuple[Optional[ExtractOutcome], Optional[ExtractOutcome], List[str], int]:
        """Fire `backends` concurrently on `egress` and return the first outcome
        that passes both `min_q` and `min_rel`."""
        errors: List[str] = []
        fallback: Optional[ExtractOutcome] = None
        attempts = len(backends)
        self.counters["attempts"] += attempts

        ex = ThreadPoolExecutor(max_workers=len(backends))
        try:
            fut_map = {
                ex.submit(self._attempt, be, url, egress, 0): be
                for be in backends
            }
            pending = set(fut_map.keys())
            while pending:
                done, pending = wait(pending, return_when=FIRST_COMPLETED)
                for fut in done:
                    be = fut_map[fut]
                    h = self.health(be)
                    try:
                        cand = fut.result()
                    except EgressRetry as e:
                        self.counters["egress_retries"] += 1
                        errors.append(f"{be}/{egress} egress retry: {e}")
                        continue
                    except BotWalled as e:
                        h.trip(str(e), wall=True)
                        self.counters["walls"] += 1
                        errors.append(f"{be}/{egress} walled: {e}")
                        continue
                    except Exception as e:
                        h.trip(str(e), wall=False)
                        self.counters["backend_errors"] += 1
                        errors.append(f"{be}/{egress} down: {e}")
                        continue

                    cand.relevance = compute_relevance(query, cand)
                    self.counters["backend_ok"] += 1
                    self.counters[f"ok:{be}"] += 1
                    self.counters[f"ok_egress:{egress}"] += 1
                    if cand.quality < min_q or (query and cand.relevance < min_rel):
                        self.counters["low_quality"] += 1
                        errors.append(f"{be}/{egress} low quality ({cand.quality:.2f} < {min_q:.2f})")
                        if fallback is None or cand.quality > fallback.quality:
                            fallback = cand
                        continue
                    return cand, fallback, errors, attempts
        finally:
            ex.shutdown(wait=False, cancel_futures=True)

        return None, fallback, errors, attempts

    def extract(
        self,
        url: str,
        backend: Optional[str] = None,
        egress: Optional[str] = None,
        query: Optional[str] = None,
        use_cache: Optional[bool] = None,
        allow_low_quality: Optional[bool] = None,
        min_quality: Optional[float] = None,
        min_relevance: Optional[float] = None,
        max_attempts: Optional[int] = None,
    ) -> ExtractOutcome:
        """Fast-first extraction router: tries all healthy backends on `direct`
        egress first (so dead/walled hosts fail over to Jina/Wayback/CDP in ~1-3s
        instead of blocking on a proxy pool build), and escalates to `proxy`/`relay`
        only if every direct backend fails."""
        t_start = time.time()
        norm_url = normalize_url(url)
        use_cache = self.use_cache_default if use_cache is None else bool(use_cache)
        max_attempts = max_attempts or _env_int("EXTRACT_MAX_ATTEMPTS", 10)
        allow_lq = self.allow_low_quality if allow_low_quality is None else bool(allow_low_quality)
        min_q = self.min_quality if min_quality is None else min(1.0, max(0.0, float(min_quality)))
        min_rel = self.min_relevance if min_relevance is None else min(1.0, max(0.0, float(min_relevance)))

        out = ExtractOutcome(url=norm_url or url)
        if not norm_url:
            out.deferred = True
            out.errors.append("empty or invalid URL")
            return out

        cache_key = ""
        if use_cache:
            cache_key = self.cache.key(norm_url, backend or "auto")
            cached = self.cache.get(cache_key)
            if cached:
                self.counters["cache_hits"] += 1
                restored = self._from_cached_dict(cached)
                restored.elapsed_ms = int((time.time() - t_start) * 1000)
                return restored
            self.counters["cache_misses"] += 1

        backends = [backend] if backend else list(self.priority)
        egresses = [egress] if egress else list(self.egress_order)

        fallback: Optional[ExtractOutcome] = None
        attempts = 0
        errors: List[str] = []

        # Fast-Path Parallel Hedged Racing on 'direct' egress for Cloud Datacenter speed!
        # Races direct_http + jina_reader + markdown_new concurrently so if the datacenter IP
        # is blocked by Cloudflare, r.jina.ai or markdown.new returns in <1.2s without waiting!
        if self.race and not backend and "direct" in egresses:
            race_cands = [
                b for b in backends
                if b in self.table
                and b != "headless_dom"
                and (b not in KEY_ENVS or os.getenv(KEY_ENVS[b], "").strip())
                and self.health(b).ready()
            ][: self.race_width]
            if len(race_cands) >= 2:
                winner, fb_race, errs_race, att_race = self._race_backends(
                    race_cands, norm_url, "direct", query or "", min_q, min_rel
                )
                attempts += att_race
                errors.extend(errs_race)
                if fb_race is not None and (fallback is None or fb_race.quality > fallback.quality):
                    fallback = fb_race
                if winner is not None:
                    winner.attempts = attempts
                    winner.errors = errors
                    winner.elapsed_ms = int((time.time() - t_start) * 1000)
                    self.counters["urls_ok"] += 1
                    if cache_key:
                        self.cache.put(cache_key, winner)
                    return winner
                backends = [b for b in backends if b not in race_cands] + race_cands

        # OUTER LOOP = egress tier ('direct' first across all backends!), INNER LOOP = backend
        for eg in egresses:
            if attempts >= max_attempts:
                break
            for be in backends:
                if attempts >= max_attempts:
                    break
                if be not in self.table:
                    continue
                if be in KEY_ENVS and not os.getenv(KEY_ENVS[be], "").strip():
                    continue
                _fn, _rate, supports_px, supports_rl = self.table[be]
                if eg == "proxy" and not supports_px:
                    continue
                if eg == "relay" and not supports_rl:
                    continue

                h = self.health(be)
                if not h.ready():
                    errors.append(f"{be}:cooldown({int(h.cooldown_until - time.time())}s)")
                    continue

                retries = (
                    self.proxy_retries if eg == "proxy"
                    else self.relay_retries if eg == "relay"
                    else 0
                )
                for attempt_i in range(retries + 1):
                    if attempts >= max_attempts:
                        break
                    attempts += 1
                    self.counters["attempts"] += 1
                    try:
                        cand = self._attempt(be, norm_url, eg, try_index=attempt_i)
                    except EgressRetry as e:
                        self.counters["egress_retries"] += 1
                        errors.append(f"{be}/{eg} egress retry: {e}")
                        continue
                    except BotWalled as e:
                        h.trip(str(e), wall=True)
                        self.counters["walls"] += 1
                        errors.append(f"{be}/{eg} walled: {e}")
                        break
                    except BackendDown as e:
                        h.trip(str(e), wall=False)
                        self.counters["backend_errors"] += 1
                        errors.append(f"{be}/{eg} down: {e}")
                        break
                    except Exception as e:
                        h.trip(f"{type(e).__name__}:{e}")
                        self.counters["unexpected"] += 1
                        errors.append(f"{be}/{eg} error: {type(e).__name__}: {e}")
                        break

                    cand.relevance = compute_relevance(query or "", cand)
                    self.counters["backend_ok"] += 1
                    self.counters[f"ok:{be}"] += 1
                    self.counters[f"ok_egress:{eg}"] += 1

                    if cand.quality < min_q or (query and cand.relevance < min_rel):
                        self.counters["low_quality"] += 1
                        reason = (
                            f"quality {cand.quality:.2f} < {min_q:.2f}"
                            if cand.quality < min_q
                            else f"relevance {cand.relevance:.2f} < {min_rel:.2f}"
                        )
                        errors.append(f"{be}/{eg} rejected ({reason}) - trying next")
                        if fallback is None or cand.quality > fallback.quality:
                            fallback = cand
                        break

                    cand.attempts = attempts
                    cand.errors = errors
                    cand.elapsed_ms = int((time.time() - t_start) * 1000)
                    self.counters["urls_ok"] += 1
                    if cache_key:
                        self.cache.put(cache_key, cand)
                    return cand

        if fallback is not None and allow_lq:
            fallback.low_quality = True
            fallback.attempts = attempts
            fallback.errors = errors
            fallback.elapsed_ms = int((time.time() - t_start) * 1000)
            self.counters["low_quality_used"] += 1
            return fallback

        if fallback is not None:
            self.counters["low_quality_discarded"] += 1
            errors.append(
                f"best candidate had quality {fallback.quality:.2f} (< {min_q:.2f}) "
                f"and EXTRACT_ALLOW_LOW_QUALITY is off - deferred"
            )

        out.deferred = True
        out.attempts = attempts
        out.errors = errors
        out.elapsed_ms = int((time.time() - t_start) * 1000)
        self.counters["urls_deferred"] += 1
        return out

    # -- Batch & Retry ---------------------------------------------------
    def extract_many(
        self,
        urls: Sequence[str],
        workers: Optional[int] = None,
        query: Optional[str] = None,
        use_cache: Optional[bool] = None,
        allow_low_quality: Optional[bool] = None,
        min_quality: Optional[float] = None,
        progress: bool = True,
    ) -> List[ExtractOutcome]:
        clean_urls = [u.strip() for u in urls if u and u.strip()]
        if not clean_urls:
            return []
        workers = max(1, min(int(workers or _env_int("EXTRACT_WORKERS", 6)), len(clean_urls)))
        results: List[Optional[ExtractOutcome]] = [None] * len(clean_urls)
        done = 0
        lock = threading.Lock()
        t0 = time.time()

        def _one(i_u: Tuple[int, str]) -> Tuple[int, ExtractOutcome]:
            i, u = i_u
            try:
                return i, self.extract(
                    u,
                    query=query,
                    use_cache=use_cache,
                    allow_low_quality=allow_low_quality,
                    min_quality=min_quality,
                )
            except Exception as e:
                return i, ExtractOutcome(
                    url=u, deferred=True, errors=[f"fatal:{type(e).__name__}:{e}"]
                )

        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_one, (i, u)) for i, u in enumerate(clean_urls)]
            for fut in as_completed(futs):
                i, o = fut.result()
                results[i] = o
                with lock:
                    done += 1
                    if progress and (done % 10 == 0 or done == len(clean_urls)):
                        el = time.time() - t0
                        logger.info(
                            "batch %d/%d  %.1fs  ok=%d deferred=%d",
                            done, len(clean_urls), el,
                            sum(1 for r in results if r and not r.deferred),
                            sum(1 for r in results if r and r.deferred),
                        )
        return [r for r in results if r is not None]

    def extract_many_with_retry(
        self,
        urls: Sequence[str],
        rounds: Optional[int] = None,
        cooldown: Optional[float] = None,
        **kw,
    ) -> List[ExtractOutcome]:
        rounds = max(1, int(rounds or _env_int("EXTRACT_RETRY_ROUNDS", 3)))
        cooldown = cooldown if cooldown is not None else _env_float("EXTRACT_RETRY_COOLDOWN", 15.0)
        outs: Dict[str, ExtractOutcome] = {}
        pending = [u.strip() for u in urls if u and u.strip()]
        for rnd in range(1, rounds + 1):
            if not pending:
                break
            got = self.extract_many(pending, **kw)
            still: List[str] = []
            for o in got:
                if o.deferred:
                    still.append(o.url)
                else:
                    outs[o.url] = o
            logger.info(
                "retry round %d/%d: %d extracted, %d still deferred",
                rnd, rounds, len(got) - len(still), len(still),
            )
            pending = still
            if pending and rnd < rounds:
                self.reset_cooldowns(partial=True)
                time.sleep(cooldown)
        for u in pending:
            outs[u] = ExtractOutcome(url=u, deferred=True, errors=[f"deferred after {rounds} round(s)"])
        order = {normalize_url(u): i for i, u in enumerate(urls) if u and u.strip()}
        return sorted(outs.values(), key=lambda o: order.get(normalize_url(o.url), 10**6))

    def reset_cooldowns(self, partial: bool = False) -> None:
        with self._hlock:
            for h in self._health.values():
                if partial:
                    left = h.cooldown_until - time.time()
                    if left <= _env_float("EXTRACT_RETRY_MAX_COOLDOWN", 120.0):
                        h.cooldown_until = 0.0
                        h.consecutive_fail = 0
                        h.strikes = max(0, h.strikes - 1)
                else:
                    h.cooldown_until = 0.0
                    h.consecutive_fail = 0
                    h.strikes = 0

    def stats(self) -> Dict[str, Any]:
        with self._hlock:
            hs = {
                n: {
                    "ok": h.ok,
                    "fail": h.fail,
                    "walls": h.walls,
                    "chars_extracted": h.chars_extracted,
                    "strikes": h.strikes,
                    "cooldown_s": max(0, int(h.cooldown_until - time.time())),
                    "rate_qps": round(h.rate, 3),
                    "avg_ms": int(h.total_ms / h.ok) if h.ok else 0,
                    "last_error": h.last_error,
                }
                for n, h in self._health.items() if (h.ok or h.fail)
            }
        st = dict(self.counters)
        st.update({
            "uptime_s": int(time.time() - self._started),
            "cache_hits": self.cache.hits,
            "cache_misses": self.cache.misses,
            "cache_rows": self.cache.size(),
            "proxies": self.proxies.stats(),
            "backends": hs,
            "parsers_available": {
                "bs4": HAVE_BS4,
                "lxml": HAVE_LXML,
                "html2text": HAVE_HTML2TEXT,
                "trafilatura": HAVE_TRAFILATURA,
                "readability": HAVE_READABILITY,
                "pypdf": HAVE_PYPDF,
                "pdfplumber": HAVE_PDFPLUMBER,
                "pypdfium2": HAVE_PDFIUM,
                "browser_cdp": _find_chromium_binary() or False,
            },
            "egress_order": self.egress_order,
            "priority": self.priority[:12],
            "key_backends": sorted(k for k, v in KEY_ENVS.items() if os.getenv(v, "").strip()),
        })
        return st

    def selftest(
        self,
        url: str = "https://example.com",
        test_proxy: bool = True,
    ) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        have_px = self._ensure_proxies() if test_proxy else False
        norm = normalize_url(url)
        for be in self.priority:
            if be not in self.table:
                continue
            _fn, _rate, supports_px, supports_rl = self.table[be]
            if be in KEY_ENVS and not os.getenv(KEY_ENVS[be], "").strip():
                rows.append({
                    "backend": be, "egress": "-", "status": "skip",
                    "words": 0, "quality": 0.0, "ms": 0, "detail": f"{KEY_ENVS[be]} not set",
                })
                continue
            for eg in ("direct", "proxy", "relay"):
                if eg == "proxy" and (not have_px or not supports_px):
                    continue
                if eg == "relay" and not supports_rl:
                    continue
                t0 = time.time()
                try:
                    o = self._attempt(be, norm, eg, try_index=0)
                    rows.append({
                        "backend": be,
                        "egress": eg,
                        "status": "OK" if o.word_count > 0 else "EMPTY",
                        "words": o.word_count,
                        "quality": round(o.quality, 2),
                        "ms": int((time.time() - t0) * 1000),
                        "detail": f"[{o.parser}] {o.title[:50] or o.excerpt[:50]}",
                        "proxy": o.proxy,
                    })
                except BotWalled as e:
                    rows.append({
                        "backend": be, "egress": eg, "status": "WALL",
                        "words": 0, "quality": 0.0, "ms": int((time.time() - t0) * 1000),
                        "detail": str(e)[:75],
                    })
                except Exception as e:
                    rows.append({
                        "backend": be, "egress": eg, "status": "down",
                        "words": 0, "quality": 0.0, "ms": int((time.time() - t0) * 1000),
                        "detail": f"{type(e).__name__}: {str(e)[:65]}",
                    })
                h = self.health(be)
                h.cooldown_until = 0.0
                h.consecutive_fail = 0
                h.strikes = 0
        return rows


# ---------------------------------------------------------------------------
# Module-Level Convenience API (Drop-in) + `free_search` Bridge
# ---------------------------------------------------------------------------

_DEFAULT: Optional[FreeExtract] = None
_DEFAULT_LOCK = threading.Lock()


def default_client() -> FreeExtract:
    global _DEFAULT
    if _DEFAULT is None:
        with _DEFAULT_LOCK:
            if _DEFAULT is None:
                _DEFAULT = FreeExtract()
    return _DEFAULT


def extract(url: str, **kw) -> Dict[str, Any]:
    return default_client().extract(url, **kw).to_dict()


def extract_outcome(url: str, **kw) -> ExtractOutcome:
    return default_client().extract(url, **kw)


def extract_many(urls: Sequence[str], **kw) -> List[ExtractOutcome]:
    return default_client().extract_many(urls, **kw)


def extract_many_with_retry(urls: Sequence[str], **kw) -> List[ExtractOutcome]:
    return default_client().extract_many_with_retry(urls, **kw)


def search_and_extract(
    query: str,
    max_results: int = 5,
    workers: int = 5,
    **extract_kw,
) -> List[Dict[str, Any]]:
    try:
        import free_search  # type: ignore
        hits = free_search.search(query, max_results=max_results)
    except Exception as e:
        raise ExtractError(
            f"search_and_extract requires free_search.py in PYTHONPATH ({e})"
        ) from e

    urls = [str(h.get("url") or "") for h in hits if h.get("url")]
    outcomes = default_client().extract_many(urls, workers=workers, query=query, **extract_kw)
    by_url = {normalize_url(o.url): o for o in outcomes}
    combined: List[Dict[str, Any]] = []
    for h in hits:
        u = str(h.get("url") or "")
        o = by_url.get(normalize_url(u))
        row = dict(h)
        if o:
            row["extraction"] = o.to_dict()
            row["markdown"] = o.markdown
            row["text"] = o.text
            row["quality"] = round(o.quality, 3)
            row["deferred"] = o.deferred
        combined.append(row)
    return combined


# ---------------------------------------------------------------------------
# Drop-in HTTP Server Mode (Firecrawl / Tavily Extract / Jina Reader Compatible)
# ---------------------------------------------------------------------------

def serve(host: str = "127.0.0.1", port: int = 8079, client: Optional[FreeExtract] = None):
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    fe = client or FreeExtract()

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            logger.debug("http " + fmt, *args)

        def _send(self, code: int, obj: Any, content_type: str = "application/json; charset=utf-8"):
            if isinstance(obj, (bytes, bytearray)):
                body = bytes(obj)
            elif isinstance(obj, str):
                body = obj.encode("utf-8")
            else:
                body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def _body(self) -> Dict[str, Any]:
            try:
                length = int(self.headers.get("Content-Length") or 0)
                return json.loads(self.rfile.read(length) or b"{}") if length else {}
            except Exception:
                return {}

        def do_GET(self):
            p = urllib.parse.urlparse(self.path)
            qs = {k: v[0] for k, v in urllib.parse.parse_qs(p.query).items()}
            if p.path in ("/", "/health"):
                return self._send(200, {
                    "status": "ok",
                    "version": VERSION,
                    "backends": fe.priority[:12],
                })
            if p.path == "/stats":
                return self._send(200, fe.stats())
            if p.path in ("/extract", "/v1/extract", "/v1/scrape", "/reader"):
                u = qs.get("url") or qs.get("u") or ""
                fmt = (qs.get("format") or "json").lower()
                o = fe.extract(
                    u,
                    backend=qs.get("backend") or None,
                    egress=qs.get("egress") or None,
                    query=qs.get("query") or None,
                )
                code = 200 if not o.deferred else 202
                if fmt in ("md", "markdown"):
                    return self._send(code, o.markdown, "text/markdown; charset=utf-8")
                if fmt in ("txt", "text"):
                    return self._send(code, o.text, "text/plain; charset=utf-8")
                return self._send(code, o.to_dict())
            if p.path.startswith(("/http://", "/https://")):
                raw_target = self.path.lstrip("/")
                o = fe.extract(raw_target)
                accept = (self.headers.get("Accept") or "").lower()
                if "application/json" in accept:
                    return self._send(200 if not o.deferred else 202, o.to_dict())
                return self._send(
                    200 if not o.deferred else 202,
                    f"Title: {o.title}\nURL Source: {o.final_url}\n\nMarkdown Content:\n{o.markdown}\n",
                    "text/markdown; charset=utf-8",
                )
            return self._send(404, {"error": "not found", "path": p.path})

        def do_POST(self):
            p = urllib.parse.urlparse(self.path)
            data = self._body()
            if p.path in ("/extract", "/v1/scrape"):
                u = str(data.get("url") or "")
                o = fe.extract(
                    u,
                    backend=data.get("backend") or None,
                    egress=data.get("egress") or None,
                    query=data.get("query") or None,
                )
                payload = o.to_dict()
                payload["success"] = not o.deferred
                return self._send(200 if not o.deferred else 202, payload)
            if p.path in ("/batch", "/extract/batch", "/v1/extract"):
                urls = data.get("urls") or ([data["url"]] if data.get("url") else [])
                w = int(data.get("workers") or 6)
                outs = fe.extract_many([str(x) for x in urls], workers=w, progress=False)
                return self._send(200, {
                    "results": [o.to_dict() for o in outs if not o.deferred],
                    "failed_results": [
                        {"url": o.url, "error": "; ".join(o.errors[-3:])}
                        for o in outs if o.deferred
                    ],
                    "deferred": [o.url for o in outs if o.deferred],
                })
            return self._send(404, {"error": "not found", "path": p.path})

    srv = ThreadingHTTPServer((host, port), Handler)
    logger.info("free-extract API listening on http://%s:%d/extract?url=...", host, port)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _setup_logging(level: str = "INFO"):
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)s | %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stderr,
    )
    logging.getLogger("urllib3").setLevel(logging.WARNING)


def _print_outcome(o: ExtractOutcome, fmt: str = "summary", max_preview_chars: int = 2400):
    if fmt == "json":
        print(json.dumps(o.to_dict(), ensure_ascii=False, indent=2))
        return
    if fmt in ("md", "markdown"):
        print(o.markdown)
        return
    if fmt in ("txt", "text"):
        print(o.text)
        return
    print(
        f"\n{o.url}  -> {o.word_count} words (quality={o.quality:.2f})  "
        f"[backend={o.backend} parser={o.parser} egress={o.egress} "
        f"{'cache' if o.from_cache else 'live'} {o.elapsed_ms}ms]"
    )
    if o.title:
        print(f"  Title: {o.title}")
    if o.author or o.published_date:
        print(f"  Byline: {o.author or '-'} | Date: {o.published_date or '-'}")
    if o.deferred:
        print("  DEFERRED - no backend delivered clean content; retry next run.")
        for e in o.errors[-5:]:
            print("   !", e)
    else:
        body = o.markdown or o.text
        preview = body[:max_preview_chars]
        print("\n" + preview + ("\n... [use --format markdown for full output]" if len(body) > max_preview_chars else ""))


def main(argv: Optional[Sequence[str]] = None) -> int:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--log-level", default=os.getenv("EXTRACT_LOG_LEVEL", "INFO"))

    prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "free_extract.py"
    ap = argparse.ArgumentParser(
        prog=prog_name,
        parents=[common],
        description="Unmetered free website content extraction: many backends x many egress IPs x cache.",
    )
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("extract", parents=[common], help="extract one URL")
    p.add_argument("url", help="target webpage URL")
    p.add_argument("--backend", default=None, help="force one backend")
    p.add_argument("--egress", default=None, choices=list(EGRESS_ORDER) + [None])
    p.add_argument("--query", default=None, help="optional topic/query for relevance scoring")
    p.add_argument("--format", default="summary", choices=["summary", "markdown", "md", "text", "txt", "json"])
    p.add_argument("--full", action="store_true", help="print full markdown instead of summary preview")
    p.add_argument("--json", action="store_true", help="shorthand for --format json")
    p.add_argument("--no-cache", action="store_true")
    p.add_argument("--allow-low-quality", action="store_true")
    p.add_argument("-o", "--out", default=None, help="write output to file")

    p = sub.add_parser("batch", parents=[common], help="extract many URLs concurrently")
    p.add_argument("file", help="text file with one URL per line, or '-' for stdin")
    p.add_argument("-j", "--workers", type=int, default=6)
    p.add_argument("--query", default=None)
    p.add_argument("--no-cache", action="store_true")
    p.add_argument("--allow-low-quality", action="store_true")
    p.add_argument("--retry", action="store_true", help="re-queue deferred URLs after cooldown")
    p.add_argument("--json", default=None, help="write full outcomes JSON here")
    p.add_argument("--csv", default=None, help="write flat summary CSV here")
    p.add_argument("--md-dir", default=None, help="write one .md file per extracted URL in this folder")
    p.add_argument("--deferred", default=None, help="write un-extracted URLs here")

    p = sub.add_parser("search-extract", parents=[common], help="search via free_search + extract top pages")
    p.add_argument("query", nargs="+")
    p.add_argument("-n", "--max-results", type=int, default=5)
    p.add_argument("-j", "--workers", type=int, default=5)
    p.add_argument("--json", default=None, help="write combined JSON to file")

    p = sub.add_parser("selftest", parents=[common], help="backend x egress health matrix")
    p.add_argument("-u", "--url", default="https://example.com")
    p.add_argument("--no-proxy", action="store_true")
    p.add_argument("--json", action="store_true")

    p = sub.add_parser("proxies", parents=[common], help="harvest / validate the free proxy pool")
    p.add_argument("--refresh", action="store_true")
    p.add_argument("--test", type=int, default=0)
    p.add_argument("--json", action="store_true")

    p = sub.add_parser("serve", parents=[common], help="run the drop-in HTTP extraction API")
    p.add_argument("--host", default=os.getenv("EXTRACT_HOST", "127.0.0.1"))
    p.add_argument("--port", type=int, default=int(os.getenv("EXTRACT_PORT", "8079")))

    sub.add_parser("stats", parents=[common], help="dump live stats + cache info")
    sub.add_parser("prune", parents=[common], help="delete expired cache rows")

    args = ap.parse_args(argv)
    _setup_logging(args.log_level)

    if args.cmd == "extract":
        fe = FreeExtract()
        fmt = "json" if args.json else ("markdown" if args.full else args.format)
        o = fe.extract(
            args.url,
            backend=args.backend,
            egress=args.egress,
            query=args.query,
            allow_low_quality=True if args.allow_low_quality else None,
            use_cache=False if args.no_cache else None,
        )
        _print_outcome(o, fmt)
        if args.out:
            with open(args.out, "w", encoding="utf-8") as fh:
                if fmt in ("md", "markdown") or args.out.endswith(".md"):
                    fh.write(o.markdown + "\n")
                elif fmt in ("txt", "text") or args.out.endswith(".txt"):
                    fh.write(o.text + "\n")
                else:
                    json.dump(o.to_dict(), fh, ensure_ascii=False, indent=2)
            print(f"\nwrote {args.out}", file=sys.stderr)
        return 0 if not o.deferred else 2

    if args.cmd == "batch":
        raw = sys.stdin.read() if args.file == "-" else open(args.file, encoding="utf-8").read()
        urls = [
            ln.strip() for ln in raw.splitlines()
            if ln.strip() and not ln.lstrip().startswith("#")
        ]
        fe = FreeExtract()
        common_kw = dict(
            query=args.query,
            allow_low_quality=True if args.allow_low_quality else None,
            use_cache=False if args.no_cache else None,
        )
        runner = fe.extract_many_with_retry if args.retry else fe.extract_many
        outs = runner(urls, workers=args.workers, **common_kw)
        ok = [o for o in outs if not o.deferred]
        print(
            f"\nbatch done: {len(ok)}/{len(outs)} extracted, "
            f"{sum(o.word_count for o in ok)} total words",
            file=sys.stderr,
        )
        if args.json:
            with open(args.json, "w", encoding="utf-8") as fh:
                json.dump([o.to_dict() for o in outs], fh, ensure_ascii=False, indent=2)
            print(f"wrote {args.json}", file=sys.stderr)
        if args.csv:
            with open(args.csv, "w", encoding="utf-8", newline="") as fh:
                w = csv.writer(fh)
                w.writerow([
                    "url", "final_url", "title", "author", "published_date",
                    "word_count", "quality", "backend", "parser", "egress",
                    "from_cache", "deferred", "excerpt",
                ])
                for o in outs:
                    w.writerow([
                        o.url, o.final_url, o.title, o.author, o.published_date,
                        o.word_count, round(o.quality, 3), o.backend, o.parser,
                        o.egress, o.from_cache, o.deferred, o.excerpt,
                    ])
            print(f"wrote {args.csv}", file=sys.stderr)
        if args.md_dir:
            os.makedirs(args.md_dir, exist_ok=True)
            for i, o in enumerate(ok, 1):
                slug = re.sub(r"[^a-zA-Z0-9_\-]+", "_", o.title or o.url)[:60].strip("_") or f"page_{i}"
                p_md = os.path.join(args.md_dir, f"{i:03d}_{slug}.md")
                with open(p_md, "w", encoding="utf-8") as fh:
                    fh.write(f"<!-- url: {o.final_url or o.url} | backend: {o.backend} | parser: {o.parser} -->\n\n")
                    fh.write(o.markdown + "\n")
            print(f"wrote {len(ok)} markdown files to {args.md_dir}", file=sys.stderr)
        deferred = [o.url for o in outs if o.deferred]
        if args.deferred and deferred:
            with open(args.deferred, "w", encoding="utf-8") as fh:
                fh.write("\n".join(deferred) + "\n")
            print(f"wrote {len(deferred)} deferred URLs to {args.deferred}", file=sys.stderr)
        return 0 if ok else 2

    if args.cmd == "search-extract":
        q_str = " ".join(args.query)
        rows = search_and_extract(q_str, max_results=args.max_results, workers=args.workers)
        if args.json:
            with open(args.json, "w", encoding="utf-8") as fh:
                json.dump(rows, fh, ensure_ascii=False, indent=2)
            print(f"wrote {args.json}", file=sys.stderr)
        else:
            print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0 if rows else 2

    if args.cmd == "selftest":
        fe = FreeExtract()
        rows = fe.selftest(url=args.url, test_proxy=not args.no_proxy)
        if args.json:
            print(json.dumps(rows, ensure_ascii=False, indent=2))
        else:
            print(f"\n{'BACKEND':<18}{'EGRESS':<8}{'STATUS':<7}{'WORDS':>7}{'QUAL':>6}{'MS':>7}  DETAIL")
            print("-" * 100)
            for r in rows:
                print(
                    f"{r['backend']:<18}{r['egress']:<8}{r['status']:<7}"
                    f"{r['words']:>7}{r['quality']:>6.2f}{r['ms']:>7}  {r.get('detail', '')[:54]}"
                )
            oks = sum(1 for r in rows if r["status"] == "OK")
            print("-" * 100)
            print(f"{oks}/{len(rows)} backend+egress combinations extracted content")
        return 0

    if args.cmd == "proxies":
        pp = ProxyPool()
        if args.test:
            cands = pp.harvest()[: args.test]
            scored = pp.validate(cands, limit=args.test)
            payload = {
                "tested": len(cands),
                "alive": len(scored),
                "proxies": [{"proxy": c, "latency_s": round(l, 2)} for c, l in scored[:40]],
            }
            print(
                json.dumps(payload, ensure_ascii=False, indent=2)
                if args.json
                else f"tested {len(cands)} -> {len(scored)} alive\n"
                + "\n".join(f"  {c}  {l:.2f}s" for c, l in scored[:40])
            )
            return 0
        okk = pp.build(force=args.refresh)
        st = pp.stats()
        print(
            json.dumps(st, ensure_ascii=False, indent=2)
            if args.json
            else f"proxy pool: {st['alive']}/{st['pool']} alive (builds={st['builds']}) -> {'OK' if okk else 'FAILED'}"
        )
        return 0 if okk else 1

    if args.cmd == "serve":
        serve(args.host, args.port)
        return 0

    if args.cmd == "stats":
        fe = FreeExtract()
        print(json.dumps(fe.stats(), ensure_ascii=False, indent=2))
        return 0

    if args.cmd == "prune":
        c = ResultCache()
        print(f"pruned {c.prune()} expired rows; {c.size()} remain")
        return 0

    ap.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())